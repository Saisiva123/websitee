const initState={
    loading:false
}
export const LoaderReducer=(state=initState,action)=>
{
    switch(action.type)
    {
        case "SET_LOADER":
            return{
                ...state,
                loading:action.payload
            }
        default:
            return state;
    }
}