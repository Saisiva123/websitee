const initState = {
  typeFor: "",
  value: "",
};
export const SortByReducer = (state = initState, action) => {
  switch (action.type) {
    case "SORT":
      return { ...state,
      typeFor:action.typeFor,
      value:action.value
    };
    default:
      return state;
  }
};
