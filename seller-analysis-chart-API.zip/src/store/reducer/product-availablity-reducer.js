let intialStates = {
  productAvailablityData: null,
  currentCategory: "",
  label: "",
  rightTableData: [],
  leftTableData: [],
};

export const ProductAvailablityReducer = (state = intialStates, action) => {
  switch (action.type) {
    case "SET_TABLE_DATA":
      return {
        ...state,
        currentCategory: action.currentCategory,
        rightTableData: action.rightTableData,
        leftTableData: action.leftTableData,
        label: action.label,
      };
    case "SET_PRODUCTAVAILITY_DATA":
      return {
        ...state,
        productAvailablityData: action.data,
      };
    default:
      return state;
  }
};
