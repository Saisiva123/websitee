const intialState = {
  loading: false,
  KpiButtonData: [
    {
      title: "Product Availability",
      percentageData: "67%",
      isPositive: true,
      percentageSubData: "+6%",
      kpiSubData: "25 products available in stock",
      toolTipDescription: [
        "Product Availability is the measure of all the products(listings) that are in stock at least for one seller vs total  listing available on platform for a given week/month/quater. it is reported as a % value of the overall listing (Out of stock + In stock).",
        "Calculation : Product Availability = Total in stock listing Current selection/ Total listing (out of stock + in stock)",
      ],

      link: "/dashboard/overview/product-availability",
      noChange: false,
    },
    {
      title: "Seller Analysis",
      percentageData: "58.2K",
      isPositive: false,
      percentageSubData: "-100",
      kpiSubData: "07% decrease in number of sellers",
      toolTipDescription: [
        "Seller Analysis is defined as count of unique seller on selected date for a given region / country / platform. It comprises both HP authorized and Unauthorized sellers.",
        "Note: Sellers remain unique for a country. Eg. Same seller can exist for India, Malaysia and Singapore but at overall APJ level it will only be counted as 1 seller.",
        "Calculation : Seller listing fo a given week is = Total unique seller listing for that week.",
      ],
      link: "/dashboard/overview/seller-analysis",
      noChange: false,
    },
    {
      title: "Price Change",
      percentageData: "32%",
      isPositive: false,
      percentageSubData: "-2%",
      kpiSubData: "60K SKU's underwent price change out of 500K SKU's",
      toolTipDescription: [
        "Price change depicts the count of products for which Net/Total Price changed basis selected date range",
        "Calculation : Price Change (%) = (Count of Net price changed SKUs) common listed SKUs (previous & current week).",
      ],
      link: "/dashboard/overview/price-change",
      noChange: false,
    },
    {
      title: "Content Compliance",
      percentageData: "78%",
      isPositive: false,
      percentageSubData: "-12%",
      kpiSubData: "12% less than target 90%",
      toolTipDescription: ["Content Compliance Desc"],
      link: "/dashboard/overview/content-compliance",
      noChange: false,
    },
    {
      title: "Share of Search",
      percentageData: "42%",
      isPositive: false,
      percentageSubData: "-5%",
      kpiSubData: "08% less than target 50%",
      toolTipDescription: ["Share of Search Desc"],
      link: "/dashboard/overview/share-of-search",
      noChange: false,
    },
    {
      title: "Reviews",
      percentageData: "4.2K",
      isPositive: false,
      percentageSubData: "-1.2K",
      kpiSubData: "20% reviews with less than 4 stars",
      toolTipDescription: ["Reviews Desc"],
      link: "/dashboard/overview/reviews",
      noChange: false,
    },
    {
      title: "Ratings",
      percentageData: "3.5",
      isPositive: false,
      percentageSubData: "No Change",
      kpiSubData: "4.3% drop in revenue than last week",
      toolTipDescription: ["Ratings Desc"],
      link: "/dashboard/overview/ratings",
      noChange: true,
    },
  ],
  currentKpi: "",
};

const kpiReducer = (state = intialState, action) => {
  switch (action.type) {
    case "FETCHING_KPI_DATA_START": {
      return {
        ...state,
        loading: true,
      };
    }
    case "SET_KPI_DATA": {
      return {
        ...state,
        loading: false,
      };
    }
    case "SET_PATH": {
      return {
        ...state,
        currentKpi: action.path,
      };
    }
    default: {
      return state;
    }
  }
};

export default kpiReducer;
