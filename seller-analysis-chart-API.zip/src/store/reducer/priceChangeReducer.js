let intialStates = {
  priceChangeData: null,
  currentCategory: "",
  label: "",
  rightTableData: [],
  downTableData: [],
};

export const priceChangeReducer = (state = intialStates, action) => {
  switch (action.type) {
    case "SET_TABLE_PRICE_DATA":
      return {
        ...state,
        currentCategory: action.currentCategory,
        rightTableData: action.rightTableData,
        downTableData: action.downTableData,
        label: action.label,
      };
    case "SET_PRICE_CHANGE_DATA":
      return {
        ...state,
        priceChangeData: action.data,
      };
    default:
      return state;
  }
};
