const intialState={
    breadcrumData:[
        {
            title:'Product Availabilty',
            link:''
        }
    ]
};

export const breadcrumReducer = (state=intialState,action) => {
    switch (action.type)
    {
        case 'UPDATE_BREADCRUM_DATA':{
            const updatedData = [
                ...state.breadcrumData,
                {
                    title:action.title,
                    link:action.link
                }
            ]
            return {
                ...state,
                breadcrumData:updatedData
            }
        }
        case 'SET_BREADCRUM_DATA':{
            return{
                ...state,
                breadcrumData:[
                    {
                        title:action.title,
                        link:""
                    },
                    {
                        title:"Worldwide Overview",
                        link:""
                    }
                ]
            }
        }
        default :
            return state;
    }
}

