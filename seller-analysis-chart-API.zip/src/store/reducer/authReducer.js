const intialState = {
  loginData: {
    token: null,
    firstName: "",
    lastName: "",
    role: "",
    emailAddress: "",
    isActive: false,
    countryAccess: "",
  },
  changePassword: {
    message: "",
    error: null,
  },
  setPassword: {
    message: "",
    error: null,
  },
  error: null,
  forgotError: null,
  loading: false,
  authRedirectPath: "/",
};

export const authReducer = (state = intialState, action) => {
  switch (action.type) {
    case "START_LOGIN_LOADING":
      return {
        ...state,
        loading: true,
      };
    case "SETPASSWORD_SUCCESS":
      return {
        ...state,
        setPassword: {
          message: "Password changed successfully",
          error: null,
        },
      };
    case "SETPASSWORD_FAILED":
      return {
        ...state,
        setPassword: {
          message: "",
          error: "",
        },
      };
    case "RESET_SETPASSWORD":
      return {
        ...state,
        setPassword: {
          message: "",
          error: null,
        },
      };
    case "FORGOT_SUCCESS":
      return {
        ...state,
        forgotError: null,
        loading: false,
      };
    case "FORGOT_FAILED":
      return {
        ...state,
        loading: false,
        forgotError: action.error,
      };
    case "CHANGEPASSWORD_SUCCESS":
      return {
        ...state,
        loading: false,
        changePassword: {
          message: "Password changed successfully",
          error: null,
        },
      };
    case "CHANGEPASSWORD_FAILED":
      return {
        ...state,
        loading: false,
        changePassword: {
          message: "",
          error: "Error",
        },
      };

    case "CHANGEPASSWORD_RESET":
      return {
        ...state,
        changePassword: {
          message: "",
          error: null,
        },
      };
    case "LOGIN_SUCESS":
      return {
        ...state,
        loginData: {
          token: action.data.token,
          firstName: action.data.firstName,
          lastName: action.data.lastName,
          role: action.data.role,
          emailAddress: action.data.email,
          isActive: action.data.isActive,
          countryAccess: action.data.countryAccess[0],
        },
        loading: false,
        error: null,
      };
    case "LOGIN_FAILED":
      return {
        ...state,
        error: action.error,
        loading: false,
      };
    case "SET_LOGOUT":
      return {
        ...state,
        loginData: {
          token: null,
          firstName: "",
          lastName: "",
          role: "",
          emailAddress: "",
          isActive: false,
          countryAccess: "",
        },
      };
    case "SET_AUTH_REDIRECT_PATH":
      return {
        ...state,
        authRedirectPath: action.path,
      };
    case "RESET_ERROR_STATE":
      return {
        ...state,
        forgotError: null,
      };
    default:
      return state;
  }
};
