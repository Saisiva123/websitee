const intialState = {
  dropdownsVisiblity: {
    country: true,
    platform: false,
    category: false,
    sellerType: false,
  },
  country: [],
  platform: [],
  category: [],
  sellerType: [],
  changePasswordDialog: false,
  selectedCountry: "",
  selectedPlatform: "",
  selectedCategory: "",
  selectedSellerType: "",
  currentTimeline: "Weekly",
  date: new Date(),
  fromDate: "",
  toDate: "",
};

export const HeaderReducer = (state = intialState, action) => {
  switch (action.type) {
    case "SET_DROPDOWNS_VISIBILITY":
      return {
        ...state,
        dropdownsVisiblity: action.dropdownsVisiblity,
      };
    case "SET_DROPDOWN_DATA":
      return {
        ...state,
        country: action.countryArray,
        platform: action.platformArray,
        category: action.categoryArray,
        sellerType: action.sellerTypeArray,
      };
    case "SET_CHANGEPASSWORD_DIALOG_VISIBILITY":
      return {
        ...state,
        changePasswordDialog: action.value,
      };
    case "SET_COUNTRY":
      return {
        ...state,
        selectedCountry: action.selectedCountry,
      };

    case "SET_PLATFORM":
      return {
        ...state,
        selectedPlatform: action.selectedPlatform,
      };

    case "SET_CATEGORY":
      return {
        ...state,
        selectedCategory: action.selectedCategory,
      };

    case "SET_SELLER_TYPE":
      return {
        ...state,
        selectedSellerType: action.selectedSellerType,
      };

    case "SET_TIMELINE":
      return {
        ...state,
        currentTimeline: action.currentTimeline,
      };

    case "SET_DATE":
      return {
        ...state,
        date: action.date,
      };
    case "SET_CALENDER_DATE":
      return {
        ...state,
        fromDate: action.fromDate,
        toDate: action.toDate,
        currentTimeline: action.currentTimeline,
      };
    default:
      return state;
  }
};
