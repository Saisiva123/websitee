let intialStates = {
  sellerAnalysisData: null,
  currentCategory: "",
  label: "",
  downTableData: [],
};

export const sellerAnalysisReducer = (state = intialStates, action) => {
  switch (action.type) {
    case "SET_TABLE_SELLER_DATA":
      return {
        ...state,
        currentCategory: action.currentCategory,
        downTableData: action.downTableData,
        label: action.label,
      };
    case "SET_SELLER_ANALYSIS_DATA":
      return {
        ...state,
        sellerAnalysisData: action.data,
      };
    default:
      return state;
  }
};
