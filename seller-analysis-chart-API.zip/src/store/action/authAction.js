import axios from "axios";

export const loginStart = () => {
  return {
    type: "START_LOGIN_LOADING",
  };
};

export const loginSuccess = (data) => {
  return {
    type: "LOGIN_SUCESS",
    data: data,
  };
};

export const changePasswordSuccess = () => {
  return {
    type: "CHANGEPASSWORD_SUCCESS",
  };
};

export const changePasswordFailed = () => {
  return {
    type: "CHANGEPASSWORD_FAILED",
  };
};

export const resetChangePassword = () => {
  return {
    type: "CHANGEPASSWORD_RESET",
  };
};

export const changePassword = (authorizedToken, oldPass, newPass) => {
  return (dispatch) => {
    dispatch(loginStart());
    const data = {
      oldPassword: oldPass,
      newPassword: newPass,
    };
    const options = {
      headers: { authorization: "token " + authorizedToken },
    };
    axios
      .put("https://10.100.23.33:3001/updatepassword", data, options)
      .then((response) => {
        dispatch(changePasswordSuccess());
      })
      .catch((error) => {
        dispatch(changePasswordFailed());
      });
  };
};

export const loginFailed = (error) => {
  return {
    type: "LOGIN_FAILED",
    error: error,
  };
};

export const logout = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("firstName");
  localStorage.removeItem("lastName");
  localStorage.removeItem("role");
  localStorage.removeItem("emailAddress");
  localStorage.removeItem("isActive");
  localStorage.removeItem("countryAccess");
  return {
    type: "SET_LOGOUT",
  };
};

export const setPasswordSuccess = () => {
  return {
    type: "SETPASSWORD_SUCCESS",
  };
};

export const setPasswordFailed = () => {
  return {
    type: "SETPASSWORD_FAILED",
  };
};

export const resetSetPassword = () => {
  return {
    type: "RESET_SETPASSWORD",
  };
};

export const setPassword = (token, password) => {
  return (dispatch) => {
    dispatch(loginStart());
    const data = {
      password: password,
    };
    const options = {
      headers: {
        authorization: "token " + token,
      },
    };
    axios
      .put("https://10.100.23.33:3001/update", data, options)
      .then((response) => {
        dispatch(setPasswordSuccess());
      })
      .catch((error) => {
        dispatch(setPasswordFailed());
      });
  };
};

export const checkAuthTimeout = (expirationTime) => {
  return (dispatch) => {
    setTimeout(() => {
      dispatch(logout());
    }, expirationTime * 1000);
  };
};

export const resetErrorState = () => {
  return {
    type: "RESET_ERROR_STATE",
  };
};

export const forgotSuccess = () => {
  return {
    type: "FORGOT_SUCCESS",
  };
};

export const forgotFailed = (error) => {
  return {
    type: "FORGOT_FAILED",
    error: error,
  };
};

export const submitForgotMail = (email) => {
  return (dispatch) => {
    dispatch(loginStart());
    const data = {
      email: email,
    };
    axios
      .post("https://10.100.23.33:3001/forgot", data)
      .then((response) => {
        dispatch(forgotSuccess());
      })
      .catch((err) => {
        dispatch(forgotFailed("Something went wrong"));
      });
  };
};

export const login = (email, pass) => {
  return (dispatch) => {
    dispatch(loginStart());
    const data = {
      email: email,
      password: pass,
    };
    axios
      .post("https://10.100.23.33:3001/login", data)
      .then((response) => {
        //const expirationDate = new Date(new Date().getTime + response.data.expiresIn * 1000);
        localStorage.setItem("token", response.data.token);
        localStorage.setItem("firstName", response.data.firstName);
        localStorage.setItem("lastName", response.data.lastName);
        localStorage.setItem("emailAddress", response.data.email);
        localStorage.setItem("role", response.data.role);
        localStorage.setItem("isActive", response.data.isActive);
        localStorage.setItem("countryAccess", response.data.countryAccess[0]);
        //localStorage.setItem("expirationDate",expirationDate)
        dispatch(loginSuccess(response.data));
        //dispatch(checkAuthTimeout(response.data.expiresIn));
      })
      .catch((err) => {
        dispatch(loginFailed("Invalid Credential"));
      });
  };
};

export const authRedirectPath = (path) => {
  return {
    type: "SET_AUTH_REDIRECT_PATH",
    path: path,
  };
};

export const loginCheckState = () => {
  return (dispatch) => {
    const token = localStorage.getItem("token");
    if (!token) {
      dispatch(logout());
    } else {
      //const expirationDate = new Date(localStorage.getItem('expirationDate'));
      const data = {
        token: token,
        firstName: localStorage.getItem("firstName"),
        lastName: localStorage.getItem("lastName"),
        email: localStorage.getItem("emailAddress"),
        role: localStorage.getItem("role"),
        isActive: localStorage.getItem("isActive"),
        countryAccess: [localStorage.getItem("countryAccess")],
      };
      dispatch(loginSuccess(data));
    }
  };
};
