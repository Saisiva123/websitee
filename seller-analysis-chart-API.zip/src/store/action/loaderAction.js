export const LoaderAction=(value)=>
{

    return {
        type:"SET_LOADER",
        payload:value
    }

}