export const setCurrentSellerAnalysisTableData = (
  category,
  downData,
  label
) => {
  return {
    type: "SET_TABLE_SELLER_DATA",
    currentCategory: category,
    downTableData: downData,
    label: label,
  };
};

export const setSellerAnalysisData = (data) => {
  return {
    type: "SET_SELLER_ANALYSIS_DATA",
    data,
  };
};
