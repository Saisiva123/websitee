export const SortBy = (item) => {
    return {
      type: "SORT",
      typeFor:item.typeFor,
      value:item.value
    };
  };