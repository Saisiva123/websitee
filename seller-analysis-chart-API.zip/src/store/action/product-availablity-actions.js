export const setCurrentTableData = (category, leftData, rightData, label) => {
  return {
    type: "SET_TABLE_DATA",
    currentCategory: category,
    rightTableData: rightData,
    leftTableData: leftData,
    label: label,
  };
};
export const setProductAvailabilityData = (data) => {
  return {
    type: "SET_PRODUCTAVAILITY_DATA",
    data,
  };
};
