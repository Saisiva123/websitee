export const setKpiData = (kpiData) => {
  return (dispatch) => {
    dispatch(setKpiStart());
    setTimeout(() => {
      dispatch(setKpi(kpiData));
    }, 500);
  };
};

const setKpiStart = () => {
  return {
    type: "FETCHING_KPI_DATA_START",
  };
};

const setKpi = (data) => {
  return {
    type: "SET_KPI_DATA",
    kpiData: data,
  };
};

export const onTabSelected = (path) => {
  return {
    type: "SET_PATH",
    path: path,
  };
};
