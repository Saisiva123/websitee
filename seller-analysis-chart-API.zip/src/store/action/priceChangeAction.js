export const setCurrentPriceChangeTableData = (
  category,
  rightData,
  downData,
  label
) => {
  return {
    type: "SET_TABLE_PRICE_DATA",
    currentCategory: category,
    rightTableData: rightData,
    downTableData: downData,
    label: label,
  };
};
export const setPriceChangeData = (data) => {
  return {
    type: "SET_PRICE_CHANGE_DATA",
    data,
  };
};
