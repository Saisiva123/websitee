export const updateBreadCrumData = (title,link) => {
    return {
        type:'UPDATE_BREADCRUM_DATA',
        title:title,
        link:link
    }
}

export const onKpiTabClicked = (title,link) =>{
    return {
        type:'SET_BREADCRUM_DATA',
        title:title,
        link:link
    }
}