export const setDropdownVisiblity = (dropdownsVisiblity) => {
  return {
    type: "SET_DROPDOWNS_VISIBILITY",
    dropdownsVisiblity: dropdownsVisiblity,
  };
};

export const setCountry = (country) => {
  return {
    type: "SET_COUNTRY",
    selectedCountry: country,
  };
};

export const setDropDownData = (data) => {
  console.log(data);
  return {
    type: "SET_DROPDOWN_DATA",
    countryArray: data["country"] !== undefined ? data.country : [],
    platformArray: data["platform"] !== undefined ? data.platform : [],
    categoryArray: data["category"] !== undefined ? data.category : [],
    sellerTypeArray: data["sellerType"] !== undefined ? data.sellerType : [],
  };
};

export const setChangePasswordDialog = (value) => {
  return {
    type: "SET_CHANGEPASSWORD_DIALOG_VISIBILITY",
    value: value,
  };
};

export const setCalenderDate = (fromDate, toDate, currentTimeline) => {
  return {
    type: "SET_CALENDER_DATE",
    fromDate: fromDate,
    toDate: toDate,
    currentTimeline: currentTimeline,
  };
};

export const setPlatForm = (platform) => {
  return {
    type: "SET_PLATFORM",
    selectedPlatform: platform,
  };
};
export const setCategory = (category) => {
  return {
    type: "SET_CATEGORY",
    selectedCategory: category,
  };
};
export const setSellerType = (sellerType) => {
  return {
    type: "SET_SELLER_TYPE",
    selectedSellerType: sellerType,
  };
};

export const setTimeLine = (timeline) => {
  return {
    type: "SET_TIMELINE",
    currentTimeline: timeline,
  };
};
export const setDate = (date) => {
  return {
    type: "SET_DATE",
    date: date,
  };
};
