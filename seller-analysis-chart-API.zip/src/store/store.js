import { createStore, combineReducers, applyMiddleware } from "redux";
import kpiReducer from "./reducer/kpiReducer";
import { ProductAvailablityReducer } from "./reducer/product-availablity-reducer";
import { breadcrumReducer } from "./reducer/breadcrumReducer";
import { HeaderReducer } from "./reducer/header-reducer";
import { priceChangeReducer } from "./reducer/priceChangeReducer";
import { sellerAnalysisReducer } from "./reducer/sellerAnalysisReducer";
import { SortByReducer } from "./reducer/sortBy-reducer";
import { LoaderReducer } from "./reducer/loaderReducer";
import { authReducer } from "./reducer/authReducer";

import thunk from "redux-thunk";

const rootReducer = combineReducers({
  kpi: kpiReducer,
  productAvailablity: ProductAvailablityReducer,
  sellerAnalysis: sellerAnalysisReducer,
  priceChange: priceChangeReducer,
  breadcrum: breadcrumReducer,
  authentication: authReducer,
  header: HeaderReducer,
  sortBy: SortByReducer,
  loader: LoaderReducer,
});

export const store = createStore(rootReducer, applyMiddleware(thunk));
