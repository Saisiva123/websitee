import React, { Suspense, lazy } from "react";
import "./App.css";
import { HashRouter, Route, Switch, Redirect } from "react-router-dom";
import Loader from "./component/loader/loader";
import { LoaderAction } from "./store/action/loaderAction";
import Backdrop from "@material-ui/core/Backdrop";
import { useSelector, useDispatch } from "react-redux";
import { loginCheckState } from "./store/action/authAction";
import { setChangePasswordDialog } from "./store/action/header-action";
const RootLayout = lazy(() => import("./container/RootLayout"));
const NavBar = lazy(() => import("./component/NavBar/NavigationItems"));
const SellerAnalysisLayout = lazy(() =>
  import("./container/SellerAnalysisLayout")
);
const PriceVarianceLayout = lazy(() =>
  import("./container/PriceVarianceLayout")
);
const Login = lazy(() => import("./component/Authentication/Login/Login"));
const ForgotPassword = lazy(() =>
  import("./component/Authentication/ForgotPassword/ForgotPassword")
);
const NewPassword = lazy(() =>
  import("./component/Authentication/NewPassword/NewPassword")
);
const PromotionAnalysis = lazy(() =>
  import("./component/PromotionAnalysis/PromotionAnalysis")
);
const ChangePassword = lazy(() =>
  import("./component/Authentication/ChangePassword/ChangePassword")
);
const UserMangement = lazy(() =>
  import("./component/UserManagement/user-mangement")
);
const DataImport = lazy(() => import("./component/DataImport/DataImport"));

const App = () => {
  var dispatch = useDispatch();
  dispatch(LoaderAction(true));
  const headerData = useSelector((state) => state.header);

  const handleClose = () => {
    dispatch(setChangePasswordDialog(false));
  };

  dispatch(loginCheckState());

  return (
    <>
      <Loader></Loader>
      <HashRouter basename="/">
        <Suspense fallback={<Loader />}>
          <Backdrop
            style={{ zIndex: "10" }}
            open={headerData.changePasswordDialog}
            invisible={!headerData.changePasswordDialog}
          >
            <ChangePassword />
          </Backdrop>

          <Route path={"/dashboard"} component={NavBar} />
          <Switch>
            <Route path="/login" exact component={Login} />
            <Route path="/forgotpassword" exact component={ForgotPassword} />
            <Route path="/setpassword" exact component={NewPassword} />
            <Route
              path="/dashboard/promotion-analysis"
              component={PromotionAnalysis}
            />
            <Route
              path={"/dashboard/overview/product-availability"}
              exact
              component={RootLayout}
            />
            <Route
              path={"/dashboard/data-import"}
              exact
              component={DataImport}
            />
            <Route
              path={"/dashboard/user-management"}
              exact
              component={UserMangement}
            />
            <Route
              path={"/dashboard/overview/price-change"}
              exact
              component={PriceVarianceLayout}
            />
            <Route
              path={"/dashboard/overview/seller-analysis"}
              exact
              component={SellerAnalysisLayout}
            />
            <Redirect
              from="/dashboard"
              to="/dashboard/overview/product-availability"
            />
            <Redirect from="/*" to="/login" />
          </Switch>
        </Suspense>
      </HashRouter>
    </>
  );
};

export default App;
//
