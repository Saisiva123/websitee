import React, { useEffect, useState } from "react";
import ContentChart from "../component/ContentComponent/content-charts";
import { useLocation, Redirect } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  intialiseProductAvailablityData,
  useQuery,
} from "../component/ContentComponent/utils";
import { getKPIData } from "../Axios/FliterAxios/FilterAxios";
import { getFormatedDates } from "../Utils/Utils";
import { setProductAvailabilityData } from "../store/action/product-availablity-actions";
// import Loader from  "../component/loader/loader";

const RootLayout = (props) => {
  let updatedQuery = useQuery();
  const location = useLocation();
  const data = useSelector((state) => state.productAvailablity);
  const authData = useSelector((state) => state.authentication);
  const headerData = useSelector((state) => state.header);
  const dispatch = useDispatch();
  // var [loader,setLoader]=useState(true);(

  useEffect(() => {
    intialiseProductAvailablityData(
      data.productAvailablity,
      headerData,
      dispatch,
      updatedQuery,
      authData,
      location.pathname
    );
  }, [location]);

  useEffect(() => {
    let seller = updatedQuery.get("seller") || "";

    getKPIData(
      "productAvailability",
      headerData.currentTimeline,
      headerData.selectedCategory,
      headerData.selectedSellerType,
      headerData.selectedPlatform,
      headerData.selectedCountry,
      seller,
      headerData.fromDate,
      headerData.toDate,
      4,
      authData.loginData.token
    )
      .then((res) => {
        dispatch(setProductAvailabilityData(res.data));
        console.log(res.data);
      })
      .catch((err) => {
        console.log(err.response);
      });
  }, [location, headerData]);
  return <ContentChart />;
};

export default RootLayout;
