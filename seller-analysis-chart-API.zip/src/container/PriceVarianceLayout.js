import React, { useEffect, useState } from "react";
import { Route, useLocation, useRouteMatch } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  intialisePriceChangeData,
  useQuery,
} from "../component/ContentComponent/utils";
import PriceVarianceContent from "../component/ContentComponent/price-variance-content/price-variance-content";
import { getKPIData } from "../Axios/FliterAxios/FilterAxios";
import { setPriceChangeData } from "../store/action/priceChangeAction";
// import Loader from  "../component/loader/loader";

const PriceVarianceLayout = (props) => {
  let { url } = useRouteMatch();
  let updatedQuery = useQuery();
  const location = useLocation();
  const data = useSelector((state) => state.priceChange);
  const authData = useSelector((state) => state.authentication);
  const headerData = useSelector((state) => state.header);
  const dispatch = useDispatch();

  useEffect(() => {
    intialisePriceChangeData(
      data,
      headerData,
      dispatch,
      updatedQuery,
      authData,
      location.pathname
    );
  }, [location]);
  useEffect(() => {
    let seller = updatedQuery.get("seller") || "";

    getKPIData(
      "priceVariance",
      headerData.currentTimeline,
      headerData.selectedCategory,
      headerData.selectedSellerType,
      headerData.selectedPlatform,
      headerData.selectedCountry,
      seller,
      headerData.fromDate,
      headerData.toDate,
      4,
      authData.loginData.token
    )
      .then((res) => {
        dispatch(setPriceChangeData(res.data));
        console.log(res.data);
      })
      .catch((err) => {
        console.log(err.response);
      });
  }, [location, headerData]);
  return (
    // loader?<Loader/>:<PriceVarianceContent/>
    <PriceVarianceContent />
  );
};

export default PriceVarianceLayout;
