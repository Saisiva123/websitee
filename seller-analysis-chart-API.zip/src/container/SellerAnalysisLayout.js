import React, { useEffect, useState } from "react";
import { Route, useLocation, useRouteMatch } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  intialiseSellerAnalysisData,
  useQuery,
} from "../component/ContentComponent/utils";
import { getKPIData } from "../Axios/FliterAxios/FilterAxios";
import SellerAnalyisContent from "../component/ContentComponent/seller-analysis-content/seller-analysis-content";
import { setSellerAnalysisData } from "../store/action/sellerAnalysisAction";

// import Loader from  "../component/loader/loader";

const SellerAnalysisLayout = (props) => {
  let { url } = useRouteMatch();
  let updatedQuery = useQuery();
  const location = useLocation();
  const data = useSelector((state) => state.sellerAnalysis);
  const headerData = useSelector((state) => state.header);
  const authData = useSelector((state) => state.authentication);
  const dispatch = useDispatch();
  //  var [loader,setLoader]=useState(true);

  useEffect(() => {
    intialiseSellerAnalysisData(
      data,
      headerData,
      dispatch,
      updatedQuery,
      authData,
      location.pathname
    );
  }, [location]);
  useEffect(() => {
    let seller = updatedQuery.get("seller") || "";

    getKPIData(
      "sellerAnalysis",
      headerData.currentTimeline,
      headerData.selectedCategory,
      headerData.selectedSellerType,
      headerData.selectedPlatform,
      headerData.selectedCountry,
      seller,
      headerData.fromDate,
      headerData.toDate,
      4,
      authData.loginData.token
    )
      .then((res) => {
        dispatch(setSellerAnalysisData(res.data));
        console.log(res.data);
      })
      .catch((err) => {
        console.log(err.response);
      });
  }, [location, headerData]);
  return <SellerAnalyisContent />;
};

export default SellerAnalysisLayout;
