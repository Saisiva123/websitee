import { addDays, subDays, addMonths, addYears } from "date-fns";
import { getDataFromDefault } from "../Axios/FliterAxios/FilterAxios";
import { setDropDownData } from "../store/action/header-action";

// Function for Product Availability Dashboard

export const SetDefaultApiData = (
  country,
  platform,
  category,
  sellerType,
  token,
  dispatch
) => {
  if (token === null) {
    const currentDate = new Date();
    const formattedDate =
      currentDate.getFullYear() +
      "-" +
      currentDate.getMonth() +
      "-" +
      currentDate.getDate;
    const dataObject = {
      date: formattedDate,
      country: country,
      platform: platform,
      category: category,
      sellerType: sellerType,
    };

    getDataFromDefault(dataObject, token)
      .then((response) => {
        dispatch(setDropDownData(response.data));
      })
      .catch((err) => console.log(err));
  }
};

export const checkValidity = (value, type) => {
  if (type === "email") {
    let isValid = true;
    const pattern = /^[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[A-Za-z]+$/;
    isValid = pattern.test(value) && isValid;
    return isValid;
  }
  if (type === "password") {
    let isValid = true;
    const patternn = /^.*(?=.{8,})((?=.*[!@#$%^&*()\-_=+{};:,<.>]){1})(?=.*\d)((?=.*[a-z]){1})((?=.*[A-Z]){1}).*$/g;
    isValid = patternn.test(value) && isValid;
    return isValid;
  }
  if (type == "oldPassword") {
    let isValid = true;
    isValid = value.length > 0 && isValid;
    return isValid;
  }
  if (type === "changePassword") {
    let eightDigitValid = true;
    let characterValid = true;
    let digitAndSymbolValid = true;

    const digitPattern = /^.*(?=.{8,}).*$/g;
    const characterPattern = /^.*((?=.*[a-z]){1})((?=.*[A-Z]){1}).*$/g;
    const symbolPattern = /^.*((?=.*[0-9]){1})((?=.*\W){1}).*$/g;

    eightDigitValid = digitPattern.test(value) && eightDigitValid;
    characterValid = characterPattern.test(value) && characterValid;
    digitAndSymbolValid = symbolPattern.test(value) && digitAndSymbolValid;

    return {
      isLengthValid: eightDigitValid,
      isCharacterValid: characterValid,
      isDigitAndSymbolValid: digitAndSymbolValid,
    };
  }
};

export const checkConfirmPassword = (newPassword, confirmPassword) => {
  let isValid = true;

  isValid = confirmPassword === newPassword && isValid;

  return isValid;
};

export const calculateProductAvailabilityKpiButtonData = (data) => {
  let productAvailabilityData = {};
  if (data.length !== 0) {
    let currentWeekPercentageValue = 0;
    let lastWeekPercentageValue = 0;
    let subPercentageValue = 0;
    let isPositive = false;
    let kpiSubDataValue = 0;
    let noChange = false;
    if (data[1] !== undefined) {
      currentWeekPercentageValue =
        (data[0].in_count / (data[0].in_count + data[0].out_count)) * 100;
      lastWeekPercentageValue =
        (data[1].in_count / (data[1].in_count + data[1].out_count)) * 100;

      subPercentageValue = currentWeekPercentageValue - lastWeekPercentageValue;
      isPositive =
        subPercentageValue === 0 ? true : subPercentageValue > 0 ? true : false;

      kpiSubDataValue =
        subPercentageValue > 0
          ? data[0].in_count - data[1].in_count
          : data[0].out_count - data[1].out_count;

      noChange = subPercentageValue === 0 ? true : false;
    } else {
      currentWeekPercentageValue =
        (data[0].in_count / (data[0].in_count + data[0].out_count)) * 100;
      lastWeekPercentageValue = 0;
      subPercentageValue = currentWeekPercentageValue - lastWeekPercentageValue;
      isPositive =
        subPercentageValue === 0 ? true : subPercentageValue > 0 ? true : false;
      kpiSubDataValue =
        subPercentageValue > 0 ? data[0].in_count - 0 : data[0].out_count - 0;

      noChange = subPercentageValue === 0 ? true : false;
    }

    productAvailabilityData = {
      percentageData: currentWeekPercentageValue.toFixed(1),
      percentageSubData: subPercentageValue.toFixed(1),
      isPositive: isPositive,
      kpiSubDataValue: kpiSubDataValue,
      noChange: noChange,
    };
  } else {
    productAvailabilityData = {
      percentageData: 0,
      percentageSubData: 0,
      isPositive: true,
      kpiSubDataValue: 0,
      noChange: true,
    };
  }
};

//Function for Seller Analysis Dashboard

export const calculateSellerAnalysisBarChartData = (data) => {
  let total = data.authorizedCount + data.unauthorizedCount;

  let authorizedPercentageData = data.authorizedCount / total;
  let unauthorizedPercentageData = data.unauthorizedCount / total;

  return {
    weekName: data.id,
    authorizedPercentageData: authorizedPercentageData,
    authorisedStringData: data.authorizedCount + " Sellers",
    unauthorizedPercentageData: unauthorizedPercentageData,
    unauthorizedStringData: data.unauthorizedCount + " Sellers",
  };
};

export const calculateSellerAnalysisLineGraphData = (data) => {
  let lineGraphSellerAnalysisData = [];
  let lineGraphSellerAnalysisWeekName;
  let lineGraphSellerAnalysisAuthorizedCountPercentageData,
    lineGraphSellerAnalysisUnauthorizedPercentageCountData;
  let total = 0;

  data.map((key) => {
    total = key.authorizedCount + key.unauthorizedCount;

    lineGraphSellerAnalysisWeekName = key.id;
    lineGraphSellerAnalysisAuthorizedCountPercentageData =
      key.authorizedCount / total;
    lineGraphSellerAnalysisUnauthorizedPercentageCountData =
      key.unauthorizedCount / total;

    lineGraphSellerAnalysisData.push({
      weekName: lineGraphSellerAnalysisWeekName,
      inStockPercentageData: lineGraphSellerAnalysisAuthorizedCountPercentageData,
      outStockPercentageData: lineGraphSellerAnalysisUnauthorizedPercentageCountData,
    });

    return null;
  });

  return lineGraphSellerAnalysisData;
};

export const calculateSellerAnalysisTableData = (data) => {
  let tableData = [];

  let tableDataName;
  let total = 0;
  let tableAuthorizedPercentageData, tableUnauthorizedPercentageData;
  let tableAuthorizedStringData, tableUnauthorizedStringData;

  data.map((key) => {
    total = key.authorizedCount + key.unauthorizedCount;
    tableDataName = key.id;
    tableAuthorizedPercentageData = key.authorizedCount / total;
    tableUnauthorizedPercentageData = key.unauthorizedCount / total;
    tableAuthorizedStringData = key.authorizedCount;
    tableUnauthorizedStringData = key.unauthorizedCount;

    tableData.push({
      name: tableDataName,
      authorizedPercentageData: tableAuthorizedPercentageData,
      authorisedStringData: tableAuthorizedStringData,
      unauthorizedPercentageData: tableUnauthorizedPercentageData,
      unauthorizedStringData: tableUnauthorizedStringData,
    });

    return null;
  });

  return tableData;
};

//Function for Calender Calculation

export const calculateToAndFromDateForYear = (date) => {
  let fromDate = date;
  let addedYear = addYears(date, 1);
  let subDate = subDays(addedYear, 1);
  let toDate = subDate;

  return {
    fromDate:
      fromDate.getFullYear() +
      "-" +
      (fromDate.getMonth() + 1) +
      "-" +
      fromDate.getDate(),
    toDate:
      toDate.getFullYear() +
      "-" +
      (toDate.getMonth() + 1) +
      "-" +
      toDate.getDate(),
  };
};

export const calculateToAndFromDateForMonth = (date) => {
  let fromDate = date;
  let addedMonths = addMonths(date, 1);
  let subDate = subDays(addedMonths, 1);
  let toDate = subDate;

  return {
    fromDate:
      fromDate.getFullYear() +
      "-" +
      (fromDate.getMonth() + 1) +
      "-" +
      fromDate.getDate(),
    toDate:
      toDate.getFullYear() +
      "-" +
      (toDate.getMonth() + 1) +
      "-" +
      toDate.getDate(),
  };
};

export const calculateToAndFromDateForQuaterly = (date) => {
  let fromDate = date;
  let addedMonths = addMonths(date, 3);
  let subDate = subDays(addedMonths, 1);
  let toDate = subDate;

  return {
    fromDate:
      fromDate.getFullYear() +
      "-" +
      (fromDate.getMonth() + 1) +
      "-" +
      fromDate.getDate(),
    toDate:
      toDate.getFullYear() +
      "-" +
      (toDate.getMonth() + 1) +
      "-" +
      toDate.getDate(),
  };
};

export const calculateFromAndToDateForWeekly = (date) => {
  let subValue, fromDate, toDate, addDate, subDate;

  switch (date.getDay()) {
    case 0:
      subValue = 0;
      break;
    case 1:
      subValue = 1;
      break;
    case 2:
      subValue = 2;
      break;
    case 3:
      subValue = 3;
      break;
    case 4:
      subValue = 4;
      break;
    case 5:
      subValue = 5;
      break;
    case 6:
      subValue = 6;
      break;
    default:
      subValue = 0;
  }
  subDate = subDays(date, subValue);
  addDate = addDays(subDate, 6);
  fromDate = subDate;
  toDate = addDate;

  return {
    fromDate:
      fromDate.getFullYear() +
      "-" +
      (fromDate.getMonth() + 1) +
      "-" +
      fromDate.getDate(),
    toDate:
      toDate.getFullYear() +
      "-" +
      (toDate.getMonth() + 1) +
      "-" +
      toDate.getDate(),
  };
};

export const calculateWeekNumber = (date) => {
  let weekNum = 0;

  var oneJan = new Date(date.getFullYear(), 0, 1);

  var numberOfDays = Math.floor((date - oneJan) / (24 * 60 * 60 * 1000));

  weekNum = Math.ceil((date.getDay() + 1 + numberOfDays) / 7);

  return weekNum;
};

export const getFormatedDates = (date, timeline) => {
  console.log(date, timeline);
  if (timeline === "Weekly") {
    const dates = calculateFromAndToDateForWeekly(date);
    return {
      from: dates.from,
      to: dates.to,
    };
  } else if (timeline === "Monthly") {
    const dates = calculateToAndFromDateForMonth(date);
    return {
      from: dates.from,
      to: dates.to,
    };
  } else if (timeline === "Quaterly") {
    const dates = calculateToAndFromDateForQuaterly(date);
    return {
      from: dates.from,
      to: dates.to,
    };
  } else if (timeline === "Yearly") {
    const dates = calculateToAndFromDateForYear(date);
    return {
      from: dates.from,
      to: dates.to,
    };
  }
};
