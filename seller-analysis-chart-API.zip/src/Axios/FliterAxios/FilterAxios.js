import axios from "axios";

export const getData = (dataObject, authorizedToken) => {
  const options = {
    headers: { authorization: "token " + authorizedToken },
  };
  return axios.post("https://10.100.23.33:3001/filter", dataObject, options);
};
export const getDataFromKpi = (dataObject, token) => {
  const options = {
    headers: { authorization: "token " + token },
  };
  return axios.post("https://10.100.23.33:3001/kpibutton", dataObject, options);
};
export const forgotPassword = (email) => {
  const data = {
    email: email,
  };
  return axios.post("https://10.100.23.33:3001/forgot", data);
};

export const getDataFromDefault = (dataObject, authorizedToken) => {
  console.log(authorizedToken);
  const options = {
    headers: { authorization: "token " + authorizedToken },
  };
  return axios.post("https://10.100.23.33:3001/default", dataObject, options);
};

export const getKPIData = (
  kpiName,
  timeline,
  category,
  sellerType,
  platform,
  country,
  seller,
  from,
  to,
  count,
  token
) => {
  console.log({
    kpiName,
    timeline,
    category,
    sellerType,
    platform,
    country,
    seller,
    from,
    to,
    count,
    token,
  });
  const data = {
    kpiName: kpiName,
    params: {
      periodicity: timeline.toLowerCase(),
      category: category.toLowerCase(),
      platform: platform.toLowerCase(),
      country: country.toLowerCase(),
      seller: seller.toLowerCase(),
      sellerType: sellerType.toLowerCase(),
      count: count,
      dateFilter: {
        from: from,
        to: to,
      },
    },
  };
  const options = {
    headers: { authorization: "token " + token },
  };
  return axios.post("https://10.100.23.33:3001/filter", data, options);
};
