export const mainApi = {
  token:
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImFkbWluQGVjbGVyeC5jb20iLCJyb2xlIjoiYWRtaW4iLCJkYXRlIjoiMjAyMC0wNy0xNVQxMjo1Mjo0NS4yMDNaIiwiaWF0IjoxNTk0ODE3NTY1LCJleHAiOjE1OTQ4MjExNjV9.AGc-FObF5oBBnStXZ0-84bUsO6dMXuJVHkdxQ6QfOIA",
};
