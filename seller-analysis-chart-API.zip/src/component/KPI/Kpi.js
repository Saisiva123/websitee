import React, { Component } from "react";
import classes from "./Kpi.module.css";
import KpiTabs from "./KpiTabs/KpiTabs";
import { connect, useDispatch } from "react-redux";
import { setKpiData, onTabSelected } from "../../store/action/kpiAction";


class Kpi extends Component {

  state = {
    HP_DATA: [
      {
        Availability: "Yes",
        Country: "India",
        Listing: "Yes",
        Refurbished: "Original",
      },
      {
        Availability: "Yes",
        Country: "India",
        Listing: "Yes",
        Refurbished: "Original",
      },
      {
        Availability: "No",
        Country: "India",
        Listing: "Yes",
        Refurbished: "Original",
      },
    ],
  };

  componentWillMount() {
    this.props.onKpiData(this.state.HP_DATA);
  }

  render() {
    //let tabs = <Spinner />

    // if(!this.props.loading)
    // {

     // const dispatch=useDispatch();
      let tabs=this.props.tabsData.map((data) => {
        return (
          <KpiTabs
            key={data.title}
            link={data.link}
            positiveCheck={data.isPositive}
            title={data.title}
            noChangeData={data.noChange}
            description={data.toolTipDescription}
            percentageValue={data.percentageData}
            percentageSubData={data.percentageSubData}
            productShortDesc={data.kpiSubData}
            //added newclick operation for loader
            //onClick={()=>dispatch(LoaderAction(true))}
            click={() => this.props.onTabSelected(data.link)}
            
          />
        );
      });
    //}

    return (
      <div className={classes.mainContainer}>
        <div className={classes.Kpi}>{tabs}</div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    loading:state.kpi.loading,
    tabsData: state.kpi.KpiButtonData,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onKpiData: (data) => dispatch(setKpiData(data)),
    onTabSelected: (path) => dispatch(onTabSelected(path)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Kpi);
