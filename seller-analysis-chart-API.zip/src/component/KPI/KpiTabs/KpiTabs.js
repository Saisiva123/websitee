import React, { useState } from "react";
import classes from "./KpiTabs.module.css";
import Tooltip from "@material-ui/core/Tooltip";
import { NavLink } from "react-router-dom";
import { withStyles } from '@material-ui/core/styles';
import TooltipIconImage from "../../../assets/Icon/KpiButtonTooltipIcon.png";
import { connect } from "react-redux";
import { onTabSelected } from "../../../store/action/kpiAction";

const KpiTabs = (props) => {
  const tooltipData = props.description.map((data) => <p>{data}</p>);

  const [open, setOpen] = React.useState(false);

  const handleTooltipClose = () => {
    setOpen(false);
  };

  const handleTooltipOpen = () => {
    setOpen(true);
  };

 
  return (
    <div className={classes.KpiTabs}>
      <NavLink
        style={{textDecoration:'none'}}
        activeClassName={classes.active}
        to={props.link}
        onClick={props.click}
        onClick={props.setBreadCrumData}
      >
        <div className={classes.TabData}>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <p className={classes.Title}>{props.title}</p>
            <Tooltip
              
              disableTouchListener
              onClose={handleTooltipClose}
              open={open}
              title={
                <div
                  style={{
                    width: 200,
                    textAlign: "start",
                  }}
                >
                  {tooltipData}
                </div>
              }
              arrow
            >
              <img
                onClick={handleTooltipOpen}
                src={TooltipIconImage}
                style={{
                  width: "16px",
                  height: "16px",
                  
                  justifyContent: "center",
                }}
                alt="Tooltip"
              />
            </Tooltip>
          </div>
          <div
            style={{
              display: "flex",
              margin: "13px 0 0 0",
              borderBottom: "0.5px solid #eee",
            }}
          >
            <p className={classes.PercentageData}>{props.percentageValue}</p>
            <div
              style={{
                backgroundColor: props.positiveCheck
                  ? "#06B754"
                  : props.noChangeData
                  ? "#000000AB"
                  : "red",
              }}
              className={classes.GreenCircle}
            ></div>
            <p
              style={{
                color: props.positiveCheck
                  ? "#06B754"
                  : props.noChangeData
                  ? "#000000AB"
                  : "red",
                marginLeft: "4px",
              }}
              className={classes.ProductSubData}
            >
              {props.percentageSubData}
            </p>
          </div>
          <p
            style={{ color: props.positiveCheck ? "#06B754" : "red" }}
            className={classes.ShortDataDesc}
          >
            {props.productShortDesc}
          </p>
        </div>
      </NavLink>
    </div>
  );
};

const mapDispatchToProps = (dispatch) => {
  return {
    setCurrentKpi: (path) => dispatch(onTabSelected(path)),
  };
};

export default connect(null, mapDispatchToProps)(KpiTabs);
