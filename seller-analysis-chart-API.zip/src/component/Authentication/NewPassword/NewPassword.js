import React from "react";
import classes from "./NewPassword.module.css";
import TextField from "@material-ui/core/TextField";
import InputAdornment from "@material-ui/core/InputAdornment";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";
import useMediaQuery from "@material-ui/core/useMediaQuery";
import IconButton from "@material-ui/core/IconButton";
import Button from "@material-ui/core/Button";
import { Redirect } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import ChangePasswordValidity from "../ChangePassword/ChangePasswordValidity/ChangePasswordValidity";
import { checkValidity, checkConfirmPassword } from "../../../Utils/Utils";
import CircularProgress from "@material-ui/core/CircularProgress";
import AuthHeader from "../AuthHeader/AuthHeader";
import WaveComponent from "../WaveComponent/WaveComponent";
import {
  setPassword,
  resetSetPassword,
} from "../../../store/action/authAction";

const NewPassword = () => {
  const dispatch = useDispatch();
  const authData = useSelector((state) => state.authentication);
  const isMobile = useMediaQuery("(max-width:767px)");

  const [values, setValues] = React.useState({
    newPassword: "",
    confirmNewPassword: "",
    isConfirmPasswordTouched: false,
    isConfirmPasswordValid: false,
    newPasswordTouched: false,
    showNewPassword: false,
    showConfirmNewPassword: false,
    isNewPasswordLengthValid: false,
    isNewPasswordCharacterValid: false,
    isNewPasswordSymbolValid: false,
  });

  let redirect = null;

  if (authData.setPassword.message.length > 0) {
    setTimeout(() => {
      dispatch(resetSetPassword());
      redirect = <Redirect to="/login" />;
    }, 1500);
  }

  const handleChange = (prop) => (event) => {
    if (prop === "newPassword") {
      var data = checkValidity(event.target.value, "changePassword");
      setValues({
        ...values,
        newPasswordTouched: true,
        isConfirmPasswordValid: checkConfirmPassword(
          event.target.value,
          values.confirmNewPassword
        ),
        isNewPasswordLengthValid: data.isLengthValid,
        isNewPasswordCharacterValid: data.isCharacterValid,
        isNewPasswordSymbolValid: data.isDigitAndSymbolValid,
        newPassword: event.target.value,
      });
    }
    if (prop === "confirmNewPassword") {
      setValues({
        ...values,
        isConfirmPasswordTouched: true,
        isConfirmPasswordValid: checkConfirmPassword(
          values.newPassword,
          event.target.value
        ),
        confirmNewPassword: event.target.value,
      });
    }
  };

  const handlChangePasswordSubmit = (event) => {
    event.preventDefault();
    if (values.newPassword.length === 0) {
      setValues({
        ...values,
        newPasswordTouched: true,
        isNewPasswordLengthValid: false,
        isNewPasswordCharacterValid: false,
        isNewPasswordSymbolValid: false,
      });
    } else if (values.confirmNewPassword.length === 0) {
      setValues({
        ...values,
        isConfirmPasswordTouched: true,
        isConfirmPasswordValid: false,
      });
    } else if (
      values.isNewPasswordLengthValid &&
      values.isNewPasswordCharacterValid &&
      values.isNewPasswordSymbolValid &&
      values.isConfirmPasswordValid
    ) {
      if (authData.loginData.token !== null) {
        setPassword(authData.loginData.token, values.newPassword);
      }
    }
  };

  const handleClickShowNewPassword = () => {
    setValues({ ...values, showNewPassword: !values.showNewPassword });
  };
  const handleClickShowConfirmNewPassword = () => {
    setValues({
      ...values,
      showConfirmNewPassword: !values.showConfirmNewPassword,
    });
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100vh",
        overflow: "auto",
      }}
    >
      {redirect}
      <AuthHeader />
      <div className={classes.NewPasswordCard}>
        <p className={classes.NewPasswordTitle}>Set New Password</p>
        <form
          style={{ width: "100%", display: "flex", flexDirection: "column" }}
        >
          <TextField
            style={{
              margin: isMobile ? "20px 13px 0 13px" : "32px 38px 0 38px",
            }}
            error={
              !values.newPasswordTouched
                ? false
                : values.isNewPasswordLengthValid &&
                  values.isNewPasswordCharacterValid &&
                  values.isNewPasswordSymbolValid
                ? false
                : true
            }
            placeholder="New password"
            type={values.showNewPassword ? "text" : "password"}
            value={values.newPassword}
            onChange={handleChange("newPassword")}
            variant="outlined"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <img className={classes.PasswordIcon} alt="Icon" />
                </InputAdornment>
              ),
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    aria-label="toggle password visibility"
                    onClick={handleClickShowNewPassword}
                    onMouseDown={handleMouseDownPassword}
                    edge="end"
                  >
                    {values.showNewPassword ? (
                      <Visibility />
                    ) : (
                      <VisibilityOff />
                    )}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
          <TextField
            style={{
              margin: isMobile ? "20px 13px 0 13px" : "32px 38px 0 38px",
            }}
            error={
              !values.isConfirmPasswordTouched
                ? false
                : values.isConfirmPasswordValid
                ? false
                : true
            }
            helperText={
              !values.isConfirmPasswordTouched
                ? ""
                : values.isConfirmPasswordValid
                ? ""
                : "Confirm password not matches with new password"
            }
            placeholder="Retype new password"
            type={values.showConfirmNewPassword ? "text" : "password"}
            value={values.confirmNewPassword}
            onChange={handleChange("confirmNewPassword")}
            variant="outlined"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <img className={classes.PasswordIcon} alt="Icon" />
                </InputAdornment>
              ),
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    aria-label="toggle password visibility"
                    onClick={handleClickShowConfirmNewPassword}
                    onMouseDown={handleMouseDownPassword}
                    edge="end"
                  >
                    {values.showConfirmNewPassword ? (
                      <Visibility />
                    ) : (
                      <VisibilityOff />
                    )}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
          <div
            style={{
              margin: isMobile ? "6px 13px 0 13px" : "12px 38px 0 38px",
              display: !values.newPasswordTouched
                ? "none"
                : values.isNewPasswordLengthValid &&
                  values.isNewPasswordCharacterValid &&
                  values.isNewPasswordSymbolValid
                ? "none"
                : "",
            }}
          >
            <ChangePasswordValidity
              valid={values.isNewPasswordLengthValid}
              content={"At least 8 characters long."}
            />
            <ChangePasswordValidity
              valid={values.isNewPasswordCharacterValid}
              content={"Include both upper and lower characters."}
            />
            <ChangePasswordValidity
              valid={values.isNewPasswordSymbolValid}
              content={"One number,symbol or whitespace character."}
            />
          </div>
          <Button
            onClick={handlChangePasswordSubmit}
            variant="contained"
            style={{
              margin: isMobile ? "20px 13px" : "30px 38px",
              backgroundColor: "#1F6283",
              color: "white",
              textTransform: "capitalize",
            }}
          >
            {!authData.loading ? (
              "Submit"
            ) : (
              <CircularProgress
                style={{ color: "blue", width: 30, height: 30 }}
              />
            )}
          </Button>
          {authData.setPassword.error !== null ? (
            <p style={{ color: "red" }}>Something went wrong</p>
          ) : authData.setPassword.message.length > 0 ? (
            <p style={{ color: "green" }}>Password set successfully</p>
          ) : null}
        </form>
      </div>
      <WaveComponent />
    </div>
  );
};

export default NewPassword;
