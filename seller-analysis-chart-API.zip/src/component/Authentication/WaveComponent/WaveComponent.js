import React from 'react';
import classes from './WaveComponent.module.css';
const WaveComponent = () => <img className={classes.WaveImage} alt="Wave" />
export default WaveComponent;