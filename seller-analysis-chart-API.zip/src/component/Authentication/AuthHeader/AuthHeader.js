import React from 'react';
import classes from "./AuthHeader.module.css";
const AuthHeader = (props) => {
    return (
        <div className={classes.LoginNav}>
        <p className={classes.ProductTitle}>
          market<span style={{ color: "#1F6283" }}>360</span>
        </p>
        <img className={classes.EclerxLogo} alt="Eclerx Logo" />
      </div>
    );
}

export default AuthHeader;