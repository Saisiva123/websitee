import React from "react";


const ChangePasswordValidity = (props) => {
  return (
    <div style={{display:'flex',alignItems:'center'}}>
      <div
        style={{
          width: 10,
          height: 10,
          display:'inline-block',
          borderRadius: "50%",
          backgroundColor: props.valid ? "green" : "red",
        }}
      ></div>
      <p
        style={{
          margin: "0 0 0 10px",
          fontFamily: "Open Sans",
          display:'inline-block',
          color: props.valid ? "black" : "red",
          fontSize: "12px",
        }}
      >
        {props.content}
      </p>
    </div>
  );
};

export default ChangePasswordValidity;
