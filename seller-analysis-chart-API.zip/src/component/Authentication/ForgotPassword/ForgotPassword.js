import React, { useState } from "react";
import AuthHeader from "../AuthHeader/AuthHeader";
import classes from "./ForgotPassword.module.css";
import TextField from "@material-ui/core/TextField";
import InputAdornment from "@material-ui/core/InputAdornment";
import Button from "@material-ui/core/Button";
import useMediaQuery from "@material-ui/core/useMediaQuery";
import { Link, useHistory } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import WaveComponent from "../WaveComponent/WaveComponent";
import { checkValidity } from "../../../Utils/Utils";
import CircularProgress from "@material-ui/core/CircularProgress";
import {
  submitForgotMail,
  resetErrorState,
} from "../../../store/action/authAction";

const ForgotPassword = (props) => {
  const isMobile = useMediaQuery("(max-width:767px)");
  const dispatch = useDispatch();
  const history = useHistory();
  const authData = useSelector((state) => state.authentication);
  const [values, setValues] = React.useState({
    isEmailTouched: false,
    isEmailValid: false,
    emailAddress: "",
  });

  const handleChange = (event) => {
    setValues({
      isEmailTouched: true,
      isEmailValid: checkValidity(event.target.value, "email"),
      emailAddress: event.target.value,
    });
  };

  const onForgotMailSubmit = (event) => {
    event.preventDefault();

    if (values.emailAddress.length === 0) {
      setValues({ ...values, isEmailTouched: true, isEmailValid: false });
    }
    if (values.isEmailValid) {
      dispatch(submitForgotMail(values.emailAddress));
    }
  };

  const handleAlertClose = (event) => {
    dispatch(resetErrorState());
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100vh",
        overflow: "auto",
      }}
    >
      <AuthHeader />

      <div className={classes.ForgotPasswordCard}>
        <p className={classes.ForgotPasswordTitle}>Forgot Password</p>
        <p className={classes.ForgotPasswordSubTitle}>
          Forgot your password? Enter the email address of your account to reset
          your password.
        </p>
        <form
          style={{ width: "100%", display: "flex", flexDirection: "column" }}
        >
          <TextField
            error={
              !values.isEmailTouched
                ? false
                : values.isEmailValid
                ? false
                : true
            }
            style={{
              margin: isMobile ? "25px 13px 0 13px" : "32px 38px 0 38px",
            }}
            placeholder="E-mail Address"
            type="text"
            value={values.emailAddress}
            onChange={handleChange}
            variant="outlined"
            helperText={
              !values.isEmailTouched
                ? ""
                : values.isEmailValid
                ? ""
                : "Please enter a valid email address."
            }
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <img className={classes.EmailIcon} alt="Icon" />
                </InputAdornment>
              ),
            }}
          />
          <div className={classes.ButtonContainer}>
            <Button
              disabled={authData.loading ? true : false}
              onClick={() => {
                history.push("/login")
                dispatch(resetErrorState());
              }}
              
              variant="outlined"
              style={{
                width: "48%",
                border: "1px solid #1F6283",
                color: "#1F6283",
                textTransform: "capitalize",
              }}
            >
              Cancel
            </Button>

            <Button
              onClick={onForgotMailSubmit}
              variant="contained"
              disabled={authData.loading ? true : false}
              style={{
                width: "48%",
                backgroundColor: "#1F6283",
                color: "white",
                textTransform: "capitalize",
              }}
            >
              {authData.loading ? (
                <CircularProgress
                  style={{ color: "#0096D6", width: 20, height: 20 }}
                />
              ) : (
                "Send"
              )}
            </Button>
          </div>
          {authData.forgotError !== null ? (
            <p style={{ color: "red", textAlign: "center" }}>
              Something went wrong
            </p>
          ) : null}
        </form>
      </div>
      <WaveComponent />
    </div>
  );
};

export default ForgotPassword;
