import React, { useState, useEffect } from "react";
import classes from "./Login.module.css";
import TextField from "@material-ui/core/TextField";
import { makeStyles } from "@material-ui/core/styles";
import InputAdornment from "@material-ui/core/InputAdornment";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";
import IconButton from "@material-ui/core/IconButton";
import Checkbox from "@material-ui/core/Checkbox";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Button from "@material-ui/core/Button";
import useMediaQuery from "@material-ui/core/useMediaQuery";
import AuthHeader from "../AuthHeader/AuthHeader";
import { Link, useHistory, Redirect } from "react-router-dom";
import { checkValidity } from "../../../Utils/Utils";
import WaveComponent from "../WaveComponent/WaveComponent";
import { useSelector, useDispatch } from "react-redux";
import CircularProgress from "@material-ui/core/CircularProgress";
import { login } from "../../../store/action/authAction";

const useStyles = makeStyles({
  label: {
    color: "#727272",
    fontSize: "15px",
    fontFamily: "Open Sans",
  },
  colorPrimary: {
    color: "#1F6283",
  },
});

const Login = (props) => {
  const abc = useStyles();
  const history = useHistory();
  const dispatch = useDispatch();
  const authData = useSelector((state) => state.authentication);
  const isMobile = useMediaQuery("(max-width:767px)");

  const [values, setValues] = React.useState({
    emailAddress: "",
    password: "",
    isEmailValid: false,
    isEmailTouched: false,
    passwordValid: true,
    showPassword: false,
    rememberMe: false,
  });

  const handleChange = (prop) => (event) => {
    if (prop === "emailAddress") {
      setValues({
        ...values,
        isEmailTouched: true,
        isEmailValid: checkValidity(event.target.value, "email"),
        emailAddress: event.target.value,
      });
    }
    if (prop === "password") {
      setValues({
        ...values,
        password: event.target.value,
      });
    }
  };

  const handleClickShowPassword = () => {
    setValues({ ...values, showPassword: !values.showPassword });
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };
  const checkBoxHandle = (event) => {
    setValues({ ...values, rememberMe: event.target.checked });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (values.password.length === 0) {
      setValues({ ...values, passwordValid: false });
    }
    if (values.emailAddress.length === 0) {
      setValues({ ...values, isEmailTouched: true, isEmailValid: false });
    }
    if (values.isEmailValid && values.password.length > 0) {
      dispatch(login(values.emailAddress, values.password));
      //history.push("/dashboard");
    }
  };

  useEffect(() => {}, []);

  let errorData = null;
  let formButtonData = (
    <CircularProgress style={{ color: "#0096D6", width: 30, height: 30 }} />
  );

  if (!authData.loading) {
    formButtonData = "Submit";
  }
  if (authData.error !== null) {
    errorData = <p style={{ textAlign: "center",color:'red'}}>{authData.error}</p>;
  }

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100vh",
        overflow: "auto",
      }}
    >
      {authData.loginData.token !== null ? <Redirect to="/dashboard" /> : null}
      <AuthHeader />

      <div className={classes.LoginCard}>
        <p className={classes.LoginCardTitle}>Login</p>
        <form
          style={{ width: "100%", display: "flex", flexDirection: "column" }}
        >
          <TextField
            error={
              !values.isEmailTouched
                ? false
                : values.isEmailValid
                ? false
                : true
            }
            style={{
              margin: isMobile ? "25px 13px 0 13px" : "45px 38px 0 38px",
            }}
            placeholder="Username"
            type="text"
            value={values.emailAddress}
            onChange={handleChange("emailAddress")}
            variant="outlined"
            helperText={
              !values.isEmailTouched
                ? ""
                : !values.isEmailValid
                ? "Please enter valid email address"
                : ""
            }
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <img className={classes.EmailIcon} alt="emailIcon" />
                </InputAdornment>
              ),
            }}
          />
          <TextField
            style={{
              margin: isMobile ? "25px 13px 0 13px" : "45px 38px 0 38px",
            }}
            placeholder="Password"
            error={values.passwordValid ? false : true}
            helperText={
              !values.passwordValid ? "Password can not be empty" : ""
            }
            type={values.showPassword ? "text" : "password"}
            value={values.password}
            onChange={handleChange("password")}
            variant="outlined"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <img className={classes.PasswordIcon} alt="emailIcon" />
                </InputAdornment>
              ),
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    aria-label="toggle password visibility"
                    onClick={handleClickShowPassword}
                    onMouseDown={handleMouseDownPassword}
                    edge="end"
                  >
                    {values.showPassword ? <Visibility /> : <VisibilityOff />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />

          <div className={classes.RememberMeContainer}>
            <FormControlLabel
              classes={{
                label: abc.label,
              }}
              style={{ margin: "0" }}
              control={
                <Checkbox
                  classes={{
                    colorPrimary: abc.colorPrimary,
                  }}
                  checked={values.rememberMe}
                  onChange={checkBoxHandle}
                  name="checkedB"
                  color="primary"
                />
              }
              label="Remember Me"
            />
            <Link to="/forgotpassword">
              <p className={classes.ForgotPassword}>Forgot Password?</p>
            </Link>
          </div>

          <Button
            variant="contained"
            onClick={handleSubmit}
            style={{
              margin: isMobile ? "25px 13px" : "38px",
              backgroundColor: "#1F6283",
              color: "white",
              textTransform: "capitalize",
            }}
          >
            {formButtonData}
          </Button>
          {errorData}
        </form>
      </div>
      <WaveComponent />
    </div>
  );
};

export default Login;
