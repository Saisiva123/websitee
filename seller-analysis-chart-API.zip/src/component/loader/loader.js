import React, { useEffect, useState } from "react";
import "./loader.css";
import { useSelector, useDispatch } from "react-redux";
import { LoaderAction } from "../../store/action/loaderAction";

export default function Loader() {
  var showLoader = useSelector((state) => state.loader);
  var load=showLoader.loading;
  var dispatch = useDispatch();

  useEffect(() => {
    setTimeout(() => dispatch(LoaderAction(false)), 1000);
  }, [load]);

  return (
    <div
      style={load ? { display: "block" } : { display: "none" }}
      className="overlayForLoader"
    >
      <div className="loaderComponent"></div>
    </div>
  );
}
