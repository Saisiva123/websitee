import React from "react";
import classes from "./NavigationItems.module.css";
import logo from "../../assets/images/logo.png";
import NavigationItem from "./NavigationItem/NavigationItem";
import { Route, Redirect, Link, useHistory } from "react-router-dom";
import Popover from "@material-ui/core/Popover";
import OverView from "../OverView/Overview";
import Kpi from "../KPI/Kpi";
import { useSelector, useDispatch } from "react-redux";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import AccountCircleIcon from "@material-ui/icons/AccountCircle";
import { setChangePasswordDialog } from "../../store/action/header-action";
import { logout } from "../../store/action/authAction";

const NavigationItems = (props) => {
  const history = useHistory();
  const dispatch = useDispatch();
  const data = useSelector((state) => state.priceChange);
  const authData = useSelector((state) => state.authentication);
  const sellerData = useSelector((state) => state.sellerAnalysis);
  const [anchorEl, setAnchorEl] = React.useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleChangePasswordClick = (event) => {
    event.preventDefault();
    setAnchorEl(null);
    dispatch(setChangePasswordDialog(true));
  };

  let redirect = null;

  if (authData.loginData.token === null) {
    redirect = <Redirect to={"/login"} />;
  }

  const open = Boolean(anchorEl);
  const id = open ? "simple-popover" : undefined;

  const handleLogout = () => {
    dispatch(logout());
  };

  return (
    <div className={classes.MainHeader}>
      {redirect}
      <nav className={classes.Navbar}>
        <img src={logo} alt="Logo" className={classes.Logo} />
        <p className={classes.LogoTitle}>Market360</p>
        <div
          style={{
            display: "flex",
            height: "100%",
            width: "100%",
            justifyContent: "space-between",
            alignItems: "center",
            overflow: "auto",
          }}
        >
          <ul className={classes.NavigationItems}>
            <NavigationItem link={"/dashboard/overview/"} exact>
              Overview
            </NavigationItem>
            <NavigationItem link={"/dashboard/promotion-analysis"} exact>
              Promotion Analysis
            </NavigationItem>
            <NavigationItem link={"/dashboard/brand-registry"} exact>
              Brand Registry
            </NavigationItem>
            {authData.loginData.role === "admin" ? (
              <React.Fragment>
                <NavigationItem link={"/dashboard/user-management"} exact>
                  User Management
                </NavigationItem>
                <NavigationItem link={"/dashboard/data-import"} exact>
                  Upload Data
                </NavigationItem>
              </React.Fragment>
            ) : null}
            {/* <NavigationItem link={"/dashboard/user-management"} exact>
              User Management
            </NavigationItem>
            <NavigationItem link={"/dashboard/data-import"} exact>
              Upload Data
            </NavigationItem> */}
          </ul>

          <div className={classes.ProfileContainer}>
            <div onClick={handleClick}>
              <AccountCircleIcon />
              <p
                style={{
                  display: "inline-block",
                  fontSize: "14px",
                  color: "#172B4D",
                  margin: "0 0 0 8px",
                }}
              >
                {authData.loginData.firstName +
                  " " +
                  authData.loginData.lastName}
              </p>
              <ExpandMoreIcon />
            </div>
            <Popover
              id={id}
              open={open}
              anchorEl={anchorEl}
              onClose={handleClose}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "center",
              }}
              transformOrigin={{
                vertical: "top",
                horizontal: "center",
              }}
            >
              <div>
                <div
                  className={classes.changePasswordContainer}
                  onClick={handleChangePasswordClick}
                >
                  <img className={classes.changePasswordImg} />
                  <p
                    style={{
                      margin: "0 15px auto 0",
                      fontSize: "14px",
                      fontFamily: "Open Sans",
                      fontWeight: "600",
                      color: "#0096D6",
                    }}
                  >
                    Change Password
                  </p>
                </div>

                <div className={classes.logoutContainer} onClick={handleLogout}>
                  <img className={classes.logoutImg} />
                  <p
                    style={{
                      margin: "0 15px auto 0",
                      fontSize: "14px",
                      fontFamily: "Open Sans",
                      color: "#666666",
                    }}
                  >
                    Logout
                  </p>
                </div>
              </div>
            </Popover>
          </div>
        </div>
      </nav>

      <Route
        path={"/dashboard/overview"}
        render={() => (
          <React.Fragment>
            <OverView />
            {data.currentCategory !== "sku" &&
            sellerData.currentCategory !== "seller" ? (
              <Kpi />
            ) : null}
          </React.Fragment>
        )}
      />
    </div>
  );
};

export default NavigationItems;
