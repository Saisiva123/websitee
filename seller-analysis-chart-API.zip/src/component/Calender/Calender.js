import React from "react";
import DatePicker from "react-datepicker";
import classes from "./Calender.module.css";
import "react-datepicker/dist/react-datepicker.css";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import './Calender.css';

const calender = (props) => {
  const ExampleCustomInput = ({ value, onClick }) => (
    <div>
      <input type="text" value={value} className={"InputContainer"} onClick={onClick} />
      <ExpandMoreIcon style={{ color: "#0096D6" }} onClick={onClick} />
    </div>
  );

  return (
    <React.Fragment>
      {
        <DatePicker
          className={classes.DatePicker}
          maxDate={new Date()}
          selected={props.selected}
          onChange={props.onChange}
          dateFormat="dd/MM/yyyy"
          showMonthYearPicker={
            props.currentTimeline === "Monthly" ? true : false
          }
          showWeekNumbers={
            props.currentTimeline === "Weekly" || props.currentTimeline === ""
              ? true
              : false
          }
          showQuarterYearPicker={
            props.currentTimeline === "Quaterly" ? true : false
          }
          showYearPicker={props.currentTimeline === "Yearly" ? true : false}
          customInput={<ExampleCustomInput />}
        />
      }
    </React.Fragment>
  );
};

export default calender;
