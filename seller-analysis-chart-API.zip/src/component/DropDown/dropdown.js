import React from "react";
import { StylesProvider } from "@material-ui/styles";
import { useQuery } from "../ContentComponent/utils";
import { makeStyles } from "@material-ui/core/styles";
import FormControl from "@material-ui/core/FormControl";
import MenuItem from "@material-ui/core/MenuItem";
import Select from "@material-ui/core/Select";
import { Link } from "react-router-dom";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";

const useStyles = makeStyles((theme) => ({
  formControl: {
    margin: "0 8px",
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
  icon: {
    color: "#0096D6",
  },
  nativeInput:{
    padding:'0'
  }
}));

function Dropdown(props) {
  const classes = useStyles();

  const updatedQuery = useQuery();

  const dropDownOptions = props.data.map((item) => {
    if (props.type === "country" || props.type === "platform") {
      return (
        <MenuItem
          key={item}
          value={item}
          onClick={() => props.onSelectItem(item)}
        >
          <Link
            className="tag"
            style={{ textDecoration: "none", color: "#000000DD" }}
            to={getUrl(item, props.type)}
          >
            {item}
          </Link>
        </MenuItem>
      );
    } else {
      return (
        <MenuItem
          key={item}
          value={item}
          onClick={() => props.onSelectItem(item)}
        >
          {item}
        </MenuItem>
      );
    }
  });

  function getUrl(label, type) {
    let query = "";
    if (type === "country") {
      query = "?country=" + label;
    } else if (type === "platform") {
      query = "?country=" + updatedQuery.get("country") + "&platform=" + label;
    } else if (type === "categories") {
      query =
        "?country=" +
        updatedQuery.get("country") +
        "&platform=" +
        updatedQuery.get("platform");
    } else if (type === "seller") {
      query =
        "?country=" +
        updatedQuery.get("country") +
        "&platform=" +
        updatedQuery.get("platform");
    }
    return query;
  }

  return (
    <FormControl className={classes.formControl} >
      <Select
        style={{
          fontSize: 13,
          fontWeight: "bold",
          fontFamily: "Open Sans",
        }}
        classes={{
          icon: classes.icon,
          selectMenu:classes.nativeInput
        }}
        displayEmpty
        disabled={props.allowDisable}
        value={props.value}
        onChange={(event) => props.onSelectItem(event.target.value)}
        disableUnderline={true}
        IconComponent={ExpandMoreIcon}
      >
        <MenuItem value="" disabled={props.disableLabel}>{props.label}</MenuItem>
        {dropDownOptions}
      </Select>
    </FormControl>
  );
}

export default Dropdown;
