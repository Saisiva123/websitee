import React, { useState } from "react";
import classes from "./DataImport.module.css";
import { DropzoneArea } from "material-ui-dropzone";
import Button from "@material-ui/core/Button";
import { makeStyles } from "@material-ui/core/styles";
import LinearProgress from "@material-ui/core/LinearProgress";
import axios from "axios";
const useStyles = makeStyles((theme) => ({
  root: {
    margin: "20px auto 0 auto",
    maxWidth: "502px",
    border: "2px dashed #0096D6",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },

  paragraph: {
    fontSize: "18px",
    fontFamily: "Open Sans",
  },
}));

const DataImport = () => {
  const abc = useStyles();

  const [uploadFile, setFile] = useState(null);
  const [uploadPercentage, setPercentage] = useState(0);
  const [disableCancel, setDisableCancel] = useState(false);
  const [disableUpload, setDisableUpload] = useState(true);

  const handleChange = (files) => {
    if (files.length !== 0) {
      setFile(files[0]);
      setDisableUpload(false);
    }
  };

  const handleCancelUpload = (event) => {
    event.preventDefault();
    setFile(null);
  };

  const handleUploadFileToServer = (event) => {
    event.preventDefault();
    setDisableUpload(true);
    setDisableCancel(true);
    let data = new FormData();
    data.append("file", uploadFile);

    const options = {
      onUploadProgress: (progressEvent) => {
        const { loaded, total } = progressEvent;
        let percent = Math.floor((loaded * 100) / total);
        if (percent < 100) {
          setPercentage(percent);
        }
      },
    };
    axios
      .post(
        "https://run.mocky.io/v3/91b0de6e-72bc-4034-a422-50dec19a12cd",
        data,
        options
      )
      .then((response) => {
        console.log(response);
        setPercentage(100);
        setFile(null);
        setPercentage(0);
        setDisableCancel(false);
      })
      .catch((err) => {
        console.log(err);
        setPercentage(0);
        setFile(null);
        setDisableCancel(false);
      });
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100vh",
        overflow: "auto",
        backgroundColor:'#EBF9FF'
      }}
    >
      <div className={classes.DataImportCard}>
        <p className={classes.DataImportTitle}>Upload Data</p>
        <p className={classes.DataImportSubTitle}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua.
        </p>
        <div
          style={{ width: "100%", display: "flex", flexDirection: "column" }}
        >
          <DropzoneArea
            filesLimit={1}
            showPreviewsInDropzone={false}
            dropzoneText={"Drag and drop files to upload"}
            dropzoneParagraphClass={abc.paragraph}
            acceptedFiles={[".png", "application/vnd.ms-excel", ".xlsx"]}
            classes={{ root: abc.root }}
            onChange={(files) => handleChange(files)}
          />

          {uploadFile !== null ? (
            <div
              style={{
                display: "flex",
                margin: "20px auto 0 auto",
                minWidth: "502px",
              }}
            >
              <img className={classes.fileUploadImg} />
              <div
                style={{
                  display: "flex",
                  marginLeft: "20px",
                  flexDirection: "column",
                  width: "100%",
                }}
              >
                <p
                  style={{
                    margin: "0",
                    fontFamily: "Open Sans",
                    fontSize: "14px",
                  }}
                >
                  {uploadFile.name}
                </p>
                <LinearProgress
                  style={{ marginTop: "10px" }}
                  variant="determinate"
                  value={uploadPercentage}
                />
              </div>
            </div>
          ) : null}

          <div className={classes.ButtonContainer}>
            <Button
              onclick={handleCancelUpload}
              variant="outlined"
              disabled={disableCancel}
              style={{
                width: "48%",
                border: "1px solid #1F6283",
                color: "#1F6283",
                textTransform: "capitalize",
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleUploadFileToServer}
              variant="contained"
              disabled={disableUpload}
              style={{
                width: "48%",
                backgroundColor: "#1F6283",
                color: "white",
                textTransform: "capitalize",
              }}
            >
              Upload
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataImport;
