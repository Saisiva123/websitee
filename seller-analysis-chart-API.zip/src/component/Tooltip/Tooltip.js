import React from "react";
import Tooltip from "@material-ui/core/Tooltip";
import ClickAwayListener from "@material-ui/core/ClickAwayListener";
import TooltipIconImage from "../../assets/Icon/KpiButtonTooltipIcon.png";
import { withStyles } from '@material-ui/core/styles';

const Tooltips = (props) => {
  const [open, setOpen] = React.useState(false);

  const handleTooltipClose = () => {
    setOpen(false);
  };

  const handleTooltipOpen = () => {
    setOpen(true);
  };

  const HtmlTooltip = withStyles((theme) => ({
    tooltip: {
      backgroundColor: "#f5f5f9",
      color: "rgba(0, 0, 0, 0.87)",
      maxWidth: 220,
      fontSize: theme.typography.pxToRem(12),
      border: "1px solid #dadde9",
    },
  }))(Tooltip);

  const tooltipData = props.description.map((data) => <p>{data}</p>);

  return (
    <ClickAwayListener onClickAway={handleTooltipClose}>
      
        <HtmlTooltip
          PopperProps={{
            disablePortal: true,
          }}
          onClose={handleTooltipClose}
          open={open}
          disableFocusListener
          disableHoverListener
          disableTouchListener
          title={<div>{tooltipData}</div>}
          
        >
          <img
            onClick={handleTooltipOpen}
            src={TooltipIconImage}
            style={{
              width: "16px",
              height: "16px",
              margin: "auto 16px",
              justifyContent: "center",
            }}
            alt="Tooltip"
          />
        </HtmlTooltip>
      
    </ClickAwayListener>
  );
};

export default Tooltips;
