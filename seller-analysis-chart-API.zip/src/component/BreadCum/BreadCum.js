import React from "react";
import { makeStyles, withStyles } from "@material-ui/core/styles";
import Breadcrumbs from "@material-ui/core/Breadcrumbs";
import Link from "@material-ui/core/Link";
import Typography from "@material-ui/core/Typography";
import NavigateNextIcon from "@material-ui/icons/NavigateNext";
import { useLocation, Link as ReactLink } from "react-router-dom";

const useStyles = makeStyles(() => ({
  disabled: {
    pointerEvents: "none",
    marginLeft:"10px",
    fontSize:"13px",
    fontFamily:'Open Sans'
  },
  ol:{
    fontSize:'13px',
    fontFamily:'Open Sans'
  }
}));

const WhiteTextTypography = withStyles({
  root: {
    color: "#0096D6",
    fontFamily:"Open Sans",
    fontSize:"13px",
    ["@media (min-width: 1200px)"]: {
      "font-size": "0.938vw"
    },
    ["@media (min-width: 992px) and (max-width: 1199px)"]: {
      "font-size": "1.334vw"
    },
    ["@media (min-width: 768px) and (max-width: 991px)"]: {
      "font-size": "1.615vw"
    },
    ["@media (max-width: 767px)"]: {
      "font-size": "2.3vw"
    },
  }
})(Typography);

function initBs(location) {
  const rs = location.pathname.split("/");
  if (rs[3] === "product-availability") {
    return [
      {
        title: "Product Availability",
        link: "",
      },
      {
        title: "APJ Overview",
        link: "/dashboard/overview/product-availability",
      },
    ];
  }
  return [
    {
      title: rs[3]
        .split("-")
        .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
        .join(" "),
      link: "",
    },
    {
      title: "APJ Overview",
      link: `/dashboard/overview/${rs[3]}`,
    },
  ];
}

function Breadcrumb(props) {
  const styles = useStyles();
  const location = useLocation();

  let bs = initBs(location);
  let obj;
  let rs = location.search
    ? location.search
        .slice(1)
        .split("&")
        .map((s, i) => ({
          title: s.split("=")[1],
        }))
    : [];
  // here array of objects where every object having title...

  //here i will get array of strings beacuse i will use split operator to separate the strings like country=india seller=..& platform=...
  //to which particular path again it moves back
  let lastIdx = 0;
  rs = rs.map((item, i) => {
    let str = location.search;
    let count = (str.match(/&/g) || []).length;
    obj = {
      ...item,
      link:
        count === i
          ? location.pathname + str
          : location.pathname + str.substring(0, str.indexOf("&", lastIdx + 1)),
    };
    lastIdx = str.indexOf("&", lastIdx + 1);
    return obj;
  });
  bs = [...bs, ...rs];

  const breadCrums = bs.map((bp, i) => {
    const last = i === bs.length - 1;
    if (!last) {
      return (
        <Link
          key={bp.title}
          component={ReactLink}
          className={bp.link ? "" : styles.disabled}
          color="inherit"
          to={bp.link}
        >
          {bp.title}
        </Link>
      );
    } else {
      return (
        <WhiteTextTypography color="textPrimary" key={bp.link}>
          {decodeURIComponent(bp.title)}
        </WhiteTextTypography>
      );
    }
  });

  return (
    <Breadcrumbs
    classes={{
      ol:styles.ol
    }}
    separator={<NavigateNextIcon fontSize="14px" />}
      aria-label="breadcrumb"
    >
      {breadCrums}
    </Breadcrumbs>
  );
}

export default Breadcrumb;
