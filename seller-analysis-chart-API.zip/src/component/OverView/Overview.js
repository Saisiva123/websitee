import React, { useState, useEffect } from "react";
import "./overview.css";
import Dropdown from "../DropDown/dropdown";
import BreadCum from "../BreadCum/BreadCum";
import { useDispatch, useSelector } from "react-redux";
import Calender from "../Calender/Calender";

import {
  setTimeLine,
  setCountry,
  setCategory,
  setSellerType,
  setPlatForm,
  setCalenderDate,
} from "../../store/action/header-action";
import {
  SetDefaultApiData,
  calculateWeekNumber,
  calculateFromAndToDateForWeekly,
  calculateToAndFromDateForQuaterly,
  calculateToAndFromDateForMonth,
  calculateToAndFromDateForYear,
} from "../../Utils/Utils";
import { LoaderAction } from "../../store/action/loaderAction";
const OverView = (props) => {
  const dispatch = useDispatch();
  const headerData = useSelector((state) => state.header);
  const authData = useSelector((state) => state.authentication);

  const weeks = ["Weekly", "Monthly", "Quaterly", "Yearly"];
  const [startDate, setStartDate] = useState(new Date());
  const [timeline, updateTimeline] = useState("Weekly");

  const Platform = [
    "Amazon",
    "Lazada",
    "Flipkart",
    "Tokopedia",
    "Shoppee",
    "Paytm Mall",
    "Qoo10",
    "Shop18",
  ];
  const Countries = [
    "India",
    "Australia",
    "Malayasisa",
    "Malesia",
    "Thailand",
    "Indonesia",
    "Malaysia",
    "Philipines",
    "Philippines",
    "Japan",
    "Korea",
    "Singapore",
  ];
  const Categories = ["Supplies"];

  const SellerType = ["Authorized", "Un-Authorized"];

  const calculateCalenderDate = (date) => {
    let calDate = {};
    let weekNumber = 0;
    if (timeline === "Weekly" || timeline === "") {
      weekNumber = calculateWeekNumber(date);
      calDate = calculateFromAndToDateForWeekly(date);
    }
    if (timeline === "Monthly") {
      calDate = calculateToAndFromDateForMonth(date);
    }
    if (timeline === "Quaterly") {
      calDate = calculateToAndFromDateForQuaterly(date);
    }
    if (timeline === "Yearly") {
      calDate = calculateToAndFromDateForYear(date);
    }

    dispatch(setCalenderDate(calDate.fromDate, calDate.toDate, timeline));
  };

  const onChangeDate = (date) => {
    setStartDate(date);
    calculateCalenderDate(date);
  };
  useEffect(() => {
    calculateCalenderDate(startDate);
  }, []);

  return (
    <div className="navbarContent">
      <div id="selectDates">
        <div className="cal_week">
          <img alt="Icon" style={{ marginLeft: "15px" }} />

          <Dropdown
            data={weeks}
            disableLabel={false}
            label=""
            type="period"
            allowDisable={false}
            value={timeline}
            onSelectItem={(item) => {
              updateTimeline(item);
            }}
          />
          <Calender
            selected={startDate}
            onChange={(date) => onChangeDate(date)}
            currentTimeline={timeline}
          />
        </div>
        <div id="categories">
          <p className="FilterTag">Filter By: </p>
          <Dropdown
            disableLabel={false}
            //data={headerData.country}
            data={Countries}
            allowDisable={false}
            value={headerData.selectedCountry}
            label="All Countries"
            className="cal_cmp"
            type="country"
            onSelectItem={(item) => {
              dispatch(setCountry(item));
              dispatch(LoaderAction(true));
            }}
          />

          <Dropdown
            disableLabel={false}
            className=""
            value={headerData.selectedPlatform}
            //data={headerData.platform}
            data={Platform}
            allowDisable={headerData.dropdownsVisiblity.platform}
            type="platform"
            label="All Platforms"
            onSelectItem={(item) => {
              dispatch(setPlatForm(item));
              dispatch(LoaderAction(true));
            }}
          />

          <Dropdown
            disableLabel={false}
            //data={headerData.category}
            data={Categories}
            value={headerData.selectedCategory}
            label="All Categories"
            className=""
            allowDisable={false}
            type="categories"
            onSelectItem={(item) => {
              dispatch(setCategory(item));
              SetDefaultApiData(
                headerData.selectedCountry,
                headerData.selectedPlatform,
                item,
                headerData.selectedSellerType,
                authData.loginData.token,
                dispatch
              );
              dispatch(LoaderAction(true));
            }}
          />

          <Dropdown
            disableLabel={false}
            //data={headerData.sellerType}
            data={SellerType}
            label="All Sellers Types"
            className=""
            type="seller"
            allowDisable={false}
            value={headerData.selectedSellerType}
            onSelectItem={(item) => {
              dispatch(setSellerType(item));
              SetDefaultApiData(
                headerData.selectedCountry,
                headerData.selectedPlatform,
                headerData.selectedCategory,
                item,
                authData.loginData.token,
                dispatch
              );
              dispatch(LoaderAction(true));
            }}
          />
        </div>
      </div>

      <div id="path_content">
        <BreadCum className="path_content_active" />
      </div>
    </div>
  );
};

export default OverView;
//src={"/build/static/media/calender.b966b520.svg"}
