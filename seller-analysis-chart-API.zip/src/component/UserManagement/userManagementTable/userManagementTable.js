import React from "react";
import "./userManagementTable.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import sortIcon from "../../../assets/Icon/funnel.svg";
import BootstrapTable from "react-bootstrap-table-next";
import { TableHeaderColumn, DeleteButton } from 'react-bootstrap-table-next';
import ToolkitProvider from "react-bootstrap-table2-toolkit";
import Grid from "@material-ui/core/Grid";
import cellEditFactory from 'react-bootstrap-table2-editor';
import paginationFactory, {
    PaginationProvider,
    PaginationListStandalone,
    PaginationTotalStandalone,
    SizePerPageDropdownStandalone,
  } from "react-bootstrap-table2-paginator";
  import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import filterFactory, {
  textFilter
} from "react-bootstrap-table2-filter";

const UserManagementTable = () => {
  function handleDelete(x, y) {
    delete x.role;
  }
  const products = [
    {
      role: "Normal User",
      status: "Inactive",
      "first name": "Dileep chalamalasetty",
      "last name": "Sai dileep",
      "email id": "dileep@gmail.com",
      country: "India",
    },
    {
      role: "Normal User",
      status: "Active",
      "first name": "sai chalamalasetty",
      "last name": "Kiran",
      "email id": "dileep@gmail.com",
      country: "India",
    },
    {
      role: "Normal User",
      status: "Inactive",
      "first name": "prasad",
      "last name": "adarsh",
      "email id": "sai@gmail.com",
      country: "Newzealand",
    },
    {
      role: "Normal User",
      status: "Active",
      "first name": "durga",
      "last name": "sai",
      "email id": "shubham@gmail.com",
      country: "Australia",
    },
    {
      role: "Normal User",
      status: "Inactive",
      "first name": "siva",
      "last name": "Sai Kiran",
      "email id": "dileep@gmail.com",
      country: "America",
    },
    {
      role: "Normal User",
      status: "Inactive",
      "first name": "sai",
      "last name": "shubham",
      "email id": "adarsh@gmail.com",
      country: "US",
    },
    {
      role: "Normal User",
      status: "Active",
      "first name": "Dileep chalamalasetty",
      "last name": "Sai Kiran",
      "email id": "dileep@gmail.com",
      country: "South America",
    },
    {
      role: "Normal User",
      status: "Inactive",
      "first name": "sai chalamalasetty",
      "last name": "adu Kiran",
      "email id": "dileep@gmail.com",
      country: "North America",
    },
    {
      role: "Normal User",
      status: "Inactive",
      "first name": "prasad",
      "last name": "durga",
      "email id": "sai@gmail.com",
      country: "Okanda",
    },
    {
      role: "Normal User",
      status: "Active",
      "first name": "durga",
      "last name": "Sai ",
      "email id": "shubham@gmail.com",
      country: "Zimbambve",
    },
    {
      role: "Normal User",
      status: "Inactive",
      "first name": "siva",
      "last name": "Sai Kiran",
      "email id": "dileep@gmail.com",
      country: "Malaysia",
    },
    {
      role: "Normal User",
      status: "Inactive",
      "first name": "sai",
      "last name": "Sai Kiran",
      "email id": "adarsh@gmail.com",
      country: "Okanda",
    },
    {
        role: "Normal User",
        status: "Active",
        "first name": "Dileep chalamalasetty",
        "last name": "Sai Kiran",
        "email id": "dileep@gmail.com",
        country: "South America",
      },
      {
        role: "Normal User",
        status: "Inactive",
        "first name": "sai chalamalasetty",
        "last name": "adu Kiran",
        "email id": "dileep@gmail.com",
        country: "North America",
      },
      {
        role: "Normal User",
        status: "Inactive",
        "first name": "prasad",
        "last name": "durga",
        "email id": "sai@gmail.com",
        country: "Okanda",
      },
      {
        role: "Normal User",
        status: "Active",
        "first name": "durga",
        "last name": "Sai ",
        "email id": "shubham@gmail.com",
        country: "Zimbambve",
      },
      {
        role: "Normal User",
        status: "Inactive",
        "first name": "siva",
        "last name": "Sai Kiran",
        "email id": "dileep@gmail.com",
        country: "Malaysia",
      }
  ];

  let columns = [
    {
      dataField: "role",
      text: "Role",
     // sort: true,
      sortCaret: (order, column) => {
        if (!order) return <img className="sortIcon" src={sortIcon}></img>;
        else if (order === "asc")
          return <img className="sortIcon" src={sortIcon}></img>;
        else if (order === "desc")
          return <img className="sortIcon" src={sortIcon}></img>;
        return null;
      },
      // filter: textFilter({
      //   style: {
      //     marginTop: "10px",
      //   },
      // })
    },
    {
      dataField: "status",
      text: "Status",
     // sort: true,
      headerStyle:{zIndex:1},
      sortCaret: (order, column) => {
        if (!order) return <img className="sortIcon" src={sortIcon}></img>;
        else if (order === "asc")
          return <img className="sortIcon" src={sortIcon}></img>;
        else if (order === "desc")
          return <img className="sortIcon" src={sortIcon}></img>;
        return null;
      },
      formatter: (cell, row, rowIndex) => (
        <div
          className="statusRadio"
          style={cell == "Active" ? { backgroundColor: "#00E022" } : null}
        ></div>
      ),
    //   filter: textFilter({
    //     style: {
    //       marginTop: "10px",
    //     },
    //   }),
    },
    {
      dataField: "first name",
      text: "Fisrt Name",
      sort: true,
      sortCaret: (order, column) => {
        if (!order) return <img className="sortIcon" src={sortIcon}></img>;
        else if (order === "asc")
          return <img className="sortIcon" src={sortIcon}></img>;
        else if (order === "desc")
          return <img className="sortIcon" src={sortIcon}></img>;
        return null;
      },
    },
    {
      dataField: "last name",
      text: "Last Name",
      sort: true,
      sortCaret: (order, column) => {
        if (!order) return <img className="sortIcon" src={sortIcon}></img>;
        else if (order === "asc")
          return <img className="sortIcon" src={sortIcon}></img>;
        else if (order === "desc")
          return <img className="sortIcon" src={sortIcon}></img>;
        return null;
      },
    },
    {
      dataField: "email id",
      text: "Email Id",
      sort: true,
      style:{width:"10%"},
      sortCaret: (order, column) => {
        if (!order) return <img className="sortIcon" src={sortIcon}></img>;
        else if (order === "asc")
          return <img className="sortIcon" src={sortIcon}></img>;
        else if (order === "desc")
          return <img className="sortIcon" src={sortIcon}></img>;
        return null;
      },
      // filter: textFilter({
      //   style: {
      //     marginTop: "10px",
      //   },
      // }),
    },
    {
      dataField: "country",
      text: "Country",
      sort: true,
      style:{textAlign:"right"},
      sortCaret: (order, column) => {
        if (!order) return <img className="sortIcon" src={sortIcon}></img>;
        else if (order === "asc")
          return <img className="sortIcon" src={sortIcon}></img>;
        else if (order === "desc")
          return <img className="sortIcon" src={sortIcon}></img>;
        return null;
      },
      // filter: textFilter({
      //   style: {
      //     marginTop: "10px",
      //   },
      // }),
    },
    {
      dataField: "action",
      text: "Action",
      sort: true,
    },
  ];

  const MySearch = (props) => {
    let input;
    const handleChange = () => {
      props.onSearch(input.value); //eslint-disable-line
    };
    return (
      <div style={{ width: "351px", float: "left" }}>
        <label htmlFor="table-search-bar">
          <div
            style={{
              float: "left",
              marginRight: "13px",
              marginTop: "8px",
              position: "relative",
              fontSize: "20px",
              fontWeight: "bold",
            }}
          >
            User List
          </div>
          <input
            id="table-search-bar"
            style={{
              padding: "10px",
              border: " 2px solid lightgrey",
              borderRadius: "24px",
              width: "250px",
              outline: "none",
            }}
            ref={(n) => (input = n)}
            type="text"
            placeholder="Search"
            onChange={handleChange}
          />
        </label>
      </div>
    );
  };

 
 
const options = {
    paginationSize: 4,
    pageStartIndex: 1,
    // alwaysShowAllBtns: true, // Always show next and previous button
    // withFirstAndLast: false, // Hide the going to First and Last page button
     hideSizePerPage: true, // Hide the sizePerPage dropdown always
 //hidePageListOnlyOnePage: true, // Hide the pagination list when only one page
    firstPageText: 'First',
    prePageText: 'Previous',
    nextPageText: 'Next',
    
    showTotal: false,
    disablePageTitle: true,
    sizePerPageList: [{
      text: '10', value: 10
    }, {
      text: '20', value: 20
    }, {
      text: 'All', value: products.length
    }] // A numeric array is also available. the purpose of above example is custom the text
  };


  return (
    <div className="userManagementTable">
      <ToolkitProvider keyField="id" data={products} columns={columns} search>
        {(props) => (
          <div style={{ width: "100%"}} className="userTableOverlay">
            <MySearch {...props.searchProps} />

            <div className="labelForActiveInactive">
              <p
                style={{
                  flexGrow: 1,
                  backgroundColor: "#EDF9FF",
                  borderTopLeftRadius: "10px",
                  borderBottomLeftRadius: "10px",
                }}
              >
                ALL
              </p>
              <div style={{ flexGrow: 1 }}>
                <div
                  className="statusRadio"
                  style={{ backgroundColor: "#00E022", float: "left" }}
                ></div>
                <p classNmae="status">Active</p>
              </div>
              <div style={{ flexGrow: 1 }}>
                <div className="statusRadio" style={{ float: "left" }}></div>
                <p classNmae="status">Inactive</p>
              </div>
            </div>

            <br />
            <BootstrapTable
             hover
              responsive
              pagination={ paginationFactory(options) }
              {...props.baseProps}
              className="userTable"
              bordered={false}
             // filter={filterFactory()}
            //  cellEdit={ cellEditFactory({ mode: 'click', clickToSelect: true }) }
            
            />
          </div>
        )}
      </ToolkitProvider>
    </div>
  );
};

export default UserManagementTable;
