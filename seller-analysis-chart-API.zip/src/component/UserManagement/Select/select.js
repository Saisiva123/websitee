import React, { useState } from "react";
import "./Select.css";
import { makeStyles, withStyles } from "@material-ui/core/styles";
import InputLabel from "@material-ui/core/InputLabel";
import { FormControl, FormHelperText } from "@material-ui/core";
import Select from "@material-ui/core/Select";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import Switch from "@material-ui/core/Switch";
import { FormControlLabel, Snackbar } from "@material-ui/core";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import Axios from "axios";
import { Spinner } from "../../Spinner/Spinner";
import { checkValidity } from "../../../Utils/Utils";
import { useSelector } from "react-redux";
import IconButton from "@material-ui/core/IconButton";
import CloseIcon from "@material-ui/icons/Close";

const useStyles = makeStyles((theme) => ({
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));

export default function NativeSelects() {
  const classes = useStyles();
  const authData = useSelector((state) => state.authentication);
  const [firstname, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [country, setCountry] = useState("");

  const [userStatus, setUserStatus] = useState(false);
  const [role, setRole] = useState("");
  const [loading, setLoading] = useState(false);
  const [firstnameError, setFirstNameError] = useState("");
  const [lastNameError, setLastNameError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [countryError, setCountryError] = useState("");
  const [userStatusError, setUserStatusError] = useState("");
  const [roleError, setRoleError] = useState("");
  const [toastMessage, setToastMessage] = React.useState("");
  const onSubmit = (e) => {
    resetErrors();
    let isValid = true;
    e.preventDefault();
    setLoading(true);

    if (!checkValidity(email, "email")) {
      setEmailError("Enter a valid email!");
      isValid = false;
      setLoading(false);
    }
    if (firstname.trim() === "") {
      setFirstNameError("First name can't be empty!");
      isValid = false;
      setLoading(false);
    }
    if (lastName.trim() === "") {
      setLastNameError("Last name can't be empty!");
      isValid = false;
      setLoading(false);
    }
    if (role === "") {
      setRoleError("Select role!");
      isValid = false;
      setLoading(false);
    }
    if (country === "") {
      setCountryError("Select country!");
      isValid = false;
      setLoading(false);
    }
    if (isValid) {
      const data = [
        {
          firstName: firstname.trim(),
          lastName: lastName.trim(),
          email: email,
          countryAccess: [country],
          role: role,
        },
      ];
      Axios.post("https://10.100.23.33:3000/signup", data, {
        headers: { authorization: "token " + authData.loginData.token },
      })
        .then((response) => {
          console.log(response);
          setLoading(false);
          setToastMessage("User has been added");
        })
        .catch((err) => {
          console.log(err.response);
          setToastMessage("Something went wrong!");
          setLoading(false);
        });
    }
  };

  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      setToastMessage("");
      return;
    }

    setToastMessage("");
  };
  const IOSSwitch = withStyles((theme) => ({
    root: {
      width: 42,
      height: 26,
      padding: 0,
      margin: theme.spacing(1),
    },
    switchBase: {
      padding: 1,
      "&$checked": {
        transform: "translateX(16px)",
        color: theme.palette.common.white,
        "& + $track": {
          backgroundColor: "#52d869",
          opacity: 1,
          border: "none",
        },
      },
      "&$focusVisible $thumb": {
        color: "#52d869",
        border: "6px solid #fff",
      },
    },
    thumb: {
      width: 24,
      height: 24,
    },
    track: {
      borderRadius: 26 / 2,
      border: `1px solid ${theme.palette.grey[400]}`,
      backgroundColor: theme.palette.grey[50],
      opacity: 1,
      transition: theme.transitions.create(["background-color", "border"]),
    },
    checked: {},
    focusVisible: {},
  }))(({ classes, ...props }) => {
    return (
      <Switch
        focusVisibleClassName={classes.focusVisible}
        disableRipple
        classes={{
          root: classes.root,
          switchBase: classes.switchBase,
          thumb: classes.thumb,
          track: classes.track,
          checked: classes.checked,
        }}
        {...props}
      />
    );
  });
  const resetForm = (e) => {
    // document.getElementById("newUserForm").reset();

    setFirstName("");
    setLastName("");
    setRole("");
    setCountry("");
    setEmail("");
    setUserStatus(false);
    resetErrors();
  };
  const resetErrors = () => {
    setEmailError("");
    setFirstNameError("");
    setLastNameError("");
    setCountryError("");
    setRoleError("");
    setUserStatusError("");
  };
  return (
    <>
      {loading && (
        <div
          style={{
            background: "rgba(0,0,0,0.7)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            position: "fixed",
            top: 0,
            bottom: 0,
            left: 0,
            right: 0,
            zIndex: 1212,
          }}
        >
          <Spinner />
        </div>
      )}
      <form className="LoginCard" id="newUserForm">
        <p className="text"> Add New User </p>
        <p className="text">Role</p>
        <FormControl
          style={{ margin: "0 20px" }}
          variant="outlined"
          className={classes.formControl}
        >
          <Select
            error={roleError !== ""}
            IconComponent={ExpandMoreIcon}
            value={role}
            onChange={(e) => {
              setRoleError("");
              setRole(e.target.value);
            }}
            inputProps={{
              name: "user",
              id: "outlined-age-native-simple",
            }}
          >
            <option aria-label="None" value="" />
            <option value={"client"}>Client</option>
            <option value={"admin"}>Admin</option>
          </Select>
          {roleError !== "" && (
            <FormHelperText style={{ color: "red" }}>
              {roleError}
            </FormHelperText>
          )}
        </FormControl>
        <div>
          <p className="text">User Status</p>
          <p className="userstatus">
            Activate User{" "}
            <FormControlLabel
              control={
                <IOSSwitch
                  checked={userStatus}
                  onChange={() => setUserStatus(!userStatus)}
                  name="checkedB"
                />
              }
              label={userStatus ? "ON" : "OFF"}
            />
          </p>
        </div>
        <p className="text">First Name</p>
        <TextField
          style={{ margin: "0 20px" }}
          id="outlined-basic"
          label=""
          variant="outlined"
          value={firstname}
          error={firstnameError !== ""}
          onChange={(e) => {
            setFirstNameError("");
            setFirstName(e.target.value);
          }}
          helperText={firstnameError}
        />

        <p className="text">Last Name</p>
        <TextField
          style={{ margin: "0 20px" }}
          id="outlined-basic"
          label=""
          variant="outlined"
          error={lastNameError !== ""}
          value={lastName}
          onChange={(e) => {
            setLastNameError("");
            setLastName(e.target.value);
          }}
          helperText={lastNameError}
        />

        <p className="text">Email ID</p>
        <TextField
          style={{ margin: "0 20px" }}
          id="outlined-basic"
          label=""
          variant="outlined"
          error={emailError !== ""}
          value={email}
          onChange={(e) => {
            if (!checkValidity(e.target.value, "email")) {
              setEmailError("Enter a valid email!");
            } else {
              setEmailError("");
            }

            setEmail(e.target.value);
          }}
          helperText={emailError}
        />
        <p className="text">Country</p>
        <FormControl
          style={{ margin: "0 20px" }}
          variant="outlined"
          className={classes.formControl}
        >
          <Select
            error={countryError !== ""}
            IconComponent={ExpandMoreIcon}
            value={country}
            onChange={(e) => {
              setCountryError("");
              setCountry(e.target.value);
            }}
            inputProps={{
              name: "country",
            }}
          >
            <option aria-label="None" placeholder="All Country" />
            <option value={10}>India</option>
            <option value={20}>Australia</option>
            <option value={30}>Singapore</option>
          </Select>
          {countryError !== "" && (
            <FormHelperText style={{ color: "red" }}>
              {countryError}
            </FormHelperText>
          )}
        </FormControl>
        <div className="submitfield">
          <Button
            class="addButton"
            variant="contained"
            onClick={(e) => {
              if (!loading) {
                onSubmit(e);
              }
            }}
          >
            Add
          </Button>

          <Button
            disableFocusRipple={true}
            disableRipple={true}
            class="resetButton"
            variant="contained"
            onClick={(e) => resetForm(e)}
          >
            Reset
          </Button>
        </div>
      </form>
      <Snackbar
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "left",
        }}
        open={toastMessage !== ""}
        autoHideDuration={3000}
        onClose={handleClose}
        message={toastMessage}
        action={
          <React.Fragment>
            <IconButton
              size="small"
              aria-label="close"
              color="inherit"
              onClick={handleClose}
            >
              <CloseIcon fontSize="small" />
            </IconButton>
          </React.Fragment>
        }
      />
    </>
  );
}
