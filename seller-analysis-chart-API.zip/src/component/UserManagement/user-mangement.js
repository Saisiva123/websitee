import React from "react";
import Select from "./Select/select";
import { Grid, Paper } from "@material-ui/core";
import UserManagementTable from "./userManagementTable/userManagementTable";

function UserMangement() {
  return (
    <div className="main-container">
      <Grid container>
        <Grid item md={4} xs={12}>
          <Select />
        </Grid>
        <Grid item md={8}   xs={12}  style={{position:'relative'}}>
          <Paper>
            <UserManagementTable />
          </Paper>
        </Grid>
      </Grid>
    </div>
  );
}

export default UserMangement;
