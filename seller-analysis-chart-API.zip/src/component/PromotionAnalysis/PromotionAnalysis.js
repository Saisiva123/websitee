import React,{Component} from 'react';

class PromotionAnalysis extends React.Component {
    render() {
       return (
          <div>
             <h1>Promotional Analysis...</h1>
          </div>
       )
    }
 }
 export default PromotionAnalysis;