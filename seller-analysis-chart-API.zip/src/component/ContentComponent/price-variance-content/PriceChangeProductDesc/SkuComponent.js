import React from 'react';
import { Paper } from "@material-ui/core";
import hpimage1 from './hpimage1.png';
import './content.css';

const SkuCompo = () => {
    return (

 
   <Paper className={"card1"}>
<p className={"Title"}>SKU Details</p>
 {/* <div className={"productcontent"}> */}
     <img src={hpimage1} style={{width: "78px",height:"78px",
    margin: "12px 12px 0px 1px",
    float: "left"}}></img>
     <div className={"productstyle"}>
     <p className={"SkuName"}>X4E78AA</p>
     <p className={"SkuDescrip"}>HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)</p>
     </div>
     
 {/* </div> */}
   </Paper>
      
    );
}
export default SkuCompo;