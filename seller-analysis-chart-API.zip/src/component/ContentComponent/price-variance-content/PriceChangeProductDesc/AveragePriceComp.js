import React from 'react';
import { Paper } from "@material-ui/core";
import './content.css';


const AveragePriceComp = (props) => {
    
    return (


   <Paper className={"card2"}>
    {/* <div className={"pricecardcontent"}> */}
    <p  className={"Priceheader"}>{props.data}</p>
    <p className={"pricechange"}>{props.item}</p>
    <p className={"Percentageheader"}>{props.value}</p>

     
       {/* </div> */}

   </Paper>
    
    );
}
export default AveragePriceComp;