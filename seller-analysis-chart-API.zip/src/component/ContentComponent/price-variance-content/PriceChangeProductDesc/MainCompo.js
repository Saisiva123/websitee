import React from 'react';
import SkuCompo from './SkuComponent';
import AveragePriceComp from './AveragePriceComp';

import './content.css';
const MainCompo = (props) => {

  const pricevariance = ["Minimum Price","Maximum Price","Average Price","Net Distributor Price","Suggested Retail Price"];

  const percentage = ["$19","$16","$20","$10","$20"];
  const increasePercent = ["+$1.6","-$1.0","+$0.8","+$1.1","+$1.1"];


    return(
    <div className ={"card"}>
    
      <SkuCompo />
           
           <AveragePriceComp data={pricevariance[1]} value={percentage[1]} item={increasePercent[1]} />
           <AveragePriceComp data={pricevariance[0]} value={percentage[0]} item={increasePercent[0]}/>
        
           <AveragePriceComp data={pricevariance[2]} value={percentage[2]} item={increasePercent[2]}/>
           <AveragePriceComp data={pricevariance[3]} value={percentage[3]} item={increasePercent[3]}/>
           <AveragePriceComp data={pricevariance[4]} value={percentage[4]} item={increasePercent[4]}/>
       
 

        
    </div>
        
 
    );
}
export default MainCompo;