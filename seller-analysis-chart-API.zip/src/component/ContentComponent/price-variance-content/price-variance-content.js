import React, { useEffect, useState } from "react";
import Grid from "@material-ui/core/Grid";
import ProductAvailablityCard from "../product-availablity-card";
import PriceTrendChart from "../chartscomponets/price-trend-chart";

import "../content-charts.css";
import {
  countryByPriceChange,
  skuAvailabilityOnAppario,
} from "../product-percentage-data";
import ProductPercentageBody from "../chartscomponets/product-percentage-body";
import { useSelector, useDispatch } from "react-redux";
import { setCurrentPriceChangeTableData } from "../../../store/action/priceChangeAction";
import { useQuery } from "../utils";
import PriceVarianceBarChart from "../chartscomponets/price-variance-bar-chart";
import MainCompo from "./PriceChangeProductDesc/MainCompo";

export default function PriceVarianceContent() {
  const dispatch = useDispatch();
  const data = useSelector((state) => state.priceChange);
  const dataForTxtAboveTable = useSelector((state) => state.header);
  const headerData = useSelector((state) => state.header);
  const query = useQuery();
  const sortByValue = useSelector((state) => state.sortBy);

  const priceChangeWorldwideTooltipData =
    "This chart depicts the quantum of price changed listing basis variance buckets across countries. Click on buckets to see +ve to -ve count of changed products for respective weeks.";

  const priceChangeTrendChartData =
    "Price trend of Advertised selling price in USD (inclusive Tax, exclusive of shipping) against Net Distributor or price (NDP) and Suggested Retailer Prices (SRP).";

  const priceChangeTableWorldWide =
    "Listing of all price changed product across countries by Price variance bucket selected.";
  const priceChangeTableCountry =
    "Listing of all price changed product across platform by Price variance bucket selected.";
  const priceChangeTablePlatform =
    "Listing of all price changed product across seller by Price variance bucket selected.";
  const priceChangeTableSeller =
    "Listing of all price changed product across sku by Price variance bucket selected.";

  const priceChangeTableSku =
    "Listing with price change based on Total price for a specific SKU across all platform and seller for a selected country.";

  useEffect(() => {
    if (!query.get("country")) {
      dispatch(
        setCurrentPriceChangeTableData(
          "worldwide",
          countryByPriceChange,
          [],
          "APJ"
        )
      );
    }
  }, []);

  const category = "WorldWide";
  var leftTableTitle = "List of All SKU's by Price Variance" + category;
  var [newSKUforAppario, newValues] = useState(skuAvailabilityOnAppario);
  var [search, setSearch] = useState("");

  useEffect(() => {
    const results = skuAvailabilityOnAppario.filter(
      (item) =>
        item.SKUName.toLowerCase().indexOf(search.toLowerCase()) !== -1 ||
        item.Description.toLowerCase().indexOf(search.toLowerCase()) != -1 ||
        item.Category.toLowerCase().indexOf(search.toLowerCase()) != -1 ||
        item.Status.toLowerCase().indexOf(search.toLowerCase()) != -1
    );
    newValues(results);
  }, [search]);

  var righttTableTitle =
    data.currentCategory === "worldwide"
      ? "List of Countries by Price Change"
      : data.currentCategory === "country"
      ? "List of Platforms by Price Change"
      : data.currentCategory === "platform"
      ? "List of Sellers by Price Change"
      : data.currentCategory === "seller"
      ? "List of All SKUs by Price Variance"
      : "Price Trend";
  var mainBigTableTitle =
    data.currentCategory === "platform"
      ? "List of All SKU's on " + data.label
      : "List of All SKU's";

  useEffect(() => {
    if (sortByValue.typeFor == leftTableTitle) {
      dispatch(
        setCurrentPriceChangeTableData(
          data.currentCategory,
          data.rightTableData.reverse(),
          data.downTableData,
          data.label
        )
      );
    }

    if (sortByValue.typeFor == righttTableTitle) {
      dispatch(
        setCurrentPriceChangeTableData(
          data.currentCategory,
          data.rightTableData.reverse(),
          data.downTableData,
          data.label
        )
      );
    }

    if (sortByValue.typeFor == mainBigTableTitle) {
      dispatch(
        setCurrentPriceChangeTableData(
          data.currentCategory,
          data.rightTableData,
          data.downTableData.reverse(),
          data.label
        )
      );
    }
  }, [sortByValue.value]);
  return (
    <Grid container className="content-container">
      {data.currentCategory === "sku" ? <MainCompo /> : null}

      {/*above chart container*/}
      <Grid container item xs={12}>
        <Grid item md={5} xs={12}>
          {data.currentCategory !== "sku" ? (
            <ProductAvailablityCard
              title={"Price Change Summary"}
              subTitle={
                data.currentCategory === "worldwide"
                  ? `By All Countries | ${
                      headerData.selectedCategory !== ""
                        ? headerData.selectedCategory
                        : "All Categories"
                    }`
                  : data.currentCategory === "country" ||
                    data.currentCategory === "platform"
                  ? `By ${data.label} |  ${
                      headerData.selectedCategory !== ""
                        ? headerData.selectedCategory
                        : "All Categories"
                    }`
                  : data.currentCategory === "seller"
                  ? `By ${query.get("seller")} |  ${
                      headerData.selectedCategory !== ""
                        ? headerData.selectedCategory
                        : "All Categories"
                    }`
                  : "By " + data.label
              }
              tooltipData={priceChangeWorldwideTooltipData}
              chartComponent={<PriceVarianceBarChart />}
            />
          ) : (
            <ProductAvailablityCard
              title={leftTableTitle}
              subTitle={
                data.currentCategory === "sku" ? query.get("country") : ""
              }
              showTableDescription={
                data.currentCategory === "worldwide" ? false : true
              }
              tooltipData={priceChangeTableSku}
              showDropdown="true"
              DropdownTitle={"Filter By Variance"}
              dropdownFor={leftTableTitle}
              chartComponent={
                <ProductPercentageBody
                  data={data.rightTableData}
                  type="table"
                  tableFor="SKU by price variance"
                  arrow="show"
                  extraHeight="true"
                />
              }
            />
          )}
        </Grid>
        <Grid item md={7} xs={12}>
          <ProductAvailablityCard
            title={righttTableTitle}
            showDropdown={data.currentCategory !== "sku" ? "true" : "false"}
            dropdownFor={righttTableTitle}
            stockHeading={data.currentCategory === "sku" ? "true" : "false"}
            stockHeadingClass="chartstockHeadingLegends"
            showTableDescription={
              data.currentCategory === "worldwide" ||
              data.currentCategory === "sku"
                ? false
                : true
            }
            subTitle={
              data.currentCategory === "seller"
                ? `By ${query.get("seller")} | ${
                    headerData.selectedCategory !== ""
                      ? headerData.selectedCategory
                      : "All Categories"
                  }`
                : data.currentCategory === "worldwide" ||
                  data.currentCategory === "platform" ||
                  data.currentCategory === "country"
                ? `By ${
                    headerData.selectedCategory !== ""
                      ? headerData.selectedCategory
                      : "All Categories"
                  }`
                : data.currentCategory === "sku"
                ? `By ${query.get("seller")} | ${query.get("country")}`
                : "By All Categories"
            }
            tooltipData={
              data.currentCategory === "worldwide"
                ? priceChangeTableWorldWide
                : data.currentCategory === "country"
                ? priceChangeTableCountry
                : data.currentCategory === "platform"
                ? priceChangeTablePlatform
                : data.currentCategory === "seller"
                ? priceChangeTableSeller
                : priceChangeTrendChartData
            }
            chartComponent={
              data.currentCategory !== "sku" ? (
                <ProductPercentageBody
                  data={data.rightTableData}
                  type="table"
                  tableFor="price change for countries"
                  dataFor={
                    data.currentCategory === "worldwide"
                      ? "priceChangeWorldWide"
                      : data.currentCategory === "country"
                      ? "priceChangeCountry"
                      : data.currentCategory === "platform"
                      ? "priceChangePlatform"
                      : "priceChangeSeller"
                  }
                  arrow="show"
                  extraHeight="true"
                />
              ) : (
                <PriceTrendChart />
              )
            }
          />
        </Grid>
      </Grid>
      {data.currentCategory === "country" ||
      data.currentCategory === "platform" ? (
        <div className="scrollTxtAboveTable">
          <p>
            See the list of all SKU's on{" "}
            {data.currentCategory == "country"
              ? dataForTxtAboveTable.selectedCountry
              : dataForTxtAboveTable.selectedPlatform}{" "}
            below
          </p>
        </div>
      ) : null}
      {/* main big table will be here */}
      {data.currentCategory === "country" ||
      data.currentCategory === "platform" ? (
        <ProductAvailablityCard
          title={mainBigTableTitle}
          style={{ width: "100%" }}
          showDropdown="true"
          dropdownFor={mainBigTableTitle}
          subTitle={
            data.currentCategory !== "platform"
              ? `By All Platforms | ${
                  headerData.selectedCategory !== ""
                    ? headerData.selectedCategory
                    : "All Categories"
                }`
              : `By ${
                  headerData.selectedCategory !== ""
                    ? headerData.selectedCategory
                    : "All Categories"
                }`
          }
          showSearchbar="true"
          showDropdown="true"
          stockHeading="false"
          implementFiltering={(e) => setSearch(e.target.value)}
          chartComponent={
            <ProductPercentageBody
              data={data.downTableData}
              type="table"
              tableFor="all SKU list"
              arrow="disable"
              extraHeight="true"
            />
          }
        />
      ) : null}
    </Grid>
  );
}
