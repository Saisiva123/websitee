import React, { useEffect, useState } from "react";
import Grid from "@material-ui/core/Grid";
import ProductAvailablityCard from "../product-availablity-card";
import "../content-charts.css";
import {
  sellerAnalysisTableData,
  skuAvailabilityOnAppario,
} from "../product-percentage-data";
import ProductPercentageBody from "../chartscomponets/product-percentage-body";
import { useSelector, useDispatch } from "react-redux";
import { setCurrentSellerAnalysisTableData } from "../../../store/action/sellerAnalysisAction";
import { useQuery } from "../utils";
import SellerAnalysisOverViewChart from "../chartscomponets/seller-analysis-overview-chart";
import SellerAnalysisTrendChart from "../chartscomponets/seller-analysis-trend-chart";

export default function SellerAnalyisContent() {
  const dispatch = useDispatch();
  const data = useSelector((state) => state.sellerAnalysis);
  const sortByValue = useSelector((state) => state.sortBy);
  const headerData = useSelector((state) => state.header);

  const query = useQuery();

  const sellerAnalysisWorldwideTooltipData =
    "Bifurcation of total sellers into HP Authorized and Unauthorized sellers";
  const sellerAnalysisCountryTooltipData =
    "Country spilt by Authorized and Unauthorized sellers.";
  const sellerAnalysisPlatformTooltipData =
    "Platform spilt by Authorized and Unauthorized sellers.";

  const sellerAnalysisTrendWorldwideToolTipData =
    "Trend of HP Authorized and Unauthorized sellers.";
  const sellerAnalysisTrendCountryToolTipData =
    "Trend of HP Authorized and Unauthorized sellers.";
  const sellerAnalysisTrendPlatformToolTipData =
    "Trend of HP Authorized and Unauthorized sellers.";

  const sellerAnalysisDownTableWorldwide =
    "Country level drill down for authorized and unauthorized sellers.";
  const sellerAnalysisDownTableCountry =
    "Platform level drill down for authorized and unauthorized sellers.";
  const sellerAnalysisDownTablePlatform =
    "Seller level drill down for authorized and unauthorized sellers.";
  const sellerAnalysisDownTableSeller =
    "Seller wise SKU level drill down for authorized and unauthorized sellers.";

  useEffect(() => {
    if (!query.get("country")) {
      dispatch(
        setCurrentSellerAnalysisTableData(
          "worldwide",
          sellerAnalysisTableData,
          "Worldwide"
        )
      );
    }
  }, []);
  const category = "WorldWide";
  var [newSKUforAppario, newValues] = useState(skuAvailabilityOnAppario);
  var [search, setSearch] = useState("");

  useEffect(() => {
    const results = skuAvailabilityOnAppario.filter(
      (item) =>
        item.SKUName.toLowerCase().indexOf(search.toLowerCase()) !== -1 ||
        item.Description.toLowerCase().indexOf(search.toLowerCase()) != -1 ||
        item.Category.toLowerCase().indexOf(search.toLowerCase()) != -1 ||
        item.Status.toLowerCase().indexOf(search.toLowerCase()) != -1
    );
    newValues(results);
  }, [search]);
  var tableTitle =
    data.currentCategory === "worldwide"
      ? "List of Countries"
      : data.currentCategory === "country"
      ? "List of Platforms"
      : data.currentCategory === "platform"
      ? "List of Sellers"
      : "List of all HP Products";

  useEffect(() => {
    if (sortByValue.typeFor == "List of Countries") {
      dispatch(
        setCurrentSellerAnalysisTableData(
          data.currentCategory,
          data.downTableData.reverse(),
          data.label
        )
      );
    }
    if (sortByValue.typeFor == "List of Platforms") {
      dispatch(
        setCurrentSellerAnalysisTableData(
          data.currentCategory,
          data.downTableData.reverse(),
          data.label
        )
      );
    }
    if (sortByValue.typeFor == "List of Sellers") {
      dispatch(
        setCurrentSellerAnalysisTableData(
          data.currentCategory,
          data.downTableData.reverse(),
          data.label
        )
      );
    }
    if (sortByValue.typeFor == "List of all HP Products") {
      dispatch(
        setCurrentSellerAnalysisTableData(
          data.currentCategory,
          data.downTableData.reverse(),
          data.label
        )
      );
    }
  }, [sortByValue.value]);

  return (
    <Grid container className="content-container">
      {/*above chart container*/}

      {data.currentCategory !== "seller" ? (
        <Grid container item xs={12}>
          <Grid item md={5} xs={12}>
            <ProductAvailablityCard
              title={"Seller Analysis"}
              subTitle={
                data.currentCategory === "worldwide"
                  ? `By APJ | ${
                      headerData.selectedCategory !== ""
                        ? headerData.selectedCategory
                        : "All Categories"
                    }`
                  : data.currentCategory === "country" ||
                    data.currentCategory === "platform"
                  ? `By ${data.label} | ${
                      headerData.selectedCategory !== ""
                        ? headerData.selectedCategory
                        : "All Categories"
                    }`
                  : data.currentCategory === "seller"
                  ? `By ${query.get("country")} | ${
                      headerData.selectedCategory !== ""
                        ? headerData.selectedCategory
                        : "All Categories"
                    }`
                  : "By All Categories"
              }
              tooltipData={
                data.currentCategory === "worldwide"
                  ? sellerAnalysisWorldwideTooltipData
                  : data.currentCategory === "country"
                  ? sellerAnalysisCountryTooltipData
                  : sellerAnalysisPlatformTooltipData
              }
              chartComponent={<SellerAnalysisOverViewChart />}
            />
          </Grid>
          <Grid item md={7} xs={12}>
            <ProductAvailablityCard
              title={"Seller Analysis Trend"}
              stockHeading="true"
              stockHeadingClass="chartstockHeadingLegends"
              subTitle={
                data.currentCategory === "worldwide"
                  ? `By APJ | ${
                      headerData.selectedCategory !== ""
                        ? headerData.selectedCategory
                        : "All Categories"
                    }`
                  : data.currentCategory === "country" ||
                    data.currentCategory === "platform"
                  ? `By ${data.label} | ${
                      headerData.selectedCategory !== ""
                        ? headerData.selectedCategory
                        : "All Categories"
                    }`
                  : data.currentCategory === "seller"
                  ? `By ${query.get("country")} | ${
                      headerData.selectedCategory !== ""
                        ? headerData.selectedCategory
                        : "All Categories"
                    }`
                  : "By All Categories"
              }
              tooltipData={
                data.currentCategory === "worldwide"
                  ? sellerAnalysisTrendWorldwideToolTipData
                  : data.currentCategory === "country"
                  ? sellerAnalysisTrendCountryToolTipData
                  : sellerAnalysisTrendPlatformToolTipData
              }
              chartComponent={<SellerAnalysisTrendChart />}
            />
          </Grid>
        </Grid>
      ) : null}

      {tableTitle == "List of all HP Products" ? null : (
        <div className="scrollTxtAboveTable">
          <p>
            See the list of all{" "}
            {data.currentCategory == "worldwide"
              ? "countries "
              : data.currentCategory == "country"
              ? "platforms "
              : `List of all sellers on ${headerData.selectedPlatform} `}
            below
          </p>
        </div>
      )}

      <ProductAvailablityCard
        title={tableTitle}
        tooltipData={"Seller table tooltip"}
        tooltipData={
          data.currentCategory === "worldwide"
            ? sellerAnalysisDownTableWorldwide
            : data.currentCategory === "country"
            ? sellerAnalysisDownTableCountry
            : data.currentCategory === "platform"
            ? sellerAnalysisDownTablePlatform
            : sellerAnalysisDownTableSeller
        }
        style={{ width: "100%" }}
        subTitle={
          data.currentCategory === "worldwide"
            ? `By APJ | ${
                headerData.selectedCategory !== ""
                  ? headerData.selectedCategory
                  : "All Categories"
              }`
            : data.currentCategory === "country" ||
              data.currentCategory === "platform"
            ? `By ${data.label} | ${
                headerData.selectedCategory !== ""
                  ? headerData.selectedCategory
                  : "All Categories"
              }`
            : data.currentCategory === "seller"
            ? `By ${query.get("seller")} | ${
                headerData.selectedCategory !== ""
                  ? headerData.selectedCategory
                  : "All Categories"
              }`
            : "By All Categories"
        }
        showDropdown="true"
        stockHeading="true"
        showSearchbar={tableTitle == "List of all HP Products" ? "true" : null}
        DropdownTitle={
          tableTitle == "List of Sellers"
            ? "Sort By Listing"
            : tableTitle == "List of all HP Products"
            ? "Sort By Ratings"
            : "Sort By"
        }
        dropdownFor={tableTitle}
        implementFiltering={(e) => setSearch(e.target.value)}
        chartComponent={
          data.currentCategory !== "platform" ? (
            <ProductPercentageBody
              data={data.downTableData}
              dataFor={
                data.currentCategory === "worldwide"
                  ? "sellerAnalysisWorldWide"
                  : data.currentCategory === "country"
                  ? "sellerAnalysisCountry"
                  : "sellerAnalysisSeller"
              }
              type="table"
              tableFor="sellerAnalysisPlatformWise"
              arrow="show"
            />
          ) : (
            <ProductPercentageBody
              data={data.downTableData}
              type="table"
              tableFor="sellerAnalysisForAmazon"
              arrow="show"
            />
          )
        }
      />
    </Grid>
  );
}
