import React, { useState, useEffect } from "react";
import { Paper, Tooltip } from "@material-ui/core";
import TooltipIconImage from "../../assets/Icon/KpiButtonTooltipIcon.png";
import "./content-charts.css";
import Dropdown from "../DropDown/dropdown";
import { useDispatch, useSelector } from "react-redux";
import { SortBy } from "../../store/action/sortByAction";

export default function ProductAvailablityCard(props) {
  var dropdownArray = ["Low To High", "High To Low"];
  var [valueForDropdown, setValue] = useState(dropdownArray[0]);
  const dispatch = useDispatch();
  const sellerData = useSelector((state) => state.sellerAnalysis);
  var currentKpiPath = useSelector((state) => state.kpi);

  const [open, setOpen] = React.useState(false);

  const handleTooltipClose = () => {
    setOpen(false);
  };

  const handleTooltipOpen = () => {
    setOpen(true);
  };

  return (
    <Paper className={["chart-card", props.extraClass]} style={props.style}>
      <div className="chart-card-header">
        <div className="chart-card-title-container">
          <span className="chart-card-title">{props.title}</span>
          {props.tooltipData ? (
            <Tooltip
              disableTouchListener
              onClose={handleTooltipClose}
              open={open}
              title={props.tooltipData}
              arrow>
              <img
                onClick={handleTooltipOpen}
                src={TooltipIconImage}
                style={{
                  width: "16px",
                  height: "16px",
                  margin: "auto 16px",
                  justifyContent: "center",
                }}
                alt="Tooltip"
              />
            </Tooltip>
          ) : null}
        </div>
        {props.stockHeading == "true" ? (
          <div
            className={"stockHeading " + props.stockHeadingClass}
            style={{
              display: sellerData.currentCategory == "seller" ? "none" : "",
            }}>
            {currentKpiPath.currentKpi == "priceChange" && (
              <div
                style={{
                  position: "relative",
                  float: "left",
                  marginRight: "15px",
                  display:
                    sellerData.currentCategory == "platform" ? "none" : "",
                }}>
                <div
                  className="sphere"
                  style={{
                    backgroundColor: "#0C9BD8",
                  }}></div>
                <p>SRP</p>
              </div>
            )}
            <div
              style={{
                position: "relative",
                float: "left",
                marginRight: "15px",
                display: sellerData.currentCategory == "platform" ? "none" : "",
              }}>
              <div
                className="sphere"
                style={
                  currentKpiPath.currentKpi == "sellerAnalysis"
                    ? { backgroundColor: "rgb(29, 53, 87)" }
                    : currentKpiPath.currentKpi == "priceChange"
                    ? {
                        backgroundColor: "#1D3557",
                      }
                    : {
                        backgroundColor: "#0C9BD8",
                      }
                }></div>
              <p>
                {currentKpiPath.currentKpi == "sellerAnalysis"
                  ? "Authorized Seller"
                  : currentKpiPath.currentKpi == "priceChange"
                  ? "NDP"
                  : "In Stock"}
              </p>
            </div>
            <div style={{ position: "relative", float: "left" }}>
              <div
                className="sphere"
                style={
                  currentKpiPath.currentKpi == "sellerAnalysis"
                    ? { backgroundColor: "rgb(235, 69, 99)" }
                    : currentKpiPath.currentKpi == "priceChange"
                    ? {
                        backgroundColor: "#EB4563",
                      }
                    : {
                        backgroundColor: "#1D3557",
                      }
                }></div>
              <p>
                {currentKpiPath.currentKpi == "sellerAnalysis"
                  ? "UnAuthorized Seller"
                  : currentKpiPath.currentKpi == "priceChange"
                  ? "ASP"
                  : "Out of Stock"}
              </p>
            </div>
          </div>
        ) : null}

        {props.showDropdown === "true" ? (
          <div
            class="sortBySection "
            style={
              props.DropdownTitle == "Filter By Variance"
                ? { width: "310px" }
                : props.DropdownTitle == "Filter By Listed Status"
                ? { width: "312px" }
                : props.DropdownTitle == "Sort By Listing"
                ? { width: "242px" }
                : props.DropdownTitle == "Sort By Ratings"
                ? { width: "242px" }
                : props.DropdownTitle
                ? { width: "205px" }
                : null
            }>
            <p style={{ float: "left" }}>
              {currentKpiPath.currentKpi == "productAvailability"
                ? props.DropdownTitle
                  ? props.DropdownTitle
                  : "Filter By"
                : props.DropdownTitle
                ? props.DropdownTitle
                : "Sort By"}
            </p>
            <Dropdown
              disableLabel={true}
              data={dropdownArray}
              label={"Filter By"}
              value={valueForDropdown}
              onSelectItem={(item) => {
                setValue(item);
                dispatch(
                  SortBy({
                    typeFor: props.dropdownFor,
                    value: item,
                  })
                );
              }}
            />
          </div>
        ) : null}
        {props.showSearchbar ? (
          <div className="searchBox">
            <input
              type="text"
              placeholder="search SKU here..."
              onChange={props.implementFiltering}></input>
          </div>
        ) : null}

        <div className="chart-card-subtitle-container">
          <span className="chart-card-subtitle">{props.subTitle}</span>
        </div>
      </div>
      {props.chartComponent}
      {props.showTableDescription ? (
        <p className="scrollText">Scroll Down to see more</p>
      ) : null}
    </Paper>
  );
}
