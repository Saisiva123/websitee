import { setCurrentTableData } from "../../store/action/product-availablity-actions";
import { setCurrentSellerAnalysisTableData } from "../../store/action/sellerAnalysisAction";
import { setCurrentPriceChangeTableData } from "../../store/action/priceChangeAction";
import { useLocation } from "react-router-dom";
import {
  countryData,
  sellerByNetPriceVariance,
  companyData,
  skuByPriceVariance,
  sellersByPriceChange,
  countryByPriceChange,
  platformByPriceChange,
  sellerAnalysisTableData,
  sellerAnalysisPlatformData,
  sellerAllHpProductList,
  sellerTypeData,
} from "./product-percentage-data";
import {
  setDropdownVisiblity,
  setCountry,
  setPlatForm,
  setSellerType,
} from "../../store/action/header-action";
import { SetDefaultApiData } from "../../Utils/Utils";

export function abbreviateNumber(number, decPlaces) {
  // 2 decimal places => 100, 3 => 1000, etc
  decPlaces = Math.pow(10, decPlaces);

  // Enumerate number abbreviations
  var abbrev = ["K", "M", "B", "T"];

  // Go through the array backwards, so we do the largest first
  for (var i = abbrev.length - 1; i >= 0; i--) {
    // Convert array index to "1000", "1000000", etc
    var size = Math.pow(10, (i + 1) * 3);

    // If the number is bigger or equal do the abbreviation
    if (size <= number) {
      // Here, we multiply by decPlaces, round, and then divide by decPlaces.
      // This gives us nice rounding to a particular decimal place.
      number = Math.round((number * decPlaces) / size) / decPlaces;

      // Handle special case where we round up to the next abbreviation
      if (number === 1000 && i < abbrev.length - 1) {
        number = 1;
        i++;
      }

      // console.log(number);
      // Add the letter for the abbreviation
      number += abbrev[i];

      // We are done... stop
      break;
    }
  }

  return number;
}

export const intialiseProductAvailablityData = (
  data,
  headerData,
  dispatch,
  query,
  authData,
  currentUrl
) => {
  const isProductAvailablity =
    currentUrl === "/dashboard/overview/product-availability".toLowerCase();
  if (isProductAvailablity) {
    if (!query.get("country")) {
      dispatch(
        setCurrentTableData("worldwide", countryData, companyData, "APJ")
      );
      dispatch(
        setDropdownVisiblity({
          ...headerData.dropdownVisiblity,
          platform: true,
          category: false,
          sellerType: false,
        })
      );
      dispatch(setCountry(""));
      dispatch(setPlatForm(""));

      SetDefaultApiData(
        "",
        "",
        headerData.selectedCategory,
        headerData.selectedSellerType,
        authData.loginData.token,
        dispatch
      );
    } else if (query.get("country") && !query.get("platform")) {
      dispatch(
        setCurrentTableData(
          "country",
          countryData,
          companyData,
          query.get("country")
        )
      );
      dispatch(
        setDropdownVisiblity({
          ...headerData.dropdownVisiblity,
          platform: false,
          category: false,
          sellerType: false,
        })
      );
      dispatch(setCountry(query.get("country")));
      dispatch(setPlatForm(""));

      SetDefaultApiData(
        query.get("country"),
        "",
        headerData.selectedCategory,
        headerData.selectedSellerType,
        authData.loginData.token,
        dispatch
      );
    } else if (
      query.get("country") &&
      query.get("platform") &&
      !query.get("seller")
    ) {
      dispatch(
        setCurrentTableData(
          "platform",
          countryData,
          companyData,
          query.get("platform")
        )
      );
      dispatch(
        setDropdownVisiblity({
          ...headerData.dropdownVisiblity,
          platform: false,
          category: false,
          sellerType: false,
        })
      );
      dispatch(setCountry(query.get("country")));
      dispatch(setPlatForm(query.get("platform")));

      SetDefaultApiData(
        query.get("country"),
        query.get("platform"),
        headerData.selectedCategory,
        headerData.selectedSellerType,
        authData.loginData.token,
        dispatch
      );
    } else if (
      query.get("country") &&
      query.get("platform") &&
      query.get("seller")
    ) {
      dispatch(
        setCurrentTableData(
          "seller",
          countryData,
          companyData,
          query.get("seller")
        )
      );
      dispatch(
        setDropdownVisiblity({
          ...headerData.dropdownVisiblity,
          platform: false,
          category: false,
          sellerType: false,
        })
      );
      dispatch(setCountry(query.get("country")));
      dispatch(setPlatForm(query.get("platform")));

      SetDefaultApiData(
        query.get("country"),
        query.get("platform"),
        headerData.selectedCategory,
        headerData.selectedSellerType,
        authData.loginData.token,
        dispatch
      );
    }
  }
};

export const intialisePriceChangeData = (
  data,
  headerData,
  dispatch,
  query,
  currentUrl
) => {
  const isPriceChange =
    currentUrl === "/dashboard/overview/price-change".toLowerCase();

  if (isPriceChange) {
    if (!query.get("country")) {
      dispatch(
        setCurrentPriceChangeTableData(
          "worldwide",
          countryByPriceChange,
          [],
          "APJ"
        )
      );
      dispatch(
        setDropdownVisiblity({
          ...headerData.dropdownVisiblity,
          platform: true,
          category: false,
          sellerType: false,
        })
      );
      dispatch(setCountry(""));
      dispatch(setPlatForm(""));
    } else if (query.get("country") && !query.get("platform")) {
      dispatch(
        setCurrentPriceChangeTableData(
          "country",
          platformByPriceChange,
          skuByPriceVariance,
          query.get("country")
        )
      );
      dispatch(
        setDropdownVisiblity({
          ...headerData.dropdownVisiblity,
          platform: false,
          category: false,
          sellerType: false,
        })
      );
      dispatch(setCountry(query.get("country")));
      dispatch(setPlatForm(""));
    } else if (
      query.get("country") &&
      query.get("platform") &&
      !query.get("seller")
    ) {
      dispatch(
        setCurrentPriceChangeTableData(
          "platform",
          sellersByPriceChange,
          skuByPriceVariance,
          query.get("platform")
        )
      );
      dispatch(
        setDropdownVisiblity({
          ...headerData.dropdownVisiblity,
          platform: false,
          category: false,
          sellerType: false,
        })
      );
      dispatch(setCountry(query.get("country")));
      dispatch(setPlatForm(query.get("platform")));
      dispatch(setSellerType(""));
    } else if (
      query.get("country") &&
      query.get("platform") &&
      query.get("seller") &&
      !query.get("sku")
    ) {
      dispatch(
        setCurrentPriceChangeTableData(
          "seller",
          skuByPriceVariance,
          [],
          query.get("platform")
        )
      );
      dispatch(
        setDropdownVisiblity({
          ...headerData.dropdownVisiblity,
          platform: false,
          category: false,
          sellerType: false,
        })
      );
      dispatch(setCountry(query.get("country")));

      dispatch(setPlatForm(query.get("platform")));
    } else if (
      query.get("country") &&
      query.get("platform") &&
      query.get("seller") &&
      query.get("sku")
    ) {
      dispatch(
        setCurrentPriceChangeTableData(
          "sku",
          sellerByNetPriceVariance,
          [],
          query.get("sku")
        )
      );

      dispatch(
        setDropdownVisiblity({
          ...headerData.dropdownVisiblity,
          platform: false,
          category: false,
          sellerType: false,
        })
      );
      dispatch(setCountry(query.get("country")));
      dispatch(setPlatForm(query.get("platform")));
    }
  }
};

export const intialiseSellerAnalysisData = (
  data,
  headerData,
  dispatch,
  query,
  currentUrl
) => {
  const isSellerAnalysis =
    currentUrl === "/dashboard/overview/seller-analysis".toLowerCase();

  if (isSellerAnalysis) {
    if (!query.get("country")) {
      dispatch(
        setCurrentSellerAnalysisTableData(
          "worldwide",
          sellerAnalysisTableData,
          "APJ"
        )
      );
      dispatch(
        setDropdownVisiblity({
          ...headerData.dropdownVisiblity,
          platform: true,
          category: false,
          sellerType: false,
        })
      );
      dispatch(setCountry(""));
      dispatch(setPlatForm(""));
    } else if (query.get("country") && !query.get("platform")) {
      dispatch(
        setCurrentSellerAnalysisTableData(
          "country",
          sellerAnalysisPlatformData,
          query.get("country")
        )
      );
      dispatch(
        setDropdownVisiblity({
          ...headerData.dropdownVisiblity,
          platform: false,
          category: false,
          sellerType: false,
        })
      );
      dispatch(setCountry(query.get("country")));
      dispatch(setPlatForm(""));
    } else if (
      query.get("country") &&
      query.get("platform") &&
      !query.get("seller")
    ) {
      dispatch(
        setCurrentSellerAnalysisTableData(
          "platform",
          sellerTypeData,
          query.get("platform")
        )
      );
      dispatch(
        setDropdownVisiblity({
          ...headerData.dropdownVisiblity,
          platform: false,
          category: false,
          sellerType: false,
        })
      );
      dispatch(setCountry(query.get("country")));
      dispatch(setPlatForm(query.get("platform")));
    } else if (
      query.get("country") &&
      query.get("platform") &&
      query.get("seller")
    ) {
      dispatch(
        setCurrentSellerAnalysisTableData(
          "seller",
          sellerAllHpProductList,
          query.get("seller")
        )
      );

      dispatch(
        setDropdownVisiblity({
          ...headerData.dropdownVisiblity,
          platform: false,
          category: false,
          sellerType: false,
        })
      );

      dispatch(setCountry(query.get("country")));
      dispatch(setPlatForm(query.get("platform")));
    }
  }
};

export function useQuery() {
  return new URLSearchParams(useLocation().search);
}
