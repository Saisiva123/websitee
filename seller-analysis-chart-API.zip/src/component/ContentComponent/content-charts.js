import React, { useEffect, useState } from "react";
import Grid from "@material-ui/core/Grid";
import ProductAvailablityCard from "./product-availablity-card";
import ProductAvailablityOverViewChart from "./chartscomponets/product-availablity-overview-chart";
import ProductAvailablityTrendChart from "./chartscomponets/product-availablity-trend-chart";
import "./content-charts.css";

import {
  countryData,
  companyData,
  sellerTypeData,
  skuAvailabilityOnAmazon,
  skuAvailabilityOnAppario,
  productAvailabilityPerSeller,
} from "./product-percentage-data";

import ProductPercentageBody from "./chartscomponets/product-percentage-body";
import { useSelector, useDispatch } from "react-redux";
import { setCurrentTableData } from "../../store/action/product-availablity-actions";
import { useQuery } from "./utils";

export default function ContentChart() {
  const dispatch = useDispatch();
  const data = useSelector((state) => state.productAvailablity);
  const query = useQuery();
  const sortByValue = useSelector((state) => state.sortBy);
  const headerData = useSelector((state) => state.header);

  const productAvailablityWorldwideTooltipData =
    "Product availability at overall level (all countries)";
  const productAvailablityCountryTooltipData =
    "Product availability at country level";
  const productAvailablityPlatformTooltipData =
    "Product availability at platform level";
  const productAvailablitySellerTooltipData =
    "Product availability at seller level";

  const productAvailablityTrendWorldwideToolTipData =
    "Product availability trend to help understand and historical inventory trend across chosen category at overall level";
  const productAvailablityTrendCountryToolTipData =
    "Product availability trend to help understand and historical inventory trend across chosen category at country level";
  const productAvailablityTrendPlatformToolTipData =
    "Product availability trend to help understand and historical inventory trend across chosen category at platform level";
  const productAvailablityTrendSellerToolTipData =
    "Product availability trend to help understand and historical inventory trend across chosen category at seller level";

  const productAvailabilityLeftTableWorldWide =
    "Provides insight into country level availability. Click a country to see more";
  const productAvailabilityLeftTableCountry =
    "Top 10 SKU available at country level.";
  const productAvailabilityLeftTablePlatform =
    "Top 10 SKU's available at platform level for a selected country.";

  const productAvailabilityRightTableWorldWide =
    "Overall availability by platfom for a country";
  const productAvailabilityRightTableCountry =
    "Prouct availability at country level by platforms. Click any platform to see more.";
  const productAvailabilityRightTablePlatform =
    "Prouct availability at platform level by sellers. Click any platform to see more.";

  const productAvailabilityDownTableSeller =
    "Seller level SKU drill down to help understand availability trend and current status.";

  var titleForLeftTable =
    data.currentCategory === "worldwide"
      ? "Out of Stocks Products Per Country"
      : "Top 10 SKUs Availablity Status";

  var titleForRightTable =
    data.currentCategory === "worldwide" || data.currentCategory === "country"
      ? "Out of Stocks Products Per Platform"
      : "Out of Stocks Products Per Seller";

  useEffect(() => {
    if (!query.get("country")) {
      dispatch(
        setCurrentTableData("worldwide", countryData, companyData, "APJ")
      );
    }
  }, []);

  useEffect(() => {
    if (sortByValue.typeFor == titleForLeftTable) {
      data.currentCategory === "worldwide"
        ? dispatch(
            setCurrentTableData(
              "worldwide",
              data.leftTableData.reverse(),
              data.rightTableData,
              data.label
            )
          )
        : data.currentCategory === "country"
        ? dispatch(
            setCurrentTableData(
              "country",
              skuAvailabilityOnAmazon.reverse(),
              data.rightTableData,
              data.label
            )
          )
        : data.currentCategory === "platform"
        ? dispatch(
            setCurrentTableData(
              "platform",
              skuAvailabilityOnAmazon.reverse(),
              data.rightTableData,
              data.label
            )
          )
        : dispatch(
            setCurrentTableData(
              "worldwide",
              data.leftTableData,
              data.rightTableData,
              data.label
            )
          );
    }
    if (sortByValue.typeFor == "SKU Available Status") {
      newSKUforAppario.reverse();
    } else {
      data.currentCategory === "platform"
        ? dispatch(
            setCurrentTableData(
              "platform",
              data.leftTableData,
              productAvailabilityPerSeller.reverse(),
              data.label
            )
          )
        : data.currentCategory === "country"
        ? dispatch(
            setCurrentTableData(
              "country",
              data.leftTableData,
              data.rightTableData.reverse(),
              data.label
            )
          )
        : data.currentCategory === "worldwide"
        ? dispatch(
            setCurrentTableData(
              "worldwide",
              data.leftTableData,
              data.rightTableData.reverse(),
              data.label
            )
          )
        : dispatch(
            setCurrentTableData(
              "platform",
              data.leftTableData,
              data.rightTableData,
              data.label
            )
          );
    }
  }, [sortByValue.value]);

  const category = "WorldWide";
  var [newSKUforAppario, newValues] = useState(skuAvailabilityOnAppario);
  var [search, setSearch] = useState("");

  useEffect(() => {
    const results = skuAvailabilityOnAppario.filter(
      (item) =>
        item.SKUName.toLowerCase().indexOf(search.toLowerCase()) !== -1 ||
        item.Description.toLowerCase().indexOf(search.toLowerCase()) != -1 ||
        item.Category.toLowerCase().indexOf(search.toLowerCase()) != -1 ||
        item.Status.toLowerCase().indexOf(search.toLowerCase()) != -1
    );
    newValues(results);
  }, [search]);

  return (
    <Grid container className="content-container">
      {/*above chart container*/}
      <Grid container item xs={12}>
        <Grid item md={5} xs={12}>
          <ProductAvailablityCard
            title={"Product Availability"}
            subTitle={
              data.currentCategory === "worldwide"
                ? `By APJ | ${
                    headerData.selectedCategory !== ""
                      ? headerData.selectedCategory
                      : "All Categories"
                  }`
                : data.currentCategory === "country" ||
                  data.currentCategory === "platform"
                ? `By ${data.label} | ${
                    headerData.selectedCategory !== ""
                      ? headerData.selectedCategory
                      : "All Categories"
                  }`
                : data.currentCategory === "seller"
                ? `By ${data.label} | ${
                    headerData.selectedCategory !== ""
                      ? headerData.selectedCategory
                      : "All Categories"
                  }`
                : "By All Categories"
            }
            tooltipData={
              data.currentCategory === "worldwide"
                ? productAvailablityWorldwideTooltipData
                : data.currentCategory === "country"
                ? productAvailablityCountryTooltipData
                : data.currentCategory === "platform"
                ? productAvailablityPlatformTooltipData
                : productAvailablitySellerTooltipData
            }
            chartComponent={<ProductAvailablityOverViewChart />}
          />
        </Grid>
        <Grid item md={7} xs={12}>
          <ProductAvailablityCard
            stockHeading="true"
            stockHeadingClass="chartstockHeadingLegends"
            title={"Product Availability Trend"}
            subTitle={
              data.currentCategory === "worldwide"
                ? `By APJ | ${
                    headerData.selectedCategory !== ""
                      ? headerData.selectedCategory
                      : "All Categories"
                  }`
                : data.currentCategory === "country" ||
                  data.currentCategory === "platform"
                ? `By ${data.label} | ${
                    headerData.selectedCategory !== ""
                      ? headerData.selectedCategory
                      : "All Categories"
                  }`
                : data.currentCategory === "seller"
                ? `By ${query.get("country")} | ${
                    headerData.selectedCategory !== ""
                      ? headerData.selectedCategory
                      : "All Categories"
                  }`
                : "By All Categories"
            }
            tooltipData={
              data.currentCategory === "worldwide"
                ? productAvailablityTrendWorldwideToolTipData
                : data.currentCategory === "country"
                ? productAvailablityTrendCountryToolTipData
                : data.currentCategory === "platform"
                ? productAvailablityTrendPlatformToolTipData
                : productAvailablityTrendSellerToolTipData
            }
            chartComponent={<ProductAvailablityTrendChart />}
          />
        </Grid>
      </Grid>

      {/*Below chart Container */}
      {data.currentCategory !== "seller" && (
        <Grid container item xs={12}>
          <Grid item md={5} xs={12}>
            <ProductAvailablityCard
              title={titleForLeftTable}
              tooltipData={
                data.currentCategory === "worldwide"
                  ? productAvailabilityLeftTableWorldWide
                  : data.currentCategory === "country"
                  ? productAvailabilityLeftTableCountry
                  : productAvailabilityLeftTablePlatform
              }
              subTitle={
                data.currentCategory === "worldwide"
                  ? `By ${
                      headerData.selectedCategory !== ""
                        ? headerData.selectedCategory
                        : "All Categories"
                    }`
                  : `By ${data.label} | ${
                      headerData.selectedCategory !== ""
                        ? headerData.selectedCategory
                        : "All Categories"
                    }`
              }
              showDropdown={
                titleForLeftTable ==
                `Top 10 SKU's Availablity ${
                  data.currentCategory === "country"
                    ? "In"
                    : data.currentCategory === "platform"
                    ? "On"
                    : ""
                } ${data.label}`
                  ? null
                  : "true"
              }
              dropdownFor={titleForLeftTable}
              chartComponent={
                data.currentCategory === "worldwide" ? (
                  <ProductPercentageBody
                    data={data.leftTableData}
                    arrow={"show"}
                  />
                ) : data.currentCategory === "country" ||
                  data.currentCategory === "platform" ? (
                  //we should change this data to amazon not appario
                  <ProductPercentageBody
                    data={skuAvailabilityOnAmazon}
                    type="table"
                    tableFor="SKU Availability for Country"
                    arrow={"show"}
                  />
                ) : null
              }
            />
          </Grid>

          <Grid item md={7} xs={12}>
            <ProductAvailablityCard
              title={titleForRightTable}
              tooltipData={
                data.currentCategory === "worldwide"
                  ? productAvailabilityRightTableWorldWide
                  : data.currentCategory === "country"
                  ? productAvailabilityRightTableCountry
                  : productAvailabilityRightTablePlatform
              }
              subTitle={
                data.currentCategory === "worldwide"
                  ? `By ${
                      headerData.selectedCategory !== ""
                        ? headerData.selectedCategory
                        : "All Categories"
                    }`
                  : `By ${data.label} | ${
                      headerData.selectedCategory !== ""
                        ? headerData.selectedCategory
                        : "All Categories"
                    }`
              }
              showDropdown="true"
              dropdownFor={titleForRightTable}
              chartComponent={
                <ProductPercentageBody
                  data={
                    data.currentCategory === "worldwide"
                      ? data.rightTableData
                      : data.currentCategory === "country"
                      ? data.rightTableData
                      : data.currentCategory === "platform"
                      ? // ? data.rightTableData
                        productAvailabilityPerSeller
                      : []
                  }
                  // arrow={"show"}
                  arrow={data.currentCategory === "worldwide" ? "hide" : "show"}
                />
              }
            />
          </Grid>
        </Grid>
      )}
      {data.currentCategory == "seller" && (
        <ProductAvailablityCard
          style={{ width: "100%" }}
          title={`SKU Available Status`}
          tooltipData={productAvailabilityDownTableSeller}
          subTitle={
            data.currentCategory === "worldwide"
              ? `By ${
                  headerData.selectedCategory !== ""
                    ? headerData.selectedCategory
                    : "All Categories"
                }`
              : `By ${data.label} | ${
                  headerData.selectedCategory !== ""
                    ? headerData.selectedCategory
                    : "All Categories"
                }`
          }
          showDropdown="true"
          showSearchbar="true"
          dropdownFor={`SKU Available Status`}
          DropdownTitle={"Filter By Listed Status"}
          stockHeading="true"
          implementFiltering={(e) => setSearch(e.target.value)}
          chartComponent={
            <ProductPercentageBody
              data={newSKUforAppario}
              type="table"
              tableFor="productAvailabilityTable"
              arrow="disable"
              extraHeight="true"
            />
          }
        />
      )}
    </Grid>
  );
}
