//import hpImg from "../assets/Image 11.png";
//import hpPc from "../assets/Image 13.png";
var countryData = [
  {
    name: "India",
    percentage: "42%",
  },
  {
    name: "Australia",
    percentage: "44%",
  },
  {
    name: "Thailand",
    percentage: "48%",
  },
  {
    name: "Malesia",
    percentage: "50%",
  },
  {
    name: "Indonesia",
    percentage: "52%",
  },
  {
    name: "Philippines",
    percentage: "54%",
  },
  {
    name: "Japan",
    percentage: "56%",
  },
  {
    name: "Korea",
    percentage: "58%",
  },
  {
    name: "Singapore",
    percentage: "60%",
  },
  {
    name: "India",
    percentage: "42%",
  },
  {
    name: "Australia",
    percentage: "44%",
  },
  {
    name: "Philippines",
    percentage: "54%",
  },
  {
    name: "Japan",
    percentage: "56%",
  },
  {
    name: "Korea",
    percentage: "58%",
  },
  {
    name: "Philippines",
    percentage: "54%",
  },
  {
    name: "Japan",
    percentage: "56%",
  },
  {
    name: "Korea",
    percentage: "58%",
  },
];
var companyData = [
  {
    name: "Amazon",
    percentage: "56%",
  },
  {
    name: "Lazada",
    percentage: "59%",
  },
  {
    name: "Tokopedia",
    percentage: "60%",
  },
  {
    name: "Shoppee",
    percentage: "62%",
  },
  {
    name: "Flipkart",
    percentage: "64%",
  },
  {
    name: "Paytm Mall",
    percentage: "65%",
  },
  {
    name: "Amazon",
    percentage: "56%",
  },
  {
    name: "Lazada",
    percentage: "59%",
  },
  {
    name: "Flipkart",
    percentage: "64%",
  },
  {
    name: "Paytm Mall",
    percentage: "65%",
  },
  {
    name: "Ebay",
    percentage: "68%",
  },
  {
    name: "Flipkart",
    percentage: "64%",
  },
  {
    name: "Paytm Mall",
    percentage: "65%",
  },
  {
    name: "Amazon",
    percentage: "62%",
  },
  {
    name: "Amazon",
    percentage: "41%",
  },
];
var skuAvailabilityOnAmazon = [
  {
    SKUName: "X4E78AA",
    Category: "Display",
    Status: "Out of Stock",
  },
  {
    SKUName: "L0S24AA",
    Category: "Display",
    Status: "Out of Stock",
  },
  {
    SKUName: "CZ637AA",
    Category: "Display",
    Status: "In Stock",
  },
  {
    SKUName: "CN045AA",
    Category: "Display",
    Status: "In Stock",
  },
  {
    SKUName: "3AL28AA",
    Category: "Supplies",
    Status: "Out of Stock",
  },
  {
    SKUName: "L0S24AA",
    Category: "Supplies",
    Status: "In Stock",
  },
  {
    SKUName: "3AL28AA",
    Category: "Supplies",
    Status: "In Stock",
  },
  {
    SKUName: "CZ637AA",
    Category: "Accessories",
    Status: "In Stock",
  },
  {
    SKUName: "3AL28AA",
    Category: "Accessories",
    Status: "In Stock",
  },
  {
    SKUName: "L0S24AA",
    Category: "Accessories",
    Status: "Out of Stock",
  },
  {
    SKUName: "X4E78AA",
    Category: "Display",
    Status: "Out of Stock",
  },
  {
    SKUName: "L0S24AA",
    Category: "Display",
    Status: "Out of Stock",
  },
  {
    SKUName: "CZ637AA",
    Category: "Display",
    Status: "In Stock",
  },
  {
    SKUName: "CN045AA",
    Category: "Display",
    Status: "In Stock",
  },
  {
    SKUName: "3AL28AA",
    Category: "Supplies",
    Status: "Out of Stock",
  },
  {
    SKUName: "L0S24AA",
    Category: "Supplies",
    Status: "In Stock",
  },
  {
    SKUName: "3AL28AA",
    Category: "Supplies",
    Status: "In Stock",
  },
  {
    SKUName: "CZ637AA",
    Category: "Accessories",
    Status: "In Stock",
  },
  {
    SKUName: "3AL28AA",
    Category: "Accessories",
    Status: "In Stock",
  },
  {
    SKUName: "L0S24AA",
    Category: "Accessories",
    Status: "Out of Stock",
  },
];
var skuAvailabilityOnAppario = [
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "out of stock",
      "in stock",
      "out of stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "in stock",
      "in stock",
      "out of stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "in stock",
      "out of stock",
      "out of stock",
      "in stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "out of stock",
      "in stock",
      "out of stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "out of stock",
      "out of stock",
      "out of stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "in stock",
      "out of stock",
      "out of stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "out of stock",
      "in stock",
      "out of stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "out of stock",
      "out of stock",
      "in stock",
      "in  stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "out of stock",
      "in stock",
      "out of stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "in stock",
      "out of stock",
      "out of stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "out of stock",
      "out of stock",
      "out of stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "out of stock",
      "in stock",
      "out of stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "out of stock",
      "out of stock",
      "out of stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "out of stock",
      "out of stock",
      "in stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "out of stock",
      "out of stock",
      "out of stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "out of stock",
      "out of stock",
      "out of stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "out of stock",
      "in stock",
      "out of stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "out of stock",
      "in stock",
      "in stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "out of stock",
      "in stock",
      "out of stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",

    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "out of stock",
      "in stock",
      "out of stock",
      "out of stock",
    ],
  },

  {
    SKUName: "L0S24AA",
    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "Out of Stock",
    Availablityperweek: [
      "out of stock",
      "in stock",
      "out of stock",
      "out of stock",
    ],
  },
  {
    SKUName: "X4E78AA",
    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "In Stock",
    Availablityperweek: ["in stock", "in stock", "in stock", "in stock"],
  },
  {
    SKUName: "X4E78AA",
    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "In Stock",
    Availablityperweek: ["In stock", "In stock", "In stock", "In stock"],
  },
  {
    SKUName: "X4E78AA",
    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "In Stock",
    Availablityperweek: ["In stock", "In stock", "in stock", "In stock"],
  },
  {
    SKUName: "X4E78AA",
    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "In Stock",
    Availablityperweek: ["In stock", "In stock", "In stock", "In stock"],
  },
  {
    SKUName: "L0S24AA",
    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "In Stock",
    Availablityperweek: ["in stock", "In stock", "in stock", "in stock"],
  },
  {
    SKUName: "L0S24AA",
    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "In Stock",
    Availablityperweek: ["in stock", "In stock", "In stock", "In stock"],
  },
  {
    SKUName: "L0S24AA",
    Description:
      "HP 680 Ink Cartridges Combo Pack (1 Black Cartridge + 1 tri-Color Cartridge)",
    Category: "Supplies",
    Status: "In Stock",
    Availablityperweek: ["In stock", "In stock", "In stock", "In stock"],
  },
];
var sellerAnalysisTableData = [
  {
    countryName: "Singapore",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Indonesia",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Thailand",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Australia",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Philippines",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Japan",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Korea",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Singapore",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Indonesia",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Thailand",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Australia",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Philippines",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Japan",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Korea",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Singapore",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Indonesia",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Thailand",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Australia",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Philippines",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Japan",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    countryName: "Korea",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
];
var sellerAnalysisPlatformData = [
  {
    platformName: "Amazon",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    platformName: "Shoppee",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    platformName: "Qoo10",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    platformName: "Lazada",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    platformName: "Amazon",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    platformName: "Shoppee",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    platformName: "Qoo10",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    platformName: "Qoo10",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    platformName: "Amazon",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    platformName: "Shoppee",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    platformName: "Qoo10",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    platformName: "Lazada",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
  {
    platformName: "Lazada",
    authorizedSeller: "80%(45k)",
    unauthorizedSeller: "20%(10k)",
  },
];
var sellerTypeData = [
  {
    name: "Atrix Dynamics",
    noOfHpProductsListed: "120",
    netPrice: "15",
    discount: "18%",
    responseRate: "9%",
    reviews: "260",
    ratings: "3.9",
    seller: "10 years",
  },

  {
    name: "Ascend Media PVT.Ltd",
    noOfHpProductsListed: "120",
    netPrice: "15",
    discount: "18%",
    responseRate: "9%",
    reviews: "260",
    ratings: "3.9",
    seller: "Newly Launched",
  },
  {
    name: "Smart-shoppers",
    noOfHpProductsListed: "120",
    netPrice: "15",
    discount: "18%",
    responseRate: "9%",
    reviews: "260",
    ratings: "3.9",
    seller: "4 years",
  },
  {
    name: "Shoppe store",
    noOfHpProductsListed: "120",
    netPrice: "15",
    discount: "18%",
    responseRate: "9%",
    reviews: "260",
    ratings: "3.9",
    seller: "2 years",
  },
  {
    name: "Venture IT Solutions",
    noOfHpProductsListed: "120",
    netPrice: "15",
    discount: "18%",
    responseRate: "9%",
    reviews: "260",
    ratings: "3.9",
    seller: "Newly Launched",
  },
  {
    name: "Atrix Dynamics",
    noOfHpProductsListed: "120",
    netPrice: "15",
    discount: "18%",
    responseRate: "9%",
    reviews: "260",
    ratings: "3.9",
    seller: "10 years",
  },

  {
    name: "Ascend Media PVT.Ltd",
    noOfHpProductsListed: "120",
    netPrice: "15",
    discount: "18%",
    responseRate: "9%",
    reviews: "260",
    ratings: "3.9",
    seller: "Newly Launched",
  },
  {
    name: "Smart-shoppers",
    noOfHpProductsListed: "120",
    netPrice: "15",
    discount: "18%",
    responseRate: "9%",
    reviews: "260",
    ratings: "3.9",
    seller: "4 years",
  },
  {
    name: "Shoppe store",
    noOfHpProductsListed: "120",
    netPrice: "15",
    discount: "18%",
    responseRate: "9%",
    reviews: "260",
    ratings: "3.9",
    seller: "2 years",
  },
  {
    name: "Venture IT Solutions",
    noOfHpProductsListed: "120",
    netPrice: "15",
    discount: "18%",
    responseRate: "9%",
    reviews: "260",
    ratings: "3.9",
    seller: "Newly Launched",
  },
  {
    name: "Atrix Dynamics",
    noOfHpProductsListed: "120",
    netPrice: "15",
    discount: "18%",
    responseRate: "9%",
    reviews: "260",
    ratings: "3.9",
    seller: "10 years",
  },

  {
    name: "Ascend Media PVT.Ltd",
    noOfHpProductsListed: "120",
    netPrice: "15",
    discount: "18%",
    responseRate: "9%",
    reviews: "260",
    ratings: "3.9",
    seller: "Newly Launched",
  },
  {
    name: "Smart-shoppers",
    noOfHpProductsListed: "120",
    netPrice: "15",
    discount: "18%",
    responseRate: "9%",
    reviews: "260",
    ratings: "3.9",
    seller: "4 years",
  },
  {
    name: "Shoppe store",
    noOfHpProductsListed: "120",
    netPrice: "15",
    discount: "18%",
    responseRate: "9%",
    reviews: "260",
    ratings: "3.9",
    seller: "2 years",
  },
  {
    name: "Venture IT Solutions",
    noOfHpProductsListed: "120",
    netPrice: "15",
    discount: "18%",
    responseRate: "9%",
    reviews: "260",
    ratings: "3.9",
    seller: "Newly Launched",
  },
];
var productAvailabilityPerSeller = [
  {
    name: "Atrix Dynamics",
    percentage: "46%",
  },

  {
    name: "Ascend Media PVT.Ltd",
    percentage: "42%",
  },
  {
    name: "Smart-shoppers",
    percentage: "44%",
  },
  {
    name: "Shoppe store",
    percentage: "54%",
  },
  {
    name: "Venture IT Solutions",
    percentage: "64%",
  },
  {
    name: "Atrix Dynamics",
    percentage: "54%",
  },

  {
    name: "Ascend Media PVT.Ltd",
    percentage: "64%",
  },
  {
    name: "Smart-shoppers",
    percentage: "24%",
  },
  {
    name: "Shoppe store",
    percentage: "34%",
  },
  {
    name: "Atrix Dynamics",
    percentage: "46%",
  },

  {
    name: "Ascend Media PVT.Ltd",
    percentage: "42%",
  },
  {
    name: "Smart-shoppers",
    percentage: "44%",
  },
  {
    name: "Shoppe store",
    percentage: "54%",
  },
  {
    name: "Venture IT Solutions",
    percentage: "64%",
  },
  {
    name: "Atrix Dynamics",
    percentage: "24%",
  },

  {
    name: "Ascend Media PVT.Ltd",
    percentage: "44%",
  },
  {
    name: "Smart-shoppers",
    percentage: "24%",
  },
  {
    name: "Shoppe store",
    percentage: "34%",
  },
];
var countryByPriceChange = [
  {
    countryName: "Singapore",
    "price change": "552",
    "price change in percent": "+4%",
  },
  {
    countryName: "Indonesia",
    "price change": "402",
    "price change in percent": "+3%",
  },
  {
    countryName: "India",
    "price change": "19",
    "price change in percent": "+8%",
  },
  {
    countryName: "Korea",
    "price change": "6",
    "price change in percent": "+6%",
  },
  {
    countryName: "Malaysia",
    "price change": "4",
    "price change in percent": "+3%",
  },
  {
    countryName: "Philipines",
    "price change": "43",
    "price change in percent": "+4%",
  },
  {
    countryName: "Thailand",
    "price change": "38",
    "price change in percent": "+3%",
  },
];
var platformByPriceChange = [
  {
    platformName: "Amazon",
    "price change": "552",
    "price change in percent": "+4%",
  },
  {
    platformName: "Lazada",
    "price change": "402",
    "price change in percent": "+3%",
  },
  {
    platformName: "Qoo10",
    "price change": "19",
    "price change in percent": "+8%",
  },
  {
    platformName: "Shoppee",
    "price change": "6",
    "price change in percent": "+6%",
  },
  {
    platformName: "Shop18",
    "price change": "4",
    "price change in percent": "+3%",
  },
];
var sellersByPriceChange = [
  {
    name: "Atrix Dynamics",
    "price change": "43",
    "price change in percent": "+4%",
    sellerAuthorized: true,
  },
  {
    name: "Venture IT Solutions",
    "price change": "38",
    "price change in percent": "+3%",
    sellerAuthorized: false,
  },
  {
    name: "Ascend Media Pvt.LTD",
    "price change": "19",
    "price change in percent": "+8%",
    sellerAuthorized: true,
  },
  {
    name: "Smart-shoppers",
    "price change": "6",
    "price change in percent": "+6%",
    sellerAuthorized: true,
  },
  {
    name: "Shoppe Store",
    "price change": "4",
    "price change in percent": "+3%",
    sellerAuthorized: false,
  },
  {
    name: "Atrix Dynamics",
    "price change": "43",
    "price change in percent": "+4%",
    sellerAuthorized: true,
  },
  {
    name: "Venture IT Solutions",
    "price change": "38",
    "price change in percent": "+3%",
    sellerAuthorized: false,
  },
  {
    name: "Ascend Media Pvt.LTD",
    "price change": "19",
    "price change in percent": "+8%",
    sellerAuthorized: true,
  },
  {
    name: "Smart-shoppers",
    "price change": "6",
    "price change in percent": "+6%",
    sellerAuthorized: true,
  },
  {
    name: "Shoppe Store",
    "price change": "4",
    "price change in percent": "+3%",
    sellerAuthorized: false,
  },
];

var skuByPriceVariance = [
  {
    name: "X4E78AA",
    category: "Display",
    lastWeekNetPrice: "$16.43",
    currentWeekNetPrice: "$15.61",
    priceVariance: "-9%",
  },
  {
    name: "T3U82A6",
    category: "Display",
    lastWeekNetPrice: "$16.34",
    currentWeekNetPrice: "$15.51",
    priceVariance: "-8.6%",
  },
  {
    name: "X4E78AA",
    category: "Display",
    lastWeekNetPrice: "$16.43",
    currentWeekNetPrice: "$15.61",
    priceVariance: "-9%",
  },
  {
    name: "T3U82A6",
    category: "Display",
    lastWeekNetPrice: "$16.34",
    currentWeekNetPrice: "$15.51",
    priceVariance: "-8.6%",
  },
  {
    name: "X4E78AA",
    category: "Display",
    lastWeekNetPrice: "$16.43",
    currentWeekNetPrice: "$15.61",
    priceVariance: "-9%",
  },
  {
    name: "T3U82A6",
    category: "Display",
    lastWeekNetPrice: "$16.34",
    currentWeekNetPrice: "$15.51",
    priceVariance: "-8.6%",
  },
  {
    name: "X4E78AA",
    category: "Display",
    lastWeekNetPrice: "$16.43",
    currentWeekNetPrice: "$15.61",
    priceVariance: "-9%",
  },
  {
    name: "T3U82A6",
    category: "Display",
    lastWeekNetPrice: "$16.34",
    currentWeekNetPrice: "$15.51",
    priceVariance: "-8.6%",
  },
  {
    name: "X4E78AA",
    category: "Display",
    lastWeekNetPrice: "$16.43",
    currentWeekNetPrice: "$15.61",
    priceVariance: "-9%",
  },
  {
    name: "T3U82A6",
    category: "Display",
    lastWeekNetPrice: "$16.34",
    currentWeekNetPrice: "$15.51",
    priceVariance: "-8.6%",
  },
];
var allSKUList = [
  {
    "platform name": "Dinomarket",
    "sku name": "X4E78AA",
    category: "Display",
    "price current week": "$16.43",
    "price last week": "$15.61",
    "average price variance": "-9%",
  },
  {
    "platform name": "Dinomarket",
    "sku name": "X4E78AA",
    category: "Display",
    "price current week": "$16.43",
    "price last week": "$15.61",
    "average price variance": "-9%",
  },
  {
    "platform name": "Dinomarket",
    "sku name": "X4E78AA",
    category: "Display",
    "price current week": "$16.43",
    "price last week": "$15.61",
    "average price variance": "-9%",
  },
  {
    "platform name": "Dinomarket",
    "sku name": "X4E78AA",
    category: "Display",
    "price current week": "$16.43",
    "price last week": "$15.61",
    "average price variance": "-9%",
  },
  {
    "platform name": "Dinomarket",
    "sku name": "X4E78AA",
    category: "Display",
    "price current week": "$16.43",
    "price last week": "$15.61",
    "average price variance": "-9%",
  },
  {
    "platform name": "Dinomarket",
    "sku name": "X4E78AA",
    category: "Display",
    "price current week": "$16.43",
    "price last week": "$15.61",
    "average price variance": "-9%",
  },
  {
    "platform name": "Dinomarket",
    "sku name": "X4E78AA",
    category: "Display",
    "price current week": "$16.43",
    "price last week": "$15.61",
    "average price variance": "-9%",
  },
  {
    "platform name": "Dinomarket",
    "sku name": "X4E78AA",
    category: "Display",
    "price current week": "$16.43",
    "price last week": "$15.61",
    "average price variance": "-9%",
  },
];

var sellerAllHpProductList = [
  {
    skuName: "X4E78AA",
    description: "Compaq B191 18.5 inch LED Backlit Monitor (Black)",
    category: "Display",
    shippingSla: "7 Days",
    shippingCost: "Free",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
  {
    skuName: "T3U82A6",
    description: "HP 22f display Full HD  (1920 X 1080) 21.5 inch",
    category: "Display",
    shippingSla: "7 Days",
    shippingCost: "$2",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
  {
    skuName: "3AJ92AA",
    description: "Compaq B191 18.5 inch LED Backlit Monitor (Black)",
    category: "Display",
    shippingSla: "7 Days",
    shippingCost: "Free",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
  {
    skuName: "1PX47AA",
    description: "Compaq B191 18.5 inch LED Backlit Monitor (Black)",
    category: "Display",
    shippingSla: "7 Days",
    shippingCost: "Free",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
  {
    skuName: "X4E78AA",
    description: "Compaq B191 18.5 inch LED Backlit Monitor (Black)",
    category: "Accessories",
    shippingSla: "7 Days",
    shippingCost: "Free",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
  {
    skuName: "3AJ92AA",
    description: "Compaq B191 18.5 inch LED Backlit Monitor (Black)",
    category: "Display",
    shippingSla: "7 Days",
    shippingCost: "Free",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
  {
    skuName: "X4E78AA",
    description: "Compaq B191 18.5 inch LED Backlit Monitor (Black)",
    category: "Display",
    shippingSla: "7 Days",
    shippingCost: "Free",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
  {
    skuName: "T3U82A6",
    description: "HP 22f display Full HD  (1920 X 1080) 21.5 inch",
    category: "Display",
    shippingSla: "7 Days",
    shippingCost: "$2",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
  {
    skuName: "3AJ92AA",
    description: "Compaq B191 18.5 inch LED Backlit Monitor (Black)",
    category: "Display",
    shippingSla: "7 Days",
    shippingCost: "Free",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
  {
    skuName: "1PX47AA",
    description: "Compaq B191 18.5 inch LED Backlit Monitor (Black)",
    category: "Display",
    shippingSla: "7 Days",
    shippingCost: "Free",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
  {
    skuName: "X4E78AA",
    description: "Compaq B191 18.5 inch LED Backlit Monitor (Black)",
    category: "Accessories",
    shippingSla: "7 Days",
    shippingCost: "Free",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
  {
    skuName: "3AJ92AA",
    description: "Compaq B191 18.5 inch LED Backlit Monitor (Black)",
    category: "Display",
    shippingSla: "7 Days",
    shippingCost: "Free",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
  {
    skuName: "X4E78AA",
    description: "Compaq B191 18.5 inch LED Backlit Monitor (Black)",
    category: "Display",
    shippingSla: "7 Days",
    shippingCost: "Free",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
  {
    skuName: "T3U82A6",
    description: "HP 22f display Full HD  (1920 X 1080) 21.5 inch",
    category: "Display",
    shippingSla: "7 Days",
    shippingCost: "$2",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
  {
    skuName: "3AJ92AA",
    description: "Compaq B191 18.5 inch LED Backlit Monitor (Black)",
    category: "Display",
    shippingSla: "7 Days",
    shippingCost: "Free",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
  {
    skuName: "1PX47AA",
    description: "Compaq B191 18.5 inch LED Backlit Monitor (Black)",
    category: "Display",
    shippingSla: "7 Days",
    shippingCost: "Free",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
  {
    skuName: "X4E78AA",
    description: "Compaq B191 18.5 inch LED Backlit Monitor (Black)",
    category: "Accessories",
    shippingSla: "7 Days",
    shippingCost: "Free",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
  {
    skuName: "3AJ92AA",
    description: "Compaq B191 18.5 inch LED Backlit Monitor (Black)",
    category: "Display",
    shippingSla: "7 Days",
    shippingCost: "Free",
    reviews: "26",
    ratings: "3.9",
    productUrl: "Click here",
  },
];

var sellerByNetPriceVariance = [
  {
    platformName: "Amazon",
    sellerName: "Atrix Dynamics",
    currentWeekNetPrice: "$15.61",
    lastWeekNetPrice: "$16.43",
    priceVariance: "-13.05%",
  },
  {
    platformName: "Amazon",
    sellerName: "Venture IT Solutions",
    currentWeekNetPrice: "$10.61",
    lastWeekNetPrice: "$12.43",
    priceVariance: "-12.05%",
  },
  {
    platformName: "Amazon",
    sellerName: "Ascend Media Pvt. Ltd.",
    currentWeekNetPrice: "$12.61",
    lastWeekNetPrice: "$10.43",
    priceVariance: "-13.05%",
  },
  {
    platformName: "Lazada",
    sellerName: "Smart Shoper",
    currentWeekNetPrice: "$13.61",
    lastWeekNetPrice: "$11.43",
    priceVariance: "13.05%",
  },
  {
    platformName: "Lazada",
    sellerName: "It Store",
    currentWeekNetPrice: "$9.61",
    lastWeekNetPrice: "$9.43",
    priceVariance: "12.05%",
  },
  {
    platformName: "Amazon",
    sellerName: "Atrix Dynamics",
    currentWeekNetPrice: "$15.61",
    lastWeekNetPrice: "$16.43",
    priceVariance: "-13.05%",
  },
];
export {
  sellerAnalysisPlatformData,
  countryData,
  companyData,
  skuAvailabilityOnAmazon,
  skuAvailabilityOnAppario,
  sellerAnalysisTableData,
  sellerTypeData,
  platformByPriceChange,
  countryByPriceChange,
  productAvailabilityPerSeller,
  sellersByPriceChange,
  skuByPriceVariance,
  allSKUList,
  sellerByNetPriceVariance,
  sellerAllHpProductList,
};
