import React, { useState, useEffect } from "react";
import "../content-charts.css";
import {
  LineChart,
  Line,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Label,
  CartesianGrid,
  Tooltip,
} from "recharts";
import { useSelector } from "react-redux";

const data = [
  {
    name: "Week 01",
    "In Stock": 50,
    "Out of Stock": 30,
  },
  {
    name: "Week 02",
    "In Stock": 70,
    "Out of Stock": 40,
  },
  {
    name: "Week 03",
    "In Stock": 20,
    "Out of Stock": 50,
  },
  {
    name: "Week 04",
    "In Stock": 86,
    "Out of Stock": 34,
  },
];

export default function ProductAvailablityTrendChart(props) {
  //This will be a state connected to redux
  const data = useSelector(
    (state) => state.productAvailablity.productAvailablityData
  );
  const headerData = useSelector((state) => state.header);
  const [chartData, setChartData] = useState([]);

  useEffect(() => {
    if (
      data &&
      data.productAvailability &&
      data.productAvailability.periodicity &&
      data.productAvailability.periodicity.stock_count_world_wide.length > 0
    ) {
      let chartsInfo =
        data.productAvailability.periodicity.stock_count_world_wide;

      const updatedData = chartsInfo.map((item, index) => {
        let total = item.in_count + item.listing_count + item.unlisting_count;
        let outStock =
          ((item.listing_count + item.unlisting_count) / total) * 100;
        if (outStock) {
          outStock += 1;
        }
        return {
          name: `${headerData.currentTimeline} 0${index + 1}`,
          "In Stock": parseInt((item.in_count / total) * 100),
          "Out of Stock": parseInt(outStock),
        };
      });
      setChartData(updatedData);
    } else if (
      data &&
      data.productAvailability &&
      data.productAvailability.periodicity &&
      data.productAvailability.periodicity.stock_count_world_wide.length === 0
    ) {
      setChartData([]);
    }
  }, [data]);

  return (
    <div className="chart-grey-container">
      <ResponsiveContainer width={"100%"} height={290}>
        <LineChart data={chartData}>
          {/* <CartesianGrid strokeOpacity={0.3} /> */}
          <XAxis
            dataKey="name"
            axisLine={{ strokeWidth: 0.3 }}
            tickMargin={2}
            tickLine={false}>
            {/* <Label
              value="No. of Weeks"
              fontFamily="Open sans"
              position="insideBottom"
              dy={10}
            />*/}
          </XAxis>

          <YAxis
            axisLine={{ strokeWidth: 0.3 }}
            tickFormatter={(tickItem) => {
              return tickItem.toString() + "%";
            }}>
            <Label
              style={{ textAnchor: "middle" }}
              value="Availablity"
              position="insideLeft"
              offset={2}
              angle={-90}
              fontFamily="Open sans"
            />
          </YAxis>
          <Tooltip
            wrapperStyle={{ borderRadius: 10 }}
            formatter={(value, name, props) => {
              return value.toString() + "%";
            }}
          />

          <Line
            type="linear"
            dataKey="In Stock"
            stroke="#0096D6"
            strokeWidth={2}
            activeDot={{ r: 8 }}
          />
          <Line
            type="linear"
            dataKey="Out of Stock"
            stroke="#1D3557"
            strokeWidth={2}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
