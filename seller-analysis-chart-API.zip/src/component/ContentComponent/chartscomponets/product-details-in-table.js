import React from "react";

export default function ProductDetailsInTable(props)
{
    return (
        <div class="tableProductDetails">
            {/* <img src={props.data.imgSrc}></img> */}
            <p>{props.data.Name}</p>
        </div>
    )
}