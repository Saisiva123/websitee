import React from "react";
import AvailabilityPerWeek from "./availabilyt-per-week";
import "bootstrap/dist/css/bootstrap.min.css";
import BootstrapTable from "react-bootstrap-table-next";
import filterFactory from "react-bootstrap-table2-filter";
import paginationFactory from "react-bootstrap-table2-paginator";
import { useQuery } from "../utils";
import { useHistory } from "react-router-dom";

const TableSellerAnalysis = (props) => {
  const products = props.data;
  const updatedQuery = useQuery();
  let history = useHistory();

  function setNewClass(cell, row, rowIndex, colIndex) {
    var x = cell == "Newly Launched" ? "newlyLaunchedTxt" : "";
    return x;
  }
  function styleForPriceVariance(cell) {
    return (
      <div
        className={"arrowForTable"}
        style={{ width: "100%" }}
      >
        <p>{cell}</p>
      </div>
    );
  }


  const columns = [
    {
      dataField: "name",
      text: "Seller Name",
      sort: true,
      style: { width: "20%" },
      headerStyle:{backgroundColor:"#F5F5F5"},
    },
    {
      dataField: "noOfHpProductsListed",
      text: "HP Products Listed",
      sort: true,
      style: { width: "5%" },
      headerStyle:{lineHeight:"20px",margin:"0",backgroundColor:"#F5F5F5"}
    },
    {
      dataField: "netPrice",
      text: "Products Net Price < NDP ",
      sort: true,
      style: { width: "5%" },
      headerStyle:{lineHeight:"20px",margin:"0",backgroundColor:"#F5F5F5"}
    },
    {
      dataField: "discount",
      text: "Max.Discount",
      sort: true,
      style: { width: "5%" },
      headerStyle:{backgroundColor:"#F5F5F5"},
    },
    {
      dataField: "responseRate",
      text: "Chat Response Rate",
      sort: true,
      style: { width: "5%" },
      headerStyle:{lineHeight:"20px",margin:"0",backgroundColor:"#F5F5F5"},
     
    },
    {
      dataField: "reviews",
      text: "Reviews",
      sort: true,
      style: { width: "5%" },
      headerStyle:{backgroundColor:"#F5F5F5"},
    },
    {
      dataField: "ratings",
      text: "Ratings",
      sort: true,
      style: { width: "5%" },
      headerStyle:{backgroundColor:"#F5F5F5"},
    },
    {
      dataField: "seller",
      text: "Seller Tenure",
      sort: true,
      style: { width: "5%" ,textAlign:"left",position:"relative"},
      headerStyle:{backgroundColor:"#F5F5F5"},
      classes: setNewClass,
      formatter:styleForPriceVariance
    },
  ];
  const rowEvents = {
    onClick: (e, row, rowIndex) => {
      history.push("?country=" +
      updatedQuery.get("country") +
      "&platform=" +
      updatedQuery.get("platform") +
      "&seller=" +
      row.name);
    },
  };

  return (
    <div className="prodAvailTable">
      <BootstrapTable
        hover
        bordered={false}
        keyField="id"
        data={products}
        columns={columns}
        rowEvents={rowEvents}
        filter={filterFactory()}
      />
      </div>
  );
};

export default TableSellerAnalysis;
