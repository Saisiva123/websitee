import React,{useState} from "react";

export default function AvailabilityPerWeek(props)
{
    
    var [data,setData]=useState(props.data)

    var newArray=Object.values(Object.values(data)[4]);
    console.log(newArray);

    return(
         <div className="availability" >
              {newArray.map((items,index)=><div className={items=="in stock"?"inStock":"outStock"}>W0{index+1}</div>)}          
        </div>
    )
}