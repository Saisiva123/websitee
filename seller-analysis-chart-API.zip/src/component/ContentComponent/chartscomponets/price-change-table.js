import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import BootstrapTable from "react-bootstrap-table-next";
import filterFactory from "react-bootstrap-table2-filter";
import { useSelector, useDispatch } from "react-redux";
import { useQuery } from "../utils";
import { useHistory } from "react-router-dom";
import {setSellerType} from '../../../store/action/header-action';

const PriceChangeTable = (props) => {
  const products = props.data;
  const showArrow = props.arrowProperty;
  const updatedQuery = useQuery();
  let history = useHistory();
  const dispatch = useDispatch();

  const data = useSelector((state) => state.priceChange);

  function getUrl(label) {
    let query = "";
    if (data.currentCategory === "worldwide") {
      query = "?country=" + label;
    } else if (data.currentCategory === "country") {
      query = "?country=" + updatedQuery.get("country") + "&platform=" + label;
    } else if (data.currentCategory === "platform") {
      query =
        "?country=" +
        updatedQuery.get("country") +
        "&platform=" +
        updatedQuery.get("platform") +
        "&seller=" +
        label;
    } else if (data.currentCategory === "seller") {
      query =
        "?country=" +
        updatedQuery.get("country") +
        "&platform=" +
        updatedQuery.get("platform") +
        "&seller=" +
        updatedQuery.get("seller") +
        "&sku=" +
        label;
    }
    return query;
  }

  function styleForPriceVariance(cell) {
    return (
      <div
        className={showArrow ? "arrowForTable" : ""}
        style={{ widtsh: "100%" }}
      >
        <p>{cell}</p>
      </div>
    );
  }

  let columns;
  if (props.type === "priceChangeWorldWide") {
    columns = [
      {
        dataField: "countryName",
        text: "Country",
        sort: true,
      },
      {
        dataField: "price change",
        text: "No of Listing Price Change (Current week)",
        sort: true,
        headerStyle: {
          lineHeight: "19px",
        },
      },
      {
        dataField: "price change in percent",
        text: "% of Listing Price Change (Compared to last week)",
        sort: true,

        formatter: styleForPriceVariance,
        headerStyle: {
          lineHeight: "19px",
        },
      },
    ];
  }

  if (props.type === "priceChangeCountry") {
    columns = [
      {
        dataField: "platformName",
        text: "Platform",
        sort: true,
      },
      {
        dataField: "price change",
        text: "No of Listing Price Change (Current week)",
        sort: true,
        headerStyle: {
          lineHeight: "19px",
        },
      },
      {
        dataField: "price change in percent",
        text: "% of Listing Price Change (Compared to last week)",
        sort: true,
        headerStyle: {
          lineHeight: "19px",
        },
        formatter: styleForPriceVariance,
      },
    ];
  }

  if (props.type === "priceChangePlatform") {
    columns = [
      {
        dataField: "name",
        text: "Seller Name",
        sort: true,
      },
      {
        dataField: "price change",
        text: "No Of Listing Price Change (Current week)",
        sort: true,
        headerStyle: {
          lineHeight: "19px",
        },
        
      },
      {
        dataField: "price change in percent",
        text: "% of Listing Price Change (Compared to last week)",
        sort: true,
        headerStyle: {
          lineHeight: "19px",
        },
        
        formatter: styleForPriceVariance,
      },
    ];
  }

  if (props.type === "priceChangeSeller") {
    columns = [
      {
        dataField: "name",
        text: "SKU",
        sort: true,
      },
      {
        dataField: "category",
        text: "Category",
        sort: true,
      },
      {
        dataField: "currentWeekNetPrice",
        text: "current week Net Price",
        sort: true,

        headerStyle: {
          lineHeight: "17px",
        },
      },
      {
        dataField: "lastWeekNetPrice",
        text: "Last week Net Price",
        sort: true,

        headerStyle: {
          lineHeight: "17px",
        },
      },
      {
        dataField: "priceVariance",
        text: "Price Variance %",
        sort: true,
        style:{color:"#EB4563"},
      
        formatter: styleForPriceVariance,

        headerStyle: {
          lineHeight: "17px",
        },
      },
    ];
  }

  const rowEvents = {
    onClick: (e, row, rowIndex) => {
      if (props.type === "priceChangeWorldWide") {
        history.push(getUrl(row.countryName));
      }
      if (props.type === "priceChangeCountry") {
        history.push(getUrl(row.platformName));
      }
      if (props.type === "priceChangePlatform") {
        history.push(getUrl(row.name));
        if (row.sellerAuthorized) {
          dispatch(setSellerType("Authorized"));
        } else {
          dispatch(setSellerType("Un-Authorized"));
        }
      }
      if (props.type === "priceChangeSeller") {
        history.push(getUrl(row.name));
      }
    },
  };

  return (
    <BootstrapTable
      hover
      bordered={false}
      keyField="id"
      data={products}
      columns={columns}
      rowEvents={rowEvents}
      // filter={filterFactory()}
    />
  );
};

export default PriceChangeTable;



