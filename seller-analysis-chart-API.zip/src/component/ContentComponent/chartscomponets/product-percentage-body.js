import React from "react";
import ProductAvailabilityInpercentage from "./product-availability-inpercentage.js";
import { useDispatch, useSelector } from "react-redux";
import { setCurrentTableData } from "../../../store/action/product-availablity-actions";
import {
  setDropdownVisiblity,
  setCountry,
} from "../../../store/action/header-action";
import TableComponent from "./table-component.js";
import { Link, useRouteMatch } from "react-router-dom";
import "../content-charts.css";
import { useQuery } from "../utils.js";
import TableProductAvailability from "../chartscomponets/table-product-availability";
import TableSellerAnalysis from "../chartscomponets/table-seller-analysis";
import TableForSellerType from "../chartscomponets/table-seller-type";
import PriceVarianceTable from "../chartscomponets/price-variance-table";
import PriceChangeTable from "../chartscomponets/price-change-table";
import AllSKUlistTable from "../chartscomponets/allSKUlist-table";
import {LoaderAction} from "../../../store/action/loaderAction";

export default function ProductPercentageBody(props) {
  var showArrow = props.arrow === "show" ? true : false;
  var type = props.type == "table" ? true : false;
  var typeOfTable = props.tableFor;
  let { url } = useRouteMatch();

  const data = useSelector((state) => state.productAvailablity);
  const headerData = useSelector((state) => state.header);
  const dispatch = useDispatch();
  const updatedQuery = useQuery();

  function handleItemClick(item) {
    console.log(item);
    if (data.currentCategory === "worldwide") {
      dispatch(
        setCurrentTableData(
          "country",
          data.leftTableData,
          data.rightTableData,
          item.name
        )
      );
      dispatch(setCountry(item.name));
      dispatch(
        setDropdownVisiblity({
          ...headerData.dropdownVisiblity,
          platform: true,
          category: true,
          sellerType: false,
        })
      );
    } else if (data.currentCategory === "country") {
      dispatch(
        setCurrentTableData(
          "platform",
          data.leftTableData,
          data.rightTableData,
          item.name
        )
      );
      dispatch(
        setDropdownVisiblity({
          ...headerData.dropdownVisiblity,
          platform: true,
          category: true,
          sellerType: true,
        })
      );
    } else if (data.currentCategory === "platform") {
      dispatch(
        setCurrentTableData(
          "seller",
          data.leftTableData,
          data.rightTableData,
          item.name
        )
      );
    }
  }
  function getUrl(label) {
    let query = "";
    if (data.currentCategory === "worldwide") {
      query = "?country=" + label;
    } else if (data.currentCategory === "country") {
      query = "?country=" + updatedQuery.get("country") + "&platform=" + label;
    } else if (data.currentCategory === "platform") {
      query =
        "?country=" +
        updatedQuery.get("country") +
        "&platform=" +
        updatedQuery.get("platform") +
        "&seller=" +
        label;
    }
    return query;
  }

  return (
    <>
      <div
        className="chart-grey-container"
        style={{ height: 655, width: "100%" }}
      >
        {!type
          ? props.data.map((items) => (
              <>
                {showArrow && (
                  <Link to={getUrl(items.name)} className="link-color">
                    <ProductAvailabilityInpercentage
                      key={items.name}
                      name={items.name}
                      percentage={items.percentage}
                      arrowProperty={showArrow}
                      onClick={() => {
                        if (showArrow) {
                          handleItemClick(items);
                          dispatch(LoaderAction(true));
                        }
                      }}
                    />
                  </Link>
                )}
                {!showArrow && (
                  <ProductAvailabilityInpercentage
                    key={items.name}
                    name={items.name}
                    percentage={items.percentage}
                    arrowProperty={showArrow}
                    onClick={() => {
                      if (showArrow) {
                        handleItemClick(items);
                        dispatch(LoaderAction(true));
                      }
                    }}
                  />
                )}
              </>
            ))
          : null}

        {type && typeOfTable === "SKU Availability for Country" ? (
          <TableComponent data={props.data}></TableComponent>
        ) : null}

        {type && typeOfTable === "productAvailabilityTable" ? (
          <TableProductAvailability
            data={props.data}
          ></TableProductAvailability>
        ) : null}

        {type && typeOfTable === "sellerAnalysisPlatformWise" ? (
          <TableSellerAnalysis
            type={props.dataFor}
            data={props.data}
            arrowProperty={showArrow}
          ></TableSellerAnalysis>
        ) : null}

        {type && typeOfTable === "sellerAnalysisForAmazon" ? (
          <TableForSellerType data={props.data}></TableForSellerType>
        ) : null}

        {type && typeOfTable === "price change for countries" ? (
          <PriceChangeTable
            data={props.data}
            type={props.dataFor}
            arrowProperty={showArrow}
          ></PriceChangeTable>
        ) : null}

        {type && typeOfTable === "SKU by price variance" ? (
          <PriceVarianceTable
            data={props.data}
            arrowProperty={showArrow}
          ></PriceVarianceTable>
        ) : null}
        {type && typeOfTable === "all SKU list" ? (
          <AllSKUlistTable
            data={props.data}
            arrowProperty={showArrow}
          ></AllSKUlistTable>
        ) : null}
      </div>
    </>
  );
}
