import React from "react";
import ChevronRightIcon from "@material-ui/icons/ChevronRight";
import { useSelector } from "react-redux";

export default function ProductAvailabilityInpercentage(props) {
  var setWidth = props.arrowProperty ? "92%" : "100%";
  var setMargin = props.arrowProperty ? "-2px" : "8px";
  var typeOfData=useSelector((state)=>state.productAvailablity);
  

  return (
    <div className="percentage-tab" onClick={props.onClick}>
      <div style={{ width: setWidth,height:"22px" }}>
     <p style={{ margin: "0", marginBottom: setMargin, float: "left" }}
       className={typeOfData.currentCategory=="platform"?"setWidth200" : "setWidth100"}
        >
          {props.name}
        </p>

        <div style={typeOfData.currentCategory=="platform"?{width:"40%",float:"left"}:{width:"50%",float:"left"}}>
        <div style={{width:"85%",height:"30px",position:"relative"}}>
        <div className="percentage-line" style={{ float: "left",position:"absolute", width: `${props.percentage}` }}>
        </div>
        <p style={{ float: "left", margin: "0",marginLeft:`${props.percentage}`,paddingLeft:"20px", marginBottom: setMargin }}>
          {props.percentage}
        </p>
        </div>
       
        </div>

        
        {props.arrowProperty ? (
          <ChevronRightIcon
            className="material-icons"
            style={{ float: "right",right:"-40px",marginTop:"-5px" }}
          />
        ) : null}
       
      </div>
    </div>
  );
}
