// import React from "react";
// import ProductDetailsInTable from "./product-details-in-table";
// import AvailabilityPerWeek from "./availabilyt-per-week.js";
// import { makeStyles } from "@material-ui/core/styles";
// import Paper from "@material-ui/core/Paper";
// import Table from "@material-ui/core/Table";
// import TableBody from "@material-ui/core/TableBody";
// import TableCell from "@material-ui/core/TableCell";
// import TableContainer from "@material-ui/core/TableContainer";
// import TableHead from "@material-ui/core/TableHead";
// import TablePagination from "@material-ui/core/TablePagination";
// import TableRow from "@material-ui/core/TableRow";

// export default function TableComponent(props) {
//   const columns = Object.keys(props.data)
//     .map((item) => Object.keys(props.data[item]))[0]
//     .map((l) => {
//       const container = {};
//       container.id = l;
//       container.label = l;
//       return container;
//     });

//   const rows = props.data;

//   const useStyles = makeStyles({
//     root: {
//       width: "100%",
//     },
//     container: {
//       maxHeight: 440,
//     },
//   });

//   const classes = useStyles();
//   const [page, setPage] = React.useState(0);
//   const [rowsPerPage, setRowsPerPage] = React.useState(5);

//   const handleChangePage = (event, newPage) => {
//     setPage(newPage);
//   };

//   const handleChangeRowsPerPage = (event) => {
//     setRowsPerPage(+event.target.value);
//     setPage(0);
//   };

//   return (
//     <Paper className={classes.root}>
//       <TableContainer className={classes.container}>
//         <Table stickyHeader aria-label="sticky table" className="table">
//           <TableHead className="tableHeader">
//             <TableRow>
//               {columns.map((column) => (
//                 <TableCell
//                   key={column.id}
//                   align={column.align}
//                   style={{ minWidth: column.minWidth }}
//                 >
//                   {column.label}
//                 </TableCell>
//               ))}
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {rows
//               .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
//               .map((row) => {
//                 return (
//                   <TableRow hover role="checkbox" tabIndex={-1} key={row.code}>
//                     {columns.map((column) => {
//                       const value = row[column.id];

//                       return (
//                         <TableCell
//                           key={column.id}
//                           align={column.align}
//                           value={value}
//                         >
//                           {typeof value != "object" ? (
//                             value
//                           ) : Object.keys(value).length < 3 ? (
//                             <ProductDetailsInTable
//                               data={value}
//                             ></ProductDetailsInTable>
//                           ) : (
//                             <AvailabilityPerWeek
//                               data={value}
//                             ></AvailabilityPerWeek>
//                           )}
//                         </TableCell>
//                       );
//                     })}
//                   </TableRow>
//                 );
//               })}
//           </TableBody>
//         </Table>
//       </TableContainer>
//       <TablePagination
//         rowsPerPageOptions={[5, 10, 20]}
//         component="div"
//         count={rows.length}
//         rowsPerPage={rowsPerPage}
//         page={page}
//         onChangePage={handleChangePage}
//         onChangeRowsPerPage={handleChangeRowsPerPage}
//       />
//     </Paper>
//   );
// }

import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import BootstrapTable from "react-bootstrap-table-next";
import filterFactory, { textFilter } from "react-bootstrap-table2-filter";
import paginationFactory, {
  PaginationProvider,
  PaginationListStandalone,
  PaginationTotalStandalone,
  SizePerPageDropdownStandalone,
} from "react-bootstrap-table2-paginator";

const TableComponent = (props) => {
  function returnStyle(cell) {
    var color =
      cell == "Out of Stock"
        ? { color: "red", cursor: "auto" }
        : { color: "green", cursor: "auto" };
    return color;
  }

  const products = props.data;

  const columns = [
    {
      dataField: "SKUName",
      text: "SKU NAME",
      sort: true,
      style: { cursor: "auto" },
      headerStyle:{backgroundColor:"#F5F5F5"}
    },
    {
      dataField: "Category",
      text: "Category",
      sort: true,
      style: { cursor: "auto" },
      headerStyle:{backgroundColor:"#F5F5F5"}
    },
    {
      dataField: "Status",
      text: "Status",
      sort: true,
      headerStyle:{backgroundColor:"#F5F5F5"},
      style: returnStyle,
    },
  ];

  // var paginationOptions = {
  //   page: 2,

  //   sizePerPageList: [
  //     {
  //       text: "10",
  //       value: 10,
  //     },
  //     {
  //       text: "20",
  //       value: 20,
  //     },
  //     {
  //       text: "All",
  //       value: products.length,
  //     },
  //   ],
  //   sizePerPage: 10,
  //   pageStartIndex: 0,
  //   paginationSize: 3,
  //   prePage: "Prev",
  //   nextPage: "Next",
  //   firstPage: "First",
  //   lastPage: "Last",
  // };

  return (
    <div class="noCursor">
      <BootstrapTable
        bordered={false}
        style={{ cursor: "auto" }}
        keyField="id"
        data={products}
        columns={columns}
        filter={filterFactory()}
      />
    </div>
  );
};

export default TableComponent;
