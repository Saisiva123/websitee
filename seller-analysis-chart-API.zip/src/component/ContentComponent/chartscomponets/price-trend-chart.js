import React from "react";
import "../content-charts.css";
import {
  LineChart,
  Line,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Label,
  CartesianGrid,
  Tooltip,
} from "recharts";
import { useMediaQuery } from "@material-ui/core";

const data = [
  {
    name: "Week 01",
    "Suggested Retail Price (SRP)": 20,
    "Net Dist. Price (NDP)": 15,
    "Advertising Selling Price (ASP)": 5,
  },
  {
    name: "Week 02",
    "Suggested Retail Price (SRP)": 20,
    "Net Dist. Price (NDP)": 15,
    "Advertising Selling Price (ASP)": 5,
  },
  {
    name: "Week 03",
    "Suggested Retail Price (SRP)": 20,
    "Net Dist. Price (NDP)": 15,
    "Advertising Selling Price (ASP)": 5,
  },
  {
    name: "Week 04",
    "Suggested Retail Price (SRP)": 20,
    "Net Dist. Price (NDP)": 15,
    "Advertising Selling Price (ASP)": 5,
  },
];

export default function PriceTrendChart(props) {
  //This will be a state connected to redux

  const matches = useMediaQuery("(min-width:960px)");
  return (
    <div className="chart-grey-container">
      {
        <ResponsiveContainer width={"100%"} height={matches ? 630 : 320}>
          <LineChart data={data}>
            <CartesianGrid strokeOpacity={0.3} horizontal={false} />
            <XAxis dataKey="name" stroke={0} tickMargin={2} dy={10}>
              {/* <Label
                value="Weeks"
                fontFamily="Open sans"
                position="insideBottom"
                dy={10}
              /> */}
            </XAxis>

            <YAxis
              stroke={0}
              tickFormatter={(tickItem) => {
                return "$" + tickItem.toString();
              }}>
              <Label
                style={{ textAnchor: "middle" }}
                value="Product price"
                position="insideLeft"
                offset={10}
                angle={-90}
                fontFamily="Open sans"
              />
            </YAxis>
            <Tooltip
              wrapperStyle={{ borderRadius: 10 }}
              formatter={(value, name, props) => {
                return "$" + value.toString();
              }}
            />

            <Line
              type="monotone"
              dataKey="Suggested Retail Price (SRP)"
              stroke="#0096D6"
              strokeWidth={2}
              activeDot={{ r: 8 }}
            />
            <Line
              type="monotone"
              dataKey="Net Dist. Price (NDP)"
              stroke="#1D3537"
              strokeWidth={2}
            />
            <Line
              type="monotone"
              dataKey="Advertising Selling Price (ASP)"
              stroke="#EB4563"
              strokeWidth={2}
              activeDot={{ r: 8 }}
            />
          </LineChart>
        </ResponsiveContainer>
      }
    </div>
  );
}
