import React from "react";
import AvailabilityPerWeek from "./availabilyt-per-week";
import "bootstrap/dist/css/bootstrap.min.css";
import BootstrapTable from "react-bootstrap-table-next";
import filterFactory from "react-bootstrap-table2-filter";
import paginationFactory from "react-bootstrap-table2-paginator";
import { useSelector} from "react-redux";
import { useQuery } from "../utils";
import { useHistory } from "react-router-dom";

const TableSellerAnalysis = (props) => {
  const products = props.data;
  const updatedQuery = useQuery();
  const showArrow = props.arrowProperty;
  let history = useHistory();

  const data = useSelector((state) => state.sellerAnalysis);

  function styleForPriceVariance(cell) {
    return (
      <div
        className={"arrowForTable"}
        style={{ width: "100%" }}
      >
        <p>{cell}</p>
      </div>
    );
  }


  function getUrl(label) {
    let query = "";
    if (data.currentCategory === "worldwide") {
      query = "?country=" + label;
    } else if (data.currentCategory === "country") {
      query = "?country=" + updatedQuery.get("country") + "&platform=" + label;
    } else if (data.currentCategory === "platform") {
      query =
        "?country=" +
        updatedQuery.get("country") +
        "&platform=" +
        updatedQuery.get("platform") +
        "&seller=" +
        label;
    }
    return query;
  }


  let columns;

  if(props.type==="sellerAnalysisWorldWide")
  {
    columns = [
      {
        dataField: "countryName",
        text: "Country Name",
        sort: true,
        style: { width: "61%" ,},
        headerStyle:{backgroundColor:"#F5F5F5",width:"58%"},
        formatter: (cell, row, rowIndex) => (
          <>
            <p style={{ float: "left" }}>{cell}</p>
            <div
              className="percentage-line"
              style={{
                float: "right",
                width: "75%",
                height: "23px",
                backgroundColor: "#EB4563",
              }}
            >
              <div
                style={{
                  height: "100%",
                  width: "65%",
                  backgroundColor: "rgb(29, 53, 87)",
                }}
              ></div>
            </div>
          </>
        ),
      },
      {
        dataField: "authorizedSeller",
        text: "Authorized Sellers",
        sort: true,
        headerStyle:{backgroundColor:"#F5F5F5"},
      },
      {
        dataField: "unauthorizedSeller",
        text: "Unauthorized Sellers",
        sort: true,
        headerStyle:{backgroundColor:"#F5F5F5"},
        formatter:styleForPriceVariance
      },
    ];
  }
  if(props.type==="sellerAnalysisCountry")
  {
    columns = [
      {
        dataField: "platformName",
        text: "Platform Name",
        sort: true,
        style: { width: "61%",'white-space' : 'nowrap' },
        headerStyle:{backgroundColor:"#F5F5F5",width:"58%"},
        formatter: (cell, row, rowIndex) => (
          <>
            <p style={{ float: "left" }}>{cell}</p>
            <div
              className="percentage-line"
              style={{
                float: "right",
                width: "75%",
                height: "23px",
                backgroundColor: "#EB4563",
              }}
            >
              <div
                style={{
                  height: "100%",
                  width: "65%",
                  backgroundColor: "rgb(29, 53, 87)",
                }}
              ></div>
            </div>
          </>
        ),
      },
      {
        dataField: "authorizedSeller",
        text: "Authorized Sellers",
        sort: true,
        style:{'white-space' : 'nowrap'},
        headerStyle:{backgroundColor:"#F5F5F5"},
      },
      {
        dataField: "unauthorizedSeller",
        text: "Unauthorized Sellers",
        sort: true,
        style:{'white-space' : 'nowrap'},
        headerStyle:{backgroundColor:"#F5F5F5"},
        formatter:styleForPriceVariance
      },
    ];
  }

  if(props.type==="sellerAnalysisSeller")
  {
    columns = [
      {
        dataField: "skuName",
        text: "SKU Name",
        sort: true,
        headerStyle:{backgroundColor:"#F5F5F5"}
      },
      {
        dataField: "description",
        text: "Description",
        sort: true,
        headerStyle:{backgroundColor:"#F5F5F5"},
      },
      {
        dataField: "category",
        text: "Category",
        sort: true,
        headerStyle:{backgroundColor:"#F5F5F5"},
      },
      {
        dataField: "shippingSla",
        text: "Shipping SLA",
        sort: true,
        headerStyle:{backgroundColor:"#F5F5F5"},
      },
      {
        dataField: "shippingCost",
        text: "Shipping Cost",
        sort: true,
        headerStyle:{backgroundColor:"#F5F5F5"},
      },
      {
        dataField: "reviews",
        text: "Reviews",
        sort: true,
        headerStyle:{backgroundColor:"#F5F5F5"},
 
      },
      {
        dataField: "ratings",
        text: "Ratings",
        sort: true,
        headerStyle:{backgroundColor:"#F5F5F5"},
     
      },
      {
        dataField: "productUrl",
        text: "Product URL",
        sort: true,
        style:{'color':'rgb(92, 182, 220)','text-decoration' : 'underline'},
        headerStyle:{backgroundColor:"#F5F5F5"},
        formatter:styleForPriceVariance
      },
    ];
  }

  const rowEvents = {
    onClick: (e, row, rowIndex) => {
      if(props.type==="sellerAnalysisWorldWide")
      {
        history.push(getUrl(row.countryName));
      }
      if(props.type==="sellerAnalysisCountry")
      {
        history.push(getUrl(row.platformName));
      }
    },
  };

  return (
    <div className="prodAvailTable">
      <BootstrapTable
        hover
        bordered={false}
        keyField="id"
        data={products}
        columns={columns}
        rowEvents={rowEvents}
        filter={filterFactory()}
      />
      </div>
  );
};

export default TableSellerAnalysis;
