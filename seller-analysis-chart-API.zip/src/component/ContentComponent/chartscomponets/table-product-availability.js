import React from "react";
import AvailabilityPerWeek from "./availabilyt-per-week";
import "bootstrap/dist/css/bootstrap.min.css";
import BootstrapTable from "react-bootstrap-table-next";
import filterFactory, { textFilter } from "react-bootstrap-table2-filter";
import paginationFactory, {
  PaginationProvider,
  PaginationListStandalone,
  PaginationTotalStandalone,
  SizePerPageDropdownStandalone,
} from "react-bootstrap-table2-paginator";

const TableProductAvailability = (props) => {
  function returnStyle(cell) {
    var color = cell == "Out of Stock" ? { color: "red" } : { color: "green" };
    return color;
  }

  const products = props.data;
 // console.log(products);
  const columns = [
    {
      dataField: "SKUName",
      text: "SKU NAME",
      sort: true,
      style:{cursor:"auto"},
      headerStyle:{backgroundColor:"#F5F5F5"}
      // style:{width:"20%",'white-space' : 'nowrap'}
      // filter:textFilter({
      //   delay: 1000, // default is 500ms
      //   style: {
      //     backgroundColor: 'white'
      //   },
      //   className: 'skuInputField',
      //   placeholder: 'Search by Sku Name',
      //   onClick: e => console.log(e)
      // })
    },
    {
      dataField: "Description",
      text: "Description",
      sort: true,
      style:{cursor:"auto"},
      headerStyle:{backgroundColor:"#F5F5F5"}
      // style:{width:"20%",'white-space' : 'nowrap'}
      // filter:textFilter({
      //   delay: 1000, // default is 500ms
      //   style: {
      //     backgroundColor: 'white'
      //   },
      //   className: 'skuInputField',
      //   placeholder: "Search by Description",
      //   onClick: e => console.log(e)
      // })
    },
    {
      dataField: "Category",
      text: "Category",
      sort: true,
      style:{cursor:"auto"},
      headerStyle:{backgroundColor:"#F5F5F5"}
      // style:{width:"20%",'white-space' : 'nowrap'}
      // filter:textFilter({
      //   delay: 1000, // default is 500ms
      //   style: {
      //     backgroundColor: 'white'
      //   },
      //   className: 'skuInputField',
      //   placeholder: 'Search by Category',
      //   onClick: e => console.log(e)
      // })
    },
    {
      dataField: "Status",
      text: "Status",
      sort: true,
      style:{cursor:"auto"},
      headerStyle:{backgroundColor:"#F5F5F5"}
      // style: returnStyle,
      // style:{width:"20%",'white-space' : 'nowrap'}
      // filter:textFilter({
      //   delay: 1000, // default is 500ms
      //   style: {
      //     backgroundColor: 'white'
      //   },
      //   className: 'skuInputField',
      //   placeholder: 'Search by Status',
      //   onClick: e => console.log(e)
      // })
    },
    {
      dataField: "AvailabilityPerWeek",
      text: "Availability Per Week",
      style:{cursor:"auto"},
      headerStyle:{backgroundColor:"#F5F5F5"},
      // style:{width:"20%",'white-space' : 'nowrap'},
      formatter: (cell, row, rowIndex) => (
        <AvailabilityPerWeek data={row}></AvailabilityPerWeek>
      ),
    },
  ];

  var paginationOptions = {
    page: 0,
    // alwaysShowAllBtns: true, // Always show next and previous button
    // withFirstAndLast: false, // Hide the going to First and Last page button
    // hideSizePerPage: true, // Hide the sizePerPage dropdown always
    // hidePageListOnlyOnePage: true, // Hide the pagination list when only one page
    sizePerPageList: [
      {
        text: "10",
        value: 10,
      },
      {
        text: "20",
        value: 20,
      },
      {
        text: "All",
        value: products.length,
      },
    ],
    sizePerPage: 10,
    pageStartIndex: 0,
    paginationSize: 3,
    prePage: "Prev",
    nextPage: "Next",
    firstPage: "First",
    lastPage: "Last",
  };
  const rowEvents = {
    onClick: (e, row, rowIndex) => {
      //action should be performed here after clicking on the particular row
    },
  };

  return (
    <div className="prodAvailTable">
      <BootstrapTable   
      className="ProductAvailabilityTable"  
        bordered={false}
        keyField="id"
        data={products}
        columns={columns}
        filter={filterFactory()}
        rowEvents={rowEvents}
        pagination={paginationFactory(paginationOptions)}
      />
</div>
  );
};

export default TableProductAvailability;
