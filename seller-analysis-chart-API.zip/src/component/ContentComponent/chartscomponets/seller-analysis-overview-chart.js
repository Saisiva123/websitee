import React, { useEffect, useState } from "react";
import "../content-charts.css";
import { Divider, useMediaQuery } from "@material-ui/core";
import { abbreviateNumber } from "../utils";
import { useSelector } from "react-redux";

export default function SellerAnalysisOverviewChart(props) {
  //This will be a state connected to redux
  const data = useSelector((state) => state.sellerAnalysis.sellerAnalysisData);
  const [totalSellers, setTotalSellers] = useState(0);
  const [currentData, setCurrentData] = useState({
    authorizedPercent: 0,
    unauthorizedPercent: 0,
    authorized: 0,
    unauthorized: 0,
  });
  function getData() {
    if (
      data &&
      data.sellerAnalysis &&
      data.sellerAnalysis.periodicity &&
      data.sellerAnalysis.periodicity.stock_count_world_wide.length > 0
    ) {
      let length =
        data.sellerAnalysis.periodicity.stock_count_world_wide.length;
      let lastObject =
        data.sellerAnalysis.periodicity.stock_count_world_wide[length - 1];
      let total = lastObject.authorized_count + lastObject.unauthorized_count;

      setTotalSellers(total);
      let outStock = (lastObject.unauthorized_count / total) * 100;
      if (outStock) {
        outStock += 1;
      }

      setCurrentData({
        authorizedPercent: parseInt(
          (lastObject.authorized_count / total) * 100
        ),
        unauthorizedPercent: parseInt(outStock),
        authorized: lastObject.authorized_count,
        unauthorized: lastObject.authorized_count,
      });
    } else if (
      data &&
      data.sellerAnalysis &&
      data.sellerAnalysis.periodicity &&
      data.sellerAnalysis.periodicity.stock_count_world_wide.length === 0
    ) {
      setTotalSellers(0);
      setCurrentData({
        authorizedPercent: 0,
        unauthorizedPercent: 0,
        authorized: 0,
        unauthorized: 0,
      });
    }
  }

  useEffect(() => {
    getData();
  }, [data]);

  const matches = useMediaQuery("(min-width:960px)");
  const checkSupport = useMediaQuery("(max-width:1120px)");
  return (
    <div
      style={{
        height:
          matches && checkSupport
            ? 380
            : matches && !checkSupport
            ? 340
            : "auto",
        overflow: matches ? "hidden" : "auto",
      }}>
      <div className="chart-grey-container">
        <div className={"product-total-title-container"}>
          <span className={"product-total-title"}>Total Sellers</span>
          <span className={"product-total-title-number"}>{totalSellers}</span>
        </div>
        <Divider />
        <div
          style={{
            flexDirection: "row",
            flex: 1,
            margin: "15px 0px 10px 0px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}>
          <div>
            <span className={"stacked-bar-item-title"}>Authorized</span>
            <span className={"stacked-bar-item-percentage"}>
              {currentData.authorizedPercent}%
            </span>
          </div>
          <div>
            <span className={"stacked-bar-item-title"}>Unauthorized</span>
            <span className={"stacked-bar-item-percentage"}>
              {currentData.unauthorizedPercent}%
            </span>
          </div>
        </div>
        <div style={{ flexDirection: "row", flex: 1, display: "flex" }}>
          <div
            className="stacked-chart"
            style={{
              width: `${currentData.authorizedPercent}%`,

              borderTopRightRadius: 0,
              borderBottomRightRadius: 0,
              marginBottom: 0,
            }}
          />

          <div
            className="stacked-chart"
            style={{
              width: `${currentData.unauthorizedPercent}%`,
              marginBottom: 0,
              background: "#EB4563",
              borderTopLeftRadius: 0,
              borderBottomLeftRadius: 0,
            }}
          />
        </div>
      </div>
      <div className="stacked-chart-below-details-container">
        <div
          className={"chart-grey-container " + "stacked-chart-instock-details"}>
          <div className="stacked-chart-details-left">
            <div className="stacked-chart-details-title">
              Authorized Sellers
            </div>
            <div className={"stacked-chart-detail-number"}>
              {currentData.authorized}
            </div>
            <div className={"stacked-chart-details-title"}>Sellers</div>
          </div>
        </div>

        <div
          className={
            "chart-grey-container " + "stacked-chart-outstock-details"
          }>
          <div className="stacked-chart-details-left">
            <div className="stacked-chart-details-title">
              Unauthorized Sellers
            </div>
            <div className={"stacked-chart-detail-number"}>
              {currentData.unauthorized}
            </div>
            <div className={"stacked-chart-details-title"}>Sellers</div>
          </div>
        </div>
      </div>
    </div>
  );
}
