import React, { useState, useEffect } from "react";
import "../content-charts.css";
import { Divider, useMediaQuery } from "@material-ui/core";
import { abbreviateNumber } from "../utils";
import { useSelector } from "react-redux";

export default function ProductAvailablityOverViewChart(props) {
  //This will be a state connected to redux
  const data = useSelector(
    (state) => state.productAvailablity.productAvailablityData
  );
  const [totalProducts, setTotalProducts] = useState(0);
  const [currentData, setCurrentData] = useState({
    instockPercent: 0,
    outStockPercent: 0,
    inStock: 0,
    outStock: 0,
    listing: 0,
    unlisting: 0,
  });
  function getData() {
    if (
      data &&
      data.productAvailability &&
      data.productAvailability.periodicity &&
      data.productAvailability.periodicity.stock_count_world_wide.length > 0
    ) {
      let length =
        data.productAvailability.periodicity.stock_count_world_wide.length;
      let lastObject =
        data.productAvailability.periodicity.stock_count_world_wide[length - 1];
      let outCount = lastObject.listing_count + lastObject.unlisting_count;
      let total = lastObject.in_count + outCount;

      setTotalProducts(total);
      let outStock = (outCount / total) * 100;
      if (outStock) {
        outStock += 1;
      }

      setCurrentData({
        instockPercent: parseInt((lastObject.in_count / total) * 100),
        outStockPercent: parseInt(outStock),
        inStock: lastObject.in_count,
        outStock: outCount,
        listing: lastObject.listing_count,
        unlisting: lastObject.unlisting_count,
      });
    } else if (
      data &&
      data.productAvailability &&
      data.productAvailability.periodicity &&
      data.productAvailability.periodicity.stock_count_world_wide.length === 0
    ) {
      setTotalProducts(0);
      setCurrentData({
        instockPercent: 0,
        outStockPercent: 0,
        inStock: 0,
        outStock: 0,
        listing: 0,
        unlisting: 0,
      });
    }
  }

  useEffect(() => {
    getData();
  }, [data]);

  const matches = useMediaQuery("(min-width:960px)");
  const checkSupport = useMediaQuery("(max-width:1120px)");
  return (
    <div
      style={{
        height:
          matches && checkSupport
            ? 380
            : matches && !checkSupport
            ? 340
            : "auto",
        overflow: matches ? "hidden" : "auto",
      }}>
      <div className="chart-grey-container">
        <div className={"product-total-title-container"}>
          <span className={"product-total-title"}>Total Products</span>
          <span className={"product-total-title-number"}>{totalProducts}</span>
        </div>
        <Divider />
        <div
          style={{
            flexDirection: "row",
            flex: 1,
            margin: "15px 0px 10px 0px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}>
          <div>
            <span className={"stacked-bar-item-title"}>In Stock</span>
            <span className={"stacked-bar-item-percentage"}>
              {currentData.instockPercent}%
            </span>
          </div>
          <div>
            <span className={"stacked-bar-item-title"}>Out of Stock</span>
            <span className={"stacked-bar-item-percentage"}>
              {currentData.outStockPercent}%
            </span>
          </div>
        </div>
        <div style={{ flexDirection: "row", flex: 1, display: "flex" }}>
          <div
            className="stacked-chart"
            style={{
              width: `${currentData.instockPercent}%`,
              background: "#0096D6",
              borderTopRightRadius: 0,
              borderBottomRightRadius: 0,
              marginBottom: 0,
            }}
          />

          <div
            className="stacked-chart"
            style={{
              width: `${currentData.outStockPercent}%`,
              marginBottom: 0,
              background: "#1D3557",
              borderTopLeftRadius: 0,
              borderBottomLeftRadius: 0,
            }}
          />
        </div>
      </div>
      <div className="stacked-chart-below-details-container">
        <div
          className={"chart-grey-container " + "stacked-chart-instock-details"}>
          <div className="stacked-chart-details-left">
            <div className="stacked-chart-details-title">In Stock</div>
            <div className={"stacked-chart-detail-number"}>
              {currentData.inStock}
            </div>
            <div className={"stacked-chart-details-title"}>Products</div>
          </div>
        </div>

        <div
          className={
            "chart-grey-container " + "stacked-chart-outstock-details"
          }>
          <div className="stacked-chart-details-left">
            <div className="stacked-chart-details-title">Out of Stock</div>
            <div className={"stacked-chart-detail-number"}>
              {currentData.outStock}
            </div>
            <div className={"stacked-chart-details-title"}>Products</div>
          </div>
          <div className="stacked-chart-details-right">
            <div
              className="stacked-chart-details-right-card"
              style={{ marginBottom: 5 }}>
              <span
                className="stacked-chart-details-right-card-title"
                style={{ color: "grey" }}>
                Listed
              </span>
              <span
                className="stacked-chart-details-right-card-title"
                style={{ fontWeight: "bold" }}>
                {currentData.listing} Products
              </span>
            </div>
            <div
              className="stacked-chart-details-right-card"
              style={{ marginTop: 5 }}>
              <span
                className="stacked-chart-details-right-card-title"
                style={{ color: "grey" }}>
                Unlisted
              </span>
              <span
                className="stacked-chart-details-right-card-title"
                style={{ fontWeight: "bold" }}>
                {currentData.unlisting} Products
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
