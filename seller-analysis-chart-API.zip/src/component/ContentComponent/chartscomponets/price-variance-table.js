import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import BootstrapTable from "react-bootstrap-table-next";
import filterFactory from "react-bootstrap-table2-filter";
import { useQuery } from "../utils";
import { useHistory } from "react-router-dom";

const TableSellerAnalysis = (props) => {
  const products = props.data;
  const showArrow = props.arrowProperty;
  const updatedQuery = useQuery();
  let history = useHistory();

  function styleForPriceVariance(cell) {
    return (
      <div className="arrowForTable" style={{ widtyh: "100%" }}>
        <p style={{ color: "red" }}>{cell}</p>
      </div>
    );
  }

  const columns = [
    {
      dataField: "platformName",
      text: "Platform",
      sort: true,
    },
    {
      dataField: "sellerName",
      text: "Seller Name",
      sort: true,
      headerStyle:{
        lineHeight:"17px"
      }
    },
    {
      dataField: "currentWeekNetPrice",
      text: "Current Week Net Price",
      sort: true,
      headerStyle:{
        lineHeight:"17px"
      }
    },
    {
      dataField: "lastWeekNetPrice",
      text: "Last Week Net Price",
      sort: true,
      headerStyle:{
        lineHeight:"17px"
      }
  
    },
    {
      dataField: "priceVariance",
      text: "Price Variance %",
      sort: true,
      headerStyle:{
        lineHeight:"17px"
      },
      formatter: styleForPriceVariance
    },
  ];
  const rowEvents = {
    onClick: (e, row, rowIndex) => {
      history.replace(
        "?country=" +
          updatedQuery.get("country") +
          "&platform=" +
          row.platformName +
          "&seller=" +
          row.sellerName +
          "&sku=" +
          updatedQuery.get("sku")
      );
    },
  };

  return (
    <BootstrapTable
      hover
      bordered={false}
      keyField="id"
      data={products}
      columns={columns}
      rowEvents={rowEvents}
      filter={filterFactory()}
    />
  );
};

export default TableSellerAnalysis;
