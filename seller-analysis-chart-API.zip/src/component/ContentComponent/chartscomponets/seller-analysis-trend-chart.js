import React, { useState, useEffect } from "react";
import "../content-charts.css";
import {
  LineChart,
  Line,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Label,
  CartesianGrid,
  Tooltip,
} from "recharts";
import { useSelector } from "react-redux";
const data = [
  {
    name: "Week 01",
    Authorized: 50,
    Unauthorized: 30,
  },
  {
    name: "Week 02",
    Authorized: 70,
    Unauthorized: 40,
  },
  {
    name: "Week 03",
    Authorized: 20,
    Unauthorized: 50,
  },
  {
    name: "Week 04",
    Authorized: 86,
    Unauthorized: 34,
  },
];

export default function SellerAnalysisTrendChart(props) {
  //This will be a state connected to redux
  const data = useSelector((state) => state.sellerAnalysis.sellerAnalysisData);
  const headerData = useSelector((state) => state.header);
  const [chartData, setChartData] = useState([]);

  useEffect(() => {
    if (
      data &&
      data.sellerAnalysis &&
      data.sellerAnalysis.periodicity &&
      data.sellerAnalysis.periodicity.stock_count_world_wide.length > 0
    ) {
      let chartsInfo = data.sellerAnalysis.periodicity.stock_count_world_wide;

      const updatedData = chartsInfo.map((item, index) => {
        let total = item.authorized_count + item.unauthorized_count;

        let outStock = (item.unauthorized_count / total) * 100;
        if (outStock) {
          outStock += 1;
        }
        return {
          name: `${headerData.currentTimeline} 0${index + 1}`,
          Authorized: parseInt((item.authorized_count / total) * 100),
          Unauthorized: parseInt(outStock),
        };
      });
      setChartData(updatedData);
    } else if (
      data &&
      data.sellerAnalysis &&
      data.sellerAnalysis.periodicity &&
      data.sellerAnalysis.periodicity.stock_count_world_wide.length === 0
    ) {
      setChartData([]);
    }
  }, [data]);

  return (
    <div className="chart-grey-container">
      <ResponsiveContainer width={"100%"} height={290}>
        <LineChart data={chartData}>
          {/* <CartesianGrid strokeOpacity={0.3} /> */}
          <XAxis
            dataKey="name"
            axisLine={{ strokeWidth: 0.3 }}
            tickMargin={2}
            dy={10}
            tickLine={false}>
            {/* <Label
              value="No. of Weeks"
              fontFamily="Open sans"
              position="insideBottom"
              dy={10}
            />*/}
          </XAxis>

          <YAxis
            axisLine={{ strokeWidth: 0.3 }}
            tickFormatter={(tickItem) => {
              return tickItem.toString() + "%";
            }}>
            <Label
              style={{ textAnchor: "middle" }}
              value="No. of Sellers"
              position="insideLeft"
              offset={2}
              angle={-90}
              fontFamily="Open sans"
            />
          </YAxis>
          <Tooltip
            wrapperStyle={{ borderRadius: 10 }}
            formatter={(value, name, props) => {
              return value.toString() + "%";
            }}
          />

          <Line
            type="linear"
            dataKey="Authorized"
            stroke="#1d3557"
            strokeWidth={2}
            activeDot={{ r: 8 }}
          />
          <Line
            type="linear"
            dataKey="Unauthorized"
            stroke="#EB4563"
            strokeWidth={2}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
