import React, { PureComponent } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Label,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { Paper, useMediaQuery } from "@material-ui/core";

const data = [
  {
    label: "+ve  -ve",
    name: "Week 01",
    uv: 4000,
    pv: 2400,
    go: 4232,
    amt: 2400,
    aba: 4500,
    cd: 1400,
    ef: 3232,
    gh: 2000,
  },
  {
    label: "+ve  -ve",
    name: "Week 02",
    uv: 3000,
    pv: 1398,
    go: 4232,
    amt: 2210,
    aba: 6400,
    cd: 1400,
    ef: 3232,
    gh: 2450,
  },
  {
    label: "+ve  -ve",
    name: "Week 03",
    uv: 2000,
    pv: 9800,
    go: 4232,
    amt: 2290,
    aba: 2000,
    cd: 4400,
    ef: 1232,
    gh: 3430,
  },
  {
    label: "+ve  -ve",
    name: "Week 04",
    uv: 2780,
    pv: 3908,
    go: 4232,
    amt: 2000,
    aba: 1700,
    cd: 2230,
    ef: 3432,
    gh: 1500,
  },
];

const renderWeeklyTick = (tickProps) => {
  const { x, y, payload } = tickProps;
  const { value, offset } = payload;

  if (value) {
    return (
      <text x={x + offset} y={y - 4} textAnchor="middle">
        {value}
      </text>
    );
  }

  return null;
};
class CustomizedAxisTick extends PureComponent {
  render() {
    const { x, y, stroke, payload } = this.props;

    return (
      <g transform={`translate(${x},${y})`}>
        <text x={-10} y={0} dy={8} textAnchor="end" fill="red">
          {payload.value.split(" ")[0]}
        </text>
        <text x={10} y={0} dy={8} textAnchor="start" fill="#666">
          {"-ve"}
        </text>
      </g>
    );
  }
}
function currentLimits(value) {
  return value === "pv" || value == "aba"
    ? "0.00-25%"
    : value === "go" || value == "cd"
    ? "25.01%-50%"
    : value === "amt" || value == "ef"
    ? "50.01%-75%"
    : value === "uv" || value == "gh"
    ? "75.01%-100%"
    : value;
}

var tooltip;
const CustomTooltip = ({ active, payload }) => {
  if (!active || !tooltip) return null;
  for (const bar of payload)
    if (bar.dataKey === tooltip)
      return (
        <Paper style={{ padding: 8, textAlign: "center" }}>
          <span style={{ color: "#EB4563", fontSize: 22 }}>{bar.value}</span>
          <br />
          <span style={{ color: "#000000AA", fontSize: 14 }}>
            {currentLimits(bar.name)}
          </span>
          <br />
          <span style={{ color: "#000000AA", fontSize: 14 }}>Range</span>
        </Paper>
      );
  return null;
};
export default function PriceVarianceBarChart(props) {
  const matches = useMediaQuery("(min-width:960px)");
  return (
    <div className="chart-grey-container">
      <ResponsiveContainer width="100%" height={matches ? 630 : 320}>
        <BarChart
          data={data}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}>
          <XAxis dataKey="label" tick={<CustomizedAxisTick />} />
          <XAxis
            dataKey="name"
            axisLine={false}
            tickLine={false}
            interval={0}
            tick={renderWeeklyTick}
            scale="band"
            xAxisId="weekly">
            <Label
              value="Weeks"
              fontFamily="Open sans"
              position="insideBottom"
              dy={10}
            />
          </XAxis>
          <YAxis stroke={0} tick={false}>
            <Label
              style={{ textAnchor: "middle" }}
              value="Listing"
              position="insideLeft"
              angle={-90}
              fontFamily="Open sans"
            />
          </YAxis>
          <Tooltip
            cursor={{ fill: "transparent" }}
            content={<CustomTooltip />}
          />
          <Legend
            align="right"
            verticalAlign="top"
            iconSize={16}
            content={renderLegend}
          />
          <Bar
            dataKey="pv"
            stackId="a"
            fill="#8EBEDA"
            onMouseOver={() => (tooltip = "pv")}
          />
          <Bar
            dataKey="go"
            stackId="a"
            fill="#5A9ECC"
            onMouseOver={() => (tooltip = "go")}
          />
          <Bar
            dataKey="amt"
            stackId="a"
            fill="#1C5BA6"
            onMouseOver={() => (tooltip = "amt")}
          />

          <Bar
            dataKey="uv"
            stackId="a"
            fill="#0B3281"
            onMouseOver={() => (tooltip = "uv")}
            label={{ position: "top", fontSize: 16 }}
          />
          <Bar
            dataKey="aba"
            stackId="b"
            fill="#8EBEDA"
            onMouseOver={() => (tooltip = "aba")}
          />
          <Bar
            dataKey="cd"
            stackId="b"
            fill="#5A9ECC"
            onMouseOver={() => (tooltip = "cd")}
          />
          <Bar
            dataKey="ef"
            stackId="b"
            fill="#1C5BA6"
            onMouseOver={() => (tooltip = "ef")}
          />

          <Bar
            dataKey="gh"
            stackId="b"
            fill="#0B3281"
            onMouseOver={() => (tooltip = "gh")}
            label={{ position: "top", fontSize: 16 }}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

const renderLegend = (props) => {
  const { payload } = props;

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "flex-end",
        alignItems: "center",
      }}>
      {payload.slice(0, 4).map((entry, index) => (
        <>
          <span
            style={{
              height: 10,
              width: 10,
              background: entry.color,
              marginRight: 5,
              marginLeft: 5,
            }}
          />
          <span
            key={`item-${index}`}
            style={{ fontSize: 12, color: "#666", marginRight: 5 }}>
            {entry.value === "pv"
              ? "0.00-25%"
              : entry.value === "go"
              ? "25.01%-50%"
              : entry.value === "amt"
              ? "50.01%-75%"
              : entry.value === "uv"
              ? "75.01%-100%"
              : ""}
          </span>
        </>
      ))}
    </div>
  );
};
