import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import BootstrapTable from "react-bootstrap-table-next";
import filterFactory from "react-bootstrap-table2-filter";
import paginationFactory from "react-bootstrap-table2-paginator";
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
import { useQuery } from "../utils";
import { useHistory } from "react-router-dom";

const AllSKUlistTable = (props) => {
  const products = props.data;
  const showArrow = props.arrowProperty;

  const updatedQuery = useQuery();
  let history = useHistory();

  function styleForPriceVariance(cell) {
    return (
      <div
        className={showArrow ? "arrowForTable" : ""}
        style={{ widtyh: "100%" }}
      >
        <p>{cell}</p>
      </div>
    );
  }
  let columns = [
    {
      dataField: "name",
      text: "SKU Name",
      sort: true,
      style: { width: "5%",cursor:"auto" },
    },
    {
      dataField: "category",
      text: "Category",
      sort: true,
      style: { width: "5%", cursor:"auto" },
    },
    {
      dataField: "currentWeekNetPrice",
      text: "Average Net price current week",
      sort: true,
      style: { width: "5%", cursor:"auto"  },
      headerStyle:{lineHeight:"17px"}
    },
    {
      dataField: "lastWeekNetPrice",
      text: "Average Net price last week",
      sort: true,
      style: { width: "5%",cursor:"auto"  },
      headerStyle:{lineHeight:"17px"}
    },
    {
      dataField: "priceVariance",
      text: "Average Price Variance Compared to Last Week",
      sort: true,
      headerStyle:{lineHeight:"17px"},
      formatter: styleForPriceVariance,
      style: {
        color:"#EB4563",
        cursor:"auto" 
      },
    },
  ];

  return (
    <div className="prodAvailTable">
    <BootstrapTable
      bordered={false}
      keyField="id"
      data={products}
      columns={columns}
      filter={filterFactory()}
    />
    </div>
  );
};

export default AllSKUlistTable;
